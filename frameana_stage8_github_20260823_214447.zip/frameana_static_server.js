"use strict";

const fs = require("fs");
const http = require("http");
const path = require("path");

const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 3000);
const LOCAL_BUILD_DIR = path.resolve(__dirname, "build");
const D_DRIVE_BUILD_DIR = "D:\\FRAMEANA\\frontend_build";
const DEFAULT_BUILD_DIR =
  process.platform === "win32" && fs.existsSync(D_DRIVE_BUILD_DIR) ? D_DRIVE_BUILD_DIR : LOCAL_BUILD_DIR;
const BUILD_DIR = path.resolve(process.env.FRAMEANA_STATIC_BUILD_DIR || DEFAULT_BUILD_DIR);

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".svg": "image/svg+xml",
};

function resolveStaticFile(requestUrl) {
  const rawPath = decodeURIComponent((requestUrl || "/").split("?")[0]);
  const relativePath = rawPath.replace(/^\/+/, "") || "index.html";
  let filePath = path.resolve(BUILD_DIR, relativePath);

  if (!filePath.startsWith(BUILD_DIR)) return null;
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(BUILD_DIR, "index.html");
  }

  return filePath;
}

const server = http.createServer((request, response) => {
  const filePath = resolveStaticFile(request.url);
  if (!filePath) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  response.writeHead(200, {
    "Content-Type": MIME_TYPES[path.extname(filePath).toLowerCase()] || "application/octet-stream",
  });
  fs.createReadStream(filePath).pipe(response);
});

server.listen(PORT, HOST, () => {
  console.log(`FRAMEANA static frontend: http://${HOST}:${PORT}`);
  console.log(`Build: ${BUILD_DIR}`);
});
