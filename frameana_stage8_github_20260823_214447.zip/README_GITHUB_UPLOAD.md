# FRAMEANA GitHub Backup

This package is prepared for backing up FRAMEANA source code, backend code, and database setup files to GitHub.

## Recommended GitHub Contents

Commit source code and reproducible setup files:

```powershell
git add .
git commit -m "Backup FRAMEANA Stage 8 platform"
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```

## Database

The backend database lives locally at:

```text
D:\FRAMEANA\data\frameana.sqlite
```

Use this command to export a consistent SQLite backup and SQL dump:

```powershell
node scripts/export_frameana_db.js
```

Use this command to restore from a SQL dump:

```powershell
node scripts/load_frameana_db_from_dump.js database/frameana_full_dump.sql D:\FRAMEANA\data\frameana.sqlite
```

## Important

Do not commit real production secrets or private user data to a public GitHub repo.

Keep these local unless you intentionally want a private backup:

```text
src/segmind_api_key.txt
src/.env
src/backend/.env
*.sqlite
*.sqlite-wal
*.sqlite-shm
database/frameana_full_dump.sql
database/frameana_data.sql
```

For a public repo, commit only `database/frameana_schema.sql` and the loader/export scripts.
