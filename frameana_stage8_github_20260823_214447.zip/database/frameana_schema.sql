CREATE TABLE order_status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      status INTEGER NOT NULL,
      changed_by_user_id INTEGER,
      actor_type TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (changed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
    );
CREATE TABLE orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE,
      user_id INTEGER NOT NULL,
      status INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      submitted_at TEXT,
      frame_style TEXT,
      frame_color TEXT,
      material TEXT,
      engraving_text TEXT,
      engraving_color TEXT,
      face_width REAL,
      eye_distance REAL,
      nose_width REAL,
      head_angle REAL,
      tryon_image TEXT,
      frame_front_image TEXT,
      frame_side_image TEXT,
      frame_front_stl TEXT,
      left_arm_stl TEXT,
      right_arm_stl TEXT,
      full_frame_stl TEXT,
      metadata_json TEXT,
      feedback_text TEXT,
      job_id TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      is_admin INTEGER NOT NULL DEFAULT 0
    );
CREATE INDEX idx_order_status_history_order ON order_status_history(order_id, created_at);
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_users_email ON users(email);
