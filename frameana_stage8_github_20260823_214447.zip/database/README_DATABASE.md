# FRAMEANA Database

The local Stage 8 SQLite database defaults to:

```text
D:\FRAMEANA\data\frameana.sqlite
```

Use the export script:

```powershell
node scripts/export_frameana_db.js
```

Use the restore script:

```powershell
node scripts/load_frameana_db_from_dump.js database/frameana_full_dump.sql D:\FRAMEANA\data\frameana.sqlite
```

For public GitHub repositories, commit the schema and scripts only. Keep real user data, password hashes, images, and full dumps private unless the repository is private and intentionally used as a backup.
