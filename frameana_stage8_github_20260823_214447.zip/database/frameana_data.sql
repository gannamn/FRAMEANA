PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO "order_status_history" ("id", "order_id", "status", "changed_by_user_id", "actor_type", "note", "created_at") VALUES (1, 1, 1, 1, 'client', 'Saved as new design', '2026-08-17T02:49:25.541Z');
INSERT INTO "order_status_history" ("id", "order_id", "status", "changed_by_user_id", "actor_type", "note", "created_at") VALUES (2, 1, 2, 1, 'client', 'Submitted', '2026-08-22T17:24:22.163Z');
INSERT INTO "order_status_history" ("id", "order_id", "status", "changed_by_user_id", "actor_type", "note", "created_at") VALUES (3, 2, 1, 1, 'client', 'تم الحفظ كتصميم جديد', '2026-08-22T18:37:50.568Z');
INSERT INTO "order_status_history" ("id", "order_id", "status", "changed_by_user_id", "actor_type", "note", "created_at") VALUES (4, 3, 1, 1, 'client', 'تم الحفظ كتصميم جديد', '2026-08-22T19:03:57.419Z');
INSERT INTO "order_status_history" ("id", "order_id", "status", "changed_by_user_id", "actor_type", "note", "created_at") VALUES (5, 4, 1, 1, 'client', 'تم الحفظ كتصميم جديد', '2026-08-22T19:05:25.910Z');
INSERT INTO "orders" ("id", "order_number", "user_id", "status", "created_at", "updated_at", "submitted_at", "frame_style", "frame_color", "material", "engraving_text", "engraving_color", "face_width", "eye_distance", "nose_width", "head_angle", "tryon_image", "frame_front_image", "frame_side_image", "frame_front_stl", "left_arm_stl", "right_arm_stl", "full_frame_stl", "metadata_json", "feedback_text", "job_id") VALUES (1, 'FR-00001', 1, 2, '2026-08-17T02:49:25.535Z', '2026-08-22T17:24:22.162Z', '2026-08-22T17:24:22.162Z', 'classic', 'tortoise', 'acetate', 'Nael', '#C9A14A', NULL, NULL, NULL, NULL, 'http://localhost:8080/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/customer_tryon.png', 'http://localhost:8080/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_orthographic_views.png', '/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_orthographic_views.png', '/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_front.stl', '/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/left_arm.stl', '/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/right_arm.stl', '/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/full_frame.stl', '{
  "config": {
    "model": "classic",
    "material": "acetate",
    "frameColor": "#1F2D57",
    "engravingColor": "#C9A14A",
    "engraving": "Nael"
  },
  "metadata": {
    "stage": "FRAMEANA Stage 2C-6",
    "generated_at": "2026-08-17T02:49:20.210Z",
    "generator": {
      "file": "C:\\Users\\Dell\\glasses-app\\src\\frameana\\src\\backend\\frameana_image2stl_generator.js",
      "runtime": "v24.15.0",
      "dependencies": "none",
      "units": "millimeters",
      "stl_format": "binary",
      "geometry_source": "accepted_ai_cad_reference_2d_silhouette_extrusion",
      "uses_ai_image_generation_during_stl_step": false,
      "pixel_edge_repair": {
        "front_refine_scale": 3,
        "side_refine_scale": 1,
        "front_smooth_sidewalls": true,
        "decorative_front_rivets": false,
        "preview_supersample": 3,
        "preview_edge_cleanup": true,
        "gap_repair": "fills one-pixel horizontal, vertical, and diagonal breaks before STL extrusion"
      }
    },
    "source_inputs": {
      "reference_image": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\ai_frame_reference.png",
      "image_size_px": {
        "width": 1024,
        "height": 1024
      },
      "front_crop_px": {
        "x": 45,
        "y": 86,
        "width": 935,
        "height": 408
      },
      "side_crop_px": {
        "x": 188,
        "y": 600,
        "width": 780,
        "height": 298
      }
    },
    "style_options": {
      "frame_color": "tortoise",
      "material": "acetate",
      "frame_shape": "classic",
      "arm_text": "Nael",
      "arm_text_color": "#C9A14A",
      "text_mode": "emboss"
    },
    "appearance": {
      "frame_color": "tortoise",
      "frame_color_css": "#6B3A18",
      "engraving_color": "#C9A14A",
      "engraving_color_css": "#C9A14A"
    },
    "geometry_profile": {
      "principle": "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      "front": {
        "cell_mm": 0.061484409310496264,
        "target_width_mm": 140,
        "target_height_mm": 46.48221343873517,
        "depth_mm": 4.6,
        "cap_inset_px": 6,
        "cap_inset_mm": 0.3689064558629776,
        "sidewall_method": "smoothed_contour",
        "contour_loops": 5,
        "contour_segments": 7310,
        "contour_smooth_iterations": 4,
        "contour_face_cover_strips": 14620,
        "contour_cover_width_mm": 0.75,
        "trace_info": {
          "crop_px": {
            "x": 45,
            "y": 86,
            "width": 935,
            "height": 408
          },
          "source_grid_px": {
            "width": 760,
            "height": 332
          },
          "trace_grid_px": {
            "width": 2277,
            "height": 756
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 0,
            "max_x": 2276,
            "max_y": 755
          },
          "pixel_smoothing": {
            "applied": true,
            "refine_scale": 3,
            "source_trace_grid_px": {
              "width": 759,
              "height": 252
            },
            "refined_trace_grid_px": {
              "width": 2277,
              "height": 756
            }
          },
          "background_rgba": [
            254.71,
            254.37,
            254.68,
            255
          ],
          "foreground_pixels_raw": 46584,
          "foreground_pixels_final": 419857,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 419857
        }
      },
      "side_arm": {
        "cell_mm": 0.20597014925373133,
        "target_length_mm": 138,
        "target_height_mm": 42.01791044776119,
        "thickness_mm": 3.7,
        "x_center_mm": 68.65609354413701,
        "y_offset_mm": -5,
        "z_start_mm": -0.9499999999999997,
        "side": 1,
        "trace_info": {
          "crop_px": {
            "x": 188,
            "y": 600,
            "width": 780,
            "height": 298
          },
          "source_grid_px": {
            "width": 670,
            "height": 256
          },
          "trace_grid_px": {
            "width": 670,
            "height": 204
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 8,
            "max_x": 669,
            "max_y": 211
          },
          "pixel_smoothing": {
            "refine_scale": 1,
            "applied": false
          },
          "background_rgba": [
            254.62,
            254.43,
            254.57,
            255
          ],
          "foreground_pixels_raw": 29238,
          "foreground_pixels_final": 29238,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 29238
        },
        "hinge_connection": {
          "method": "arm_depth_overlap_without_extra_blocks",
          "right_contact_x_mm": 66.8061,
          "left_contact_x_mm": -66.8061,
          "y_offset_mm": -5,
          "lowered_from_previous_mm": 3.2,
          "z_start_mm": -0.95,
          "front_back_z_mm": -2.3,
          "overlap_mm": 1.35
        },
        "text_geometry": {
          "side_emboss": {
            "text": "Nael",
            "surface": "outside_right_arm",
            "start_z_mm": -16.5,
            "base_y_mm": 5.25,
            "height_mm": 5.2,
            "max_length_mm": 64,
            "rendered_length_mm": 10.897120000000001,
            "relief_mm": 1.1,
            "stroke_count": 13
          }
        }
      },
      "limitations": [
        "STL stores geometry only; selected colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace."
      ]
    },
    "frontend_assets": {
      "reference_2d": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\ai_frame_reference.png",
      "preview_png": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_3d_preview.png",
      "front_trace_png": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_front_trace.png",
      "side_trace_png": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_side_trace.png"
    },
    "frontend_manifest": {
      "reference_2d": "ai_frame_reference.png",
      "preview_png": "frameana_image2stl_3d_preview.png",
      "traces": {
        "front_png": "frameana_image2stl_front_trace.png",
        "side_png": "frameana_image2stl_side_trace.png",
        "front_svg": "frameana_image2stl_front_trace.svg",
        "side_svg": "frameana_image2stl_side_trace.svg"
      },
      "stl": {
        "frame_front": "frame_front.stl",
        "left_arm": "left_arm.stl",
        "right_arm": "right_arm.stl",
        "full_frame": "full_frame.stl",
        "engraving": "engraving.stl"
      },
      "metadata": "frame_metadata.json"
    },
    "outputs": {
      "frame_front": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frame_front.stl",
        "bytes": 2733284,
        "triangles": 54664,
        "bounds_mm": {
          "min": [
            -70.375,
            -23.2472,
            -2.335
          ],
          "max": [
            70.0061,
            23.2472,
            2.335
          ],
          "size": [
            140.3811,
            46.4944,
            4.67
          ]
        }
      },
      "left_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\left_arm.stl",
        "bytes": 6022684,
        "triangles": 120452,
        "bounds_mm": {
          "min": [
            -70.5061,
            -25.597,
            -138.95
          ],
          "max": [
            -66.8061,
            15.597,
            -0.95
          ],
          "size": [
            3.7,
            41.194,
            138
          ]
        }
      },
      "right_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\right_arm.stl",
        "bytes": 6030484,
        "triangles": 120608,
        "bounds_mm": {
          "min": [
            66.8061,
            -25.597,
            -138.95
          ],
          "max": [
            71.6461,
            15.597,
            -0.95
          ],
          "size": [
            4.84,
            41.194,
            138
          ]
        }
      },
      "full_frame": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\full_frame.stl",
        "bytes": 14786284,
        "triangles": 295724,
        "bounds_mm": {
          "min": [
            -70.5061,
            -25.597,
            -138.95
          ],
          "max": [
            71.6461,
            23.2472,
            2.335
          ],
          "size": [
            142.1522,
            48.8442,
            141.285
          ]
        }
      },
      "front_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_front_trace.svg",
        "bytes": 124502
      },
      "side_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_side_trace.svg",
        "bytes": 9438
      },
      "front_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_front_trace.png",
        "bytes": 25511
      },
      "side_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_side_trace.png",
        "bytes": 2089
      },
      "preview_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\frameana_image2stl_3d_preview.png",
        "bytes": 100689
      },
      "engraving": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7\\output\\engraving.stl",
        "bytes": 7884,
        "triangles": 156,
        "bounds_mm": {
          "min": [
            70.5461,
            5.191,
            -26.9968
          ],
          "max": [
            71.6461,
            10.509,
            -16.7069
          ],
          "size": [
            1.1,
            5.3181,
            10.2899
          ]
        }
      }
    },
    "job_id": "1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7",
    "style": "classic",
    "material": "acetate",
    "frame_color": "tortoise",
    "engraving_text": "Nael",
    "engraving_color": "#C9A14A",
    "customization": {
      "style": "classic",
      "material": "acetate",
      "frame_color": "tortoise",
      "engraving": "Nael",
      "engraving_color": "#C9A14A"
    },
    "stage2c6_assets": {
      "customer_tryon": "customer_tryon.png",
      "frame_orthographic": "frame_orthographic_views.png",
      "frame_3d_preview": "frame_preview.png",
      "front_trace": "frameana_image2stl_front_trace.png",
      "side_trace": "frameana_image2stl_side_trace.png",
      "engraving_stl": "engraving.stl"
    }
  },
  "outputs": {
    "customer_tryon": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/customer_tryon.png",
    "frame_preview": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_orthographic_views.png",
    "frame_orthographic": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_orthographic_views.png",
    "frame_3d_preview": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_preview.png",
    "frame_front_trace": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frameana_image2stl_front_trace.png",
    "frame_side_trace": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frameana_image2stl_side_trace.png",
    "frame_metadata": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_metadata.json",
    "frame_front": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/frame_front.stl",
    "left_arm": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/left_arm.stl",
    "right_arm": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/right_arm.stl",
    "full_frame": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/full_frame.stl",
    "engraving_stl": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/engraving.stl",
    "engraving": "/outputs/1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7/output/engraving.stl"
  },
  "job_id": "1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7"
}', NULL, '1786934882112-f453bfaa-347c-42a1-8429-eadb269cf2c7');
INSERT INTO "orders" ("id", "order_number", "user_id", "status", "created_at", "updated_at", "submitted_at", "frame_style", "frame_color", "material", "engraving_text", "engraving_color", "face_width", "eye_distance", "nose_width", "head_angle", "tryon_image", "frame_front_image", "frame_side_image", "frame_front_stl", "left_arm_stl", "right_arm_stl", "full_frame_stl", "metadata_json", "feedback_text", "job_id") VALUES (2, 'FR-00002', 1, 1, '2026-08-22T18:37:50.565Z', '2026-08-22T18:37:50.565Z', NULL, 'classic', 'tortoise', 'acetate', 'Nael', '#C9A14A', NULL, NULL, NULL, NULL, 'http://localhost:8080/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/customer_tryon.png', 'http://localhost:8080/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_orthographic_views.png', '/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_orthographic_views.png', '/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_front.stl', '/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/left_arm.stl', '/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/right_arm.stl', '/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/full_frame.stl', '{
  "config": {
    "model": "classic",
    "material": "acetate",
    "frameColor": "#1F2D57",
    "engravingColor": "#C9A14A",
    "engraving": "Nael"
  },
  "metadata": {
    "stage": "FRAMEANA Stage 2C-6",
    "generated_at": "2026-08-22T18:37:43.118Z",
    "generator": {
      "file": "C:\\Users\\Dell\\glasses-app\\src\\frameana\\src\\backend\\frameana_image2stl_generator.js",
      "runtime": "v24.15.0",
      "dependencies": "none",
      "units": "millimeters",
      "stl_format": "binary",
      "geometry_source": "accepted_ai_cad_reference_2d_silhouette_extrusion",
      "uses_ai_image_generation_during_stl_step": false,
      "pixel_edge_repair": {
        "front_refine_scale": 3,
        "side_refine_scale": 1,
        "front_smooth_sidewalls": true,
        "decorative_front_rivets": false,
        "preview_supersample": 3,
        "preview_edge_cleanup": true,
        "gap_repair": "fills one-pixel horizontal, vertical, and diagonal breaks before STL extrusion"
      }
    },
    "source_inputs": {
      "reference_image": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\ai_frame_reference.png",
      "image_size_px": {
        "width": 1024,
        "height": 1024
      },
      "front_crop_px": {
        "x": 45,
        "y": 86,
        "width": 935,
        "height": 408
      },
      "side_crop_px": {
        "x": 188,
        "y": 600,
        "width": 780,
        "height": 298
      }
    },
    "style_options": {
      "frame_color": "tortoise",
      "material": "acetate",
      "frame_shape": "classic",
      "arm_text": "Nael",
      "arm_text_color": "#C9A14A",
      "text_mode": "emboss"
    },
    "appearance": {
      "frame_color": "tortoise",
      "frame_color_css": "#6B3A18",
      "engraving_color": "#C9A14A",
      "engraving_color_css": "#C9A14A"
    },
    "geometry_profile": {
      "principle": "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      "front": {
        "cell_mm": 0.06140350877192982,
        "target_width_mm": 140,
        "target_height_mm": 47.71052631578947,
        "depth_mm": 4.6,
        "cap_inset_px": 6,
        "cap_inset_mm": 0.3684210526315789,
        "sidewall_method": "smoothed_contour",
        "contour_loops": 6,
        "contour_segments": 7578,
        "contour_smooth_iterations": 4,
        "contour_face_cover_strips": 15156,
        "contour_cover_width_mm": 0.75,
        "trace_info": {
          "crop_px": {
            "x": 45,
            "y": 86,
            "width": 935,
            "height": 408
          },
          "source_grid_px": {
            "width": 760,
            "height": 332
          },
          "trace_grid_px": {
            "width": 2280,
            "height": 777
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 0,
            "max_x": 2279,
            "max_y": 776
          },
          "pixel_smoothing": {
            "applied": true,
            "refine_scale": 3,
            "source_trace_grid_px": {
              "width": 760,
              "height": 259
            },
            "refined_trace_grid_px": {
              "width": 2280,
              "height": 777
            }
          },
          "background_rgba": [
            254.81,
            254.47,
            254.75,
            255
          ],
          "foreground_pixels_raw": 46242,
          "foreground_pixels_final": 416846,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 416846
        }
      },
      "side_arm": {
        "cell_mm": 0.20597014925373133,
        "target_length_mm": 138,
        "target_height_mm": 45.72537313432836,
        "thickness_mm": 3.7,
        "x_center_mm": 69.02499999999999,
        "y_offset_mm": -5,
        "z_start_mm": -0.9499999999999997,
        "side": 1,
        "trace_info": {
          "crop_px": {
            "x": 188,
            "y": 600,
            "width": 780,
            "height": 298
          },
          "source_grid_px": {
            "width": 670,
            "height": 256
          },
          "trace_grid_px": {
            "width": 670,
            "height": 222
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 0,
            "max_x": 669,
            "max_y": 221
          },
          "pixel_smoothing": {
            "refine_scale": 1,
            "applied": false
          },
          "background_rgba": [
            254.6,
            254.32,
            254.6,
            255
          ],
          "foreground_pixels_raw": 31826,
          "foreground_pixels_final": 31829,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 31829
        },
        "hinge_connection": {
          "method": "arm_depth_overlap_without_extra_blocks",
          "right_contact_x_mm": 67.175,
          "left_contact_x_mm": -67.175,
          "y_offset_mm": -5,
          "lowered_from_previous_mm": 3.2,
          "z_start_mm": -0.95,
          "front_back_z_mm": -2.3,
          "overlap_mm": 1.35
        },
        "text_geometry": {
          "side_emboss": {
            "text": "Nael",
            "surface": "outside_right_arm",
            "start_z_mm": -16.5,
            "base_y_mm": 5.25,
            "height_mm": 5.2,
            "max_length_mm": 64,
            "rendered_length_mm": 10.897120000000001,
            "relief_mm": 1.1,
            "stroke_count": 13
          }
        }
      },
      "limitations": [
        "STL stores geometry only; selected colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace."
      ]
    },
    "frontend_assets": {
      "reference_2d": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\ai_frame_reference.png",
      "preview_png": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_3d_preview.png",
      "front_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_front_trace.png",
      "side_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_side_trace.png"
    },
    "frontend_manifest": {
      "reference_2d": "ai_frame_reference.png",
      "preview_png": "frameana_image2stl_3d_preview.png",
      "traces": {
        "front_png": "frameana_image2stl_front_trace.png",
        "side_png": "frameana_image2stl_side_trace.png",
        "front_svg": "frameana_image2stl_front_trace.svg",
        "side_svg": "frameana_image2stl_side_trace.svg"
      },
      "stl": {
        "frame_front": "frame_front.stl",
        "left_arm": "left_arm.stl",
        "right_arm": "right_arm.stl",
        "full_frame": "full_frame.stl",
        "engraving": "engraving.stl"
      },
      "metadata": "frame_metadata.json"
    },
    "outputs": {
      "frame_front": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frame_front.stl",
        "bytes": 2837084,
        "triangles": 56740,
        "bounds_mm": {
          "min": [
            -70.375,
            -23.8618,
            -2.335
          ],
          "max": [
            70.375,
            23.8618,
            2.335
          ],
          "size": [
            140.75,
            47.7237,
            4.67
          ]
        }
      },
      "left_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\left_arm.stl",
        "bytes": 6545684,
        "triangles": 130912,
        "bounds_mm": {
          "min": [
            -70.875,
            -27.4507,
            -138.95
          ],
          "max": [
            -67.175,
            17.8627,
            -0.95
          ],
          "size": [
            3.7,
            45.3134,
            138
          ]
        }
      },
      "right_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\right_arm.stl",
        "bytes": 6553484,
        "triangles": 131068,
        "bounds_mm": {
          "min": [
            67.175,
            -27.4507,
            -138.95
          ],
          "max": [
            72.015,
            17.8627,
            -0.95
          ],
          "size": [
            4.84,
            45.3134,
            138
          ]
        }
      },
      "full_frame": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\full_frame.stl",
        "bytes": 15936084,
        "triangles": 318720,
        "bounds_mm": {
          "min": [
            -70.875,
            -27.4507,
            -138.95
          ],
          "max": [
            72.015,
            23.8618,
            2.335
          ],
          "size": [
            142.89,
            51.3126,
            141.285
          ]
        }
      },
      "front_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_front_trace.svg",
        "bytes": 130129
      },
      "side_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_side_trace.svg",
        "bytes": 10527
      },
      "front_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_front_trace.png",
        "bytes": 25509
      },
      "side_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_side_trace.png",
        "bytes": 2150
      },
      "preview_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\frameana_image2stl_3d_preview.png",
        "bytes": 101989
      },
      "engraving": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787423794355-46b77b86-0632-4d99-9637-0742404f2cce\\output\\engraving.stl",
        "bytes": 7884,
        "triangles": 156,
        "bounds_mm": {
          "min": [
            70.915,
            5.191,
            -26.9968
          ],
          "max": [
            72.015,
            10.509,
            -16.7069
          ],
          "size": [
            1.1,
            5.3181,
            10.2899
          ]
        }
      }
    },
    "job_id": "1787423794355-46b77b86-0632-4d99-9637-0742404f2cce",
    "style": "classic",
    "material": "acetate",
    "frame_color": "tortoise",
    "engraving_text": "Nael",
    "engraving_color": "#C9A14A",
    "customization": {
      "style": "classic",
      "material": "acetate",
      "frame_color": "tortoise",
      "engraving": "Nael",
      "engraving_color": "#C9A14A"
    },
    "stage2c6_assets": {
      "customer_tryon": "customer_tryon.png",
      "frame_orthographic": "frame_orthographic_views.png",
      "frame_3d_preview": "frame_preview.png",
      "front_trace": "frameana_image2stl_front_trace.png",
      "side_trace": "frameana_image2stl_side_trace.png",
      "engraving_stl": "engraving.stl"
    }
  },
  "outputs": {
    "customer_tryon": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/customer_tryon.png",
    "frame_preview": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_orthographic_views.png",
    "frame_orthographic": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_orthographic_views.png",
    "frame_3d_preview": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_preview.png",
    "frame_front_trace": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frameana_image2stl_front_trace.png",
    "frame_side_trace": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frameana_image2stl_side_trace.png",
    "frame_metadata": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_metadata.json",
    "frame_front": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/frame_front.stl",
    "left_arm": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/left_arm.stl",
    "right_arm": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/right_arm.stl",
    "full_frame": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/full_frame.stl",
    "engraving_stl": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/engraving.stl",
    "engraving": "/outputs/1787423794355-46b77b86-0632-4d99-9637-0742404f2cce/output/engraving.stl"
  },
  "job_id": "1787423794355-46b77b86-0632-4d99-9637-0742404f2cce"
}', NULL, '1787423794355-46b77b86-0632-4d99-9637-0742404f2cce');
INSERT INTO "orders" ("id", "order_number", "user_id", "status", "created_at", "updated_at", "submitted_at", "frame_style", "frame_color", "material", "engraving_text", "engraving_color", "face_width", "eye_distance", "nose_width", "head_angle", "tryon_image", "frame_front_image", "frame_side_image", "frame_front_stl", "left_arm_stl", "right_arm_stl", "full_frame_stl", "metadata_json", "feedback_text", "job_id") VALUES (3, 'FR-00003', 1, 1, '2026-08-22T19:03:57.417Z', '2026-08-22T19:03:57.417Z', NULL, 'round', 'tortoise', 'acetate', 'Nael', '#C9A14A', NULL, NULL, NULL, NULL, 'http://localhost:8080/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/customer_tryon.png', 'http://localhost:8080/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_orthographic_views.png', '/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_orthographic_views.png', '/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_front.stl', '/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/left_arm.stl', '/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/right_arm.stl', '/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/full_frame.stl', '{
  "config": {
    "model": "round",
    "material": "acetate",
    "frameColor": "#1F2D57",
    "engravingColor": "#C9A14A",
    "engraving": "Nael"
  },
  "metadata": {
    "stage": "FRAMEANA Stage 2C-6",
    "generated_at": "2026-08-22T19:03:50.505Z",
    "generator": {
      "file": "C:\\Users\\Dell\\glasses-app\\src\\frameana\\src\\backend\\frameana_image2stl_generator.js",
      "runtime": "v24.15.0",
      "dependencies": "none",
      "units": "millimeters",
      "stl_format": "binary",
      "geometry_source": "accepted_ai_cad_reference_2d_silhouette_extrusion",
      "uses_ai_image_generation_during_stl_step": false,
      "pixel_edge_repair": {
        "front_refine_scale": 3,
        "side_refine_scale": 1,
        "front_smooth_sidewalls": true,
        "decorative_front_rivets": false,
        "preview_supersample": 3,
        "preview_edge_cleanup": true,
        "gap_repair": "fills one-pixel horizontal, vertical, and diagonal breaks before STL extrusion"
      }
    },
    "source_inputs": {
      "reference_image": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\ai_frame_reference.png",
      "image_size_px": {
        "width": 1024,
        "height": 1024
      },
      "front_crop_px": {
        "x": 45,
        "y": 86,
        "width": 935,
        "height": 408
      },
      "side_crop_px": {
        "x": 188,
        "y": 600,
        "width": 780,
        "height": 298
      }
    },
    "style_options": {
      "frame_color": "tortoise",
      "material": "acetate",
      "frame_shape": "round",
      "arm_text": "Nael",
      "arm_text_color": "#C9A14A",
      "text_mode": "emboss"
    },
    "appearance": {
      "frame_color": "tortoise",
      "frame_color_css": "#6B3A18",
      "engraving_color": "#C9A14A",
      "engraving_color_css": "#C9A14A"
    },
    "geometry_profile": {
      "principle": "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      "front": {
        "cell_mm": 0.06140350877192982,
        "target_width_mm": 140,
        "target_height_mm": 47.1578947368421,
        "depth_mm": 4.6,
        "cap_inset_px": 6,
        "cap_inset_mm": 0.3684210526315789,
        "sidewall_method": "smoothed_contour",
        "contour_loops": 3,
        "contour_segments": 7262,
        "contour_smooth_iterations": 4,
        "contour_face_cover_strips": 14524,
        "contour_cover_width_mm": 0.75,
        "trace_info": {
          "crop_px": {
            "x": 45,
            "y": 86,
            "width": 935,
            "height": 408
          },
          "source_grid_px": {
            "width": 760,
            "height": 332
          },
          "trace_grid_px": {
            "width": 2280,
            "height": 768
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 0,
            "max_x": 2279,
            "max_y": 767
          },
          "pixel_smoothing": {
            "applied": true,
            "refine_scale": 3,
            "source_trace_grid_px": {
              "width": 760,
              "height": 256
            },
            "refined_trace_grid_px": {
              "width": 2280,
              "height": 768
            }
          },
          "background_rgba": [
            254.78,
            254.44,
            254.73,
            255
          ],
          "foreground_pixels_raw": 36805,
          "foreground_pixels_final": 331626,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 331626
        }
      },
      "side_arm": {
        "cell_mm": 0.20597014925373133,
        "target_length_mm": 138,
        "target_height_mm": 37.07462686567164,
        "thickness_mm": 3.7,
        "x_center_mm": 69.02499999999999,
        "y_offset_mm": -5,
        "z_start_mm": -0.9499999999999997,
        "side": 1,
        "trace_info": {
          "crop_px": {
            "x": 188,
            "y": 600,
            "width": 780,
            "height": 298
          },
          "source_grid_px": {
            "width": 670,
            "height": 256
          },
          "trace_grid_px": {
            "width": 670,
            "height": 180
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 38,
            "max_x": 669,
            "max_y": 217
          },
          "pixel_smoothing": {
            "refine_scale": 1,
            "applied": false
          },
          "background_rgba": [
            254.51,
            254.3,
            254.49,
            255
          ],
          "foreground_pixels_raw": 22226,
          "foreground_pixels_final": 22226,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 22226
        },
        "hinge_connection": {
          "method": "arm_depth_overlap_without_extra_blocks",
          "right_contact_x_mm": 67.175,
          "left_contact_x_mm": -67.175,
          "y_offset_mm": -5,
          "lowered_from_previous_mm": 3.2,
          "z_start_mm": -0.95,
          "front_back_z_mm": -2.3,
          "overlap_mm": 1.35
        },
        "text_geometry": {
          "side_emboss": {
            "text": "Nael",
            "surface": "outside_right_arm",
            "start_z_mm": -16.5,
            "base_y_mm": 5.25,
            "height_mm": 5.2,
            "max_length_mm": 64,
            "rendered_length_mm": 10.897120000000001,
            "relief_mm": 1.1,
            "stroke_count": 13
          }
        }
      },
      "limitations": [
        "STL stores geometry only; selected colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace."
      ]
    },
    "frontend_assets": {
      "reference_2d": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\ai_frame_reference.png",
      "preview_png": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_3d_preview.png",
      "front_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_front_trace.png",
      "side_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_side_trace.png"
    },
    "frontend_manifest": {
      "reference_2d": "ai_frame_reference.png",
      "preview_png": "frameana_image2stl_3d_preview.png",
      "traces": {
        "front_png": "frameana_image2stl_front_trace.png",
        "side_png": "frameana_image2stl_side_trace.png",
        "front_svg": "frameana_image2stl_front_trace.svg",
        "side_svg": "frameana_image2stl_side_trace.svg"
      },
      "stl": {
        "frame_front": "frame_front.stl",
        "left_arm": "left_arm.stl",
        "right_arm": "right_arm.stl",
        "full_frame": "full_frame.stl",
        "engraving": "engraving.stl"
      },
      "metadata": "frame_metadata.json"
    },
    "outputs": {
      "frame_front": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frame_front.stl",
        "bytes": 2755484,
        "triangles": 55108,
        "bounds_mm": {
          "min": [
            -70.375,
            -23.9539,
            -2.335
          ],
          "max": [
            70.375,
            23.5855,
            2.335
          ],
          "size": [
            140.75,
            47.5395,
            4.67
          ]
        }
      },
      "left_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\left_arm.stl",
        "bytes": 4614884,
        "triangles": 92296,
        "bounds_mm": {
          "min": [
            -70.875,
            -23.1254,
            -138.95
          ],
          "max": [
            -67.175,
            13.1254,
            -0.95
          ],
          "size": [
            3.7,
            36.2507,
            138
          ]
        }
      },
      "right_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\right_arm.stl",
        "bytes": 4622684,
        "triangles": 92452,
        "bounds_mm": {
          "min": [
            67.175,
            -23.1254,
            -138.95
          ],
          "max": [
            72.015,
            13.1254,
            -0.95
          ],
          "size": [
            4.84,
            36.2507,
            138
          ]
        }
      },
      "full_frame": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\full_frame.stl",
        "bytes": 11992884,
        "triangles": 239856,
        "bounds_mm": {
          "min": [
            -70.875,
            -23.9539,
            -138.95
          ],
          "max": [
            72.015,
            23.5855,
            2.335
          ],
          "size": [
            142.89,
            47.5395,
            141.285
          ]
        }
      },
      "front_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_front_trace.svg",
        "bytes": 134914
      },
      "side_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_side_trace.svg",
        "bytes": 8206
      },
      "front_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_front_trace.png",
        "bytes": 25957
      },
      "side_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_side_trace.png",
        "bytes": 1682
      },
      "preview_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\frameana_image2stl_3d_preview.png",
        "bytes": 95683
      },
      "engraving": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9\\output\\engraving.stl",
        "bytes": 7884,
        "triangles": 156,
        "bounds_mm": {
          "min": [
            70.915,
            5.191,
            -26.9968
          ],
          "max": [
            72.015,
            10.509,
            -16.7069
          ],
          "size": [
            1.1,
            5.3181,
            10.2899
          ]
        }
      }
    },
    "job_id": "1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9",
    "style": "round",
    "material": "acetate",
    "frame_color": "tortoise",
    "engraving_text": "Nael",
    "engraving_color": "#C9A14A",
    "customization": {
      "style": "round",
      "material": "acetate",
      "frame_color": "tortoise",
      "engraving": "Nael",
      "engraving_color": "#C9A14A"
    },
    "stage2c6_assets": {
      "customer_tryon": "customer_tryon.png",
      "frame_orthographic": "frame_orthographic_views.png",
      "frame_3d_preview": "frame_preview.png",
      "front_trace": "frameana_image2stl_front_trace.png",
      "side_trace": "frameana_image2stl_side_trace.png",
      "engraving_stl": "engraving.stl"
    }
  },
  "outputs": {
    "customer_tryon": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/customer_tryon.png",
    "frame_preview": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_orthographic_views.png",
    "frame_orthographic": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_orthographic_views.png",
    "frame_3d_preview": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_preview.png",
    "frame_front_trace": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frameana_image2stl_front_trace.png",
    "frame_side_trace": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frameana_image2stl_side_trace.png",
    "frame_metadata": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_metadata.json",
    "frame_front": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/frame_front.stl",
    "left_arm": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/left_arm.stl",
    "right_arm": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/right_arm.stl",
    "full_frame": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/full_frame.stl",
    "engraving_stl": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/engraving.stl",
    "engraving": "/outputs/1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9/output/engraving.stl"
  },
  "job_id": "1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9"
}', NULL, '1787425366361-95299be9-ab2a-46fc-8bca-f41f8cf567c9');
INSERT INTO "orders" ("id", "order_number", "user_id", "status", "created_at", "updated_at", "submitted_at", "frame_style", "frame_color", "material", "engraving_text", "engraving_color", "face_width", "eye_distance", "nose_width", "head_angle", "tryon_image", "frame_front_image", "frame_side_image", "frame_front_stl", "left_arm_stl", "right_arm_stl", "full_frame_stl", "metadata_json", "feedback_text", "job_id") VALUES (4, 'FR-00004', 1, 1, '2026-08-22T19:05:25.908Z', '2026-08-22T19:05:25.908Z', NULL, 'sport', 'tortoise', 'acetate', 'Nael', '#C9A14A', NULL, NULL, NULL, NULL, 'http://localhost:8080/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/customer_tryon.png', 'http://localhost:8080/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_orthographic_views.png', '/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_orthographic_views.png', '/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_front.stl', '/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/left_arm.stl', '/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/right_arm.stl', '/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/full_frame.stl', '{
  "config": {
    "model": "sport",
    "material": "acetate",
    "frameColor": "#1F2D57",
    "engravingColor": "#C9A14A",
    "engraving": "Nael"
  },
  "metadata": {
    "stage": "FRAMEANA Stage 2C-6",
    "generated_at": "2026-08-22T19:05:11.528Z",
    "generator": {
      "file": "C:\\Users\\Dell\\glasses-app\\src\\frameana\\src\\backend\\frameana_image2stl_generator.js",
      "runtime": "v24.15.0",
      "dependencies": "none",
      "units": "millimeters",
      "stl_format": "binary",
      "geometry_source": "accepted_ai_cad_reference_2d_silhouette_extrusion",
      "uses_ai_image_generation_during_stl_step": false,
      "pixel_edge_repair": {
        "front_refine_scale": 3,
        "side_refine_scale": 1,
        "front_smooth_sidewalls": true,
        "decorative_front_rivets": false,
        "preview_supersample": 3,
        "preview_edge_cleanup": true,
        "gap_repair": "fills one-pixel horizontal, vertical, and diagonal breaks before STL extrusion"
      }
    },
    "source_inputs": {
      "reference_image": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\ai_frame_reference.png",
      "image_size_px": {
        "width": 1024,
        "height": 1024
      },
      "front_crop_px": {
        "x": 45,
        "y": 86,
        "width": 935,
        "height": 408
      },
      "side_crop_px": {
        "x": 188,
        "y": 600,
        "width": 780,
        "height": 298
      }
    },
    "style_options": {
      "frame_color": "tortoise",
      "material": "acetate",
      "frame_shape": "sport",
      "arm_text": "Nael",
      "arm_text_color": "#C9A14A",
      "text_mode": "emboss"
    },
    "appearance": {
      "frame_color": "tortoise",
      "frame_color_css": "#6B3A18",
      "engraving_color": "#C9A14A",
      "engraving_color_css": "#C9A14A"
    },
    "geometry_profile": {
      "principle": "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      "front": {
        "cell_mm": 0.06140350877192982,
        "target_width_mm": 140,
        "target_height_mm": 42.55263157894736,
        "depth_mm": 4.6,
        "cap_inset_px": 6,
        "cap_inset_mm": 0.3684210526315789,
        "sidewall_method": "smoothed_contour",
        "contour_loops": 3,
        "contour_segments": 7131,
        "contour_smooth_iterations": 4,
        "contour_face_cover_strips": 14262,
        "contour_cover_width_mm": 0.75,
        "trace_info": {
          "crop_px": {
            "x": 45,
            "y": 86,
            "width": 935,
            "height": 408
          },
          "source_grid_px": {
            "width": 760,
            "height": 332
          },
          "trace_grid_px": {
            "width": 2280,
            "height": 693
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 0,
            "max_x": 2279,
            "max_y": 692
          },
          "pixel_smoothing": {
            "applied": true,
            "refine_scale": 3,
            "source_trace_grid_px": {
              "width": 760,
              "height": 231
            },
            "refined_trace_grid_px": {
              "width": 2280,
              "height": 693
            }
          },
          "background_rgba": [
            254.69,
            254.42,
            254.71,
            255
          ],
          "foreground_pixels_raw": 46712,
          "foreground_pixels_final": 420862,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 420862
        }
      },
      "side_arm": {
        "cell_mm": 0.20597014925373133,
        "target_length_mm": 138,
        "target_height_mm": 39.95820895522388,
        "thickness_mm": 3.7,
        "x_center_mm": 69.02499999999999,
        "y_offset_mm": -5,
        "z_start_mm": -0.9499999999999997,
        "side": 1,
        "trace_info": {
          "crop_px": {
            "x": 188,
            "y": 600,
            "width": 780,
            "height": 298
          },
          "source_grid_px": {
            "width": 670,
            "height": 256
          },
          "trace_grid_px": {
            "width": 670,
            "height": 194
          },
          "bounds_px": {
            "min_x": 0,
            "min_y": 5,
            "max_x": 669,
            "max_y": 198
          },
          "pixel_smoothing": {
            "refine_scale": 1,
            "applied": false
          },
          "background_rgba": [
            254.53,
            254.34,
            254.53,
            255
          ],
          "foreground_pixels_raw": 30618,
          "foreground_pixels_final": 30618,
          "components_total": 1,
          "components_kept": 1,
          "largest_component_pixels": 30618
        },
        "hinge_connection": {
          "method": "arm_depth_overlap_without_extra_blocks",
          "right_contact_x_mm": 67.175,
          "left_contact_x_mm": -67.175,
          "y_offset_mm": -5,
          "lowered_from_previous_mm": 3.2,
          "z_start_mm": -0.95,
          "front_back_z_mm": -2.3,
          "overlap_mm": 1.35
        },
        "text_geometry": {
          "side_emboss": {
            "text": "Nael",
            "surface": "outside_right_arm",
            "start_z_mm": -16.5,
            "base_y_mm": 5.25,
            "height_mm": 5.2,
            "max_length_mm": 64,
            "rendered_length_mm": 10.897120000000001,
            "relief_mm": 1.1,
            "stroke_count": 13
          }
        }
      },
      "limitations": [
        "STL stores geometry only; selected colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace."
      ]
    },
    "frontend_assets": {
      "reference_2d": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\ai_frame_reference.png",
      "preview_png": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_3d_preview.png",
      "front_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_front_trace.png",
      "side_trace_png": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_side_trace.png"
    },
    "frontend_manifest": {
      "reference_2d": "ai_frame_reference.png",
      "preview_png": "frameana_image2stl_3d_preview.png",
      "traces": {
        "front_png": "frameana_image2stl_front_trace.png",
        "side_png": "frameana_image2stl_side_trace.png",
        "front_svg": "frameana_image2stl_front_trace.svg",
        "side_svg": "frameana_image2stl_side_trace.svg"
      },
      "stl": {
        "frame_front": "frame_front.stl",
        "left_arm": "left_arm.stl",
        "right_arm": "right_arm.stl",
        "full_frame": "full_frame.stl",
        "engraving": "engraving.stl"
      },
      "metadata": "frame_metadata.json"
    },
    "outputs": {
      "frame_front": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frame_front.stl",
        "bytes": 2603984,
        "triangles": 52078,
        "bounds_mm": {
          "min": [
            -70.375,
            -21.2829,
            -2.335
          ],
          "max": [
            70.375,
            21.2829,
            2.335
          ],
          "size": [
            140.75,
            42.5658,
            4.67
          ]
        }
      },
      "left_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\left_arm.stl",
        "bytes": 6296684,
        "triangles": 125932,
        "bounds_mm": {
          "min": [
            -70.875,
            -24.5672,
            -138.95
          ],
          "max": [
            -67.175,
            14.5672,
            -0.95
          ],
          "size": [
            3.7,
            39.1343,
            138
          ]
        }
      },
      "right_arm": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\right_arm.stl",
        "bytes": 6304484,
        "triangles": 126088,
        "bounds_mm": {
          "min": [
            67.175,
            -24.5672,
            -138.95
          ],
          "max": [
            72.015,
            14.5672,
            -0.95
          ],
          "size": [
            4.84,
            39.1343,
            138
          ]
        }
      },
      "full_frame": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\full_frame.stl",
        "bytes": 15204984,
        "triangles": 304098,
        "bounds_mm": {
          "min": [
            -70.875,
            -24.5672,
            -138.95
          ],
          "max": [
            72.015,
            21.2829,
            2.335
          ],
          "size": [
            142.89,
            45.8501,
            141.285
          ]
        }
      },
      "front_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_front_trace.svg",
        "bytes": 107926
      },
      "side_trace_svg": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_side_trace.svg",
        "bytes": 8957
      },
      "front_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_front_trace.png",
        "bytes": 21086
      },
      "side_trace_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_side_trace.png",
        "bytes": 1815
      },
      "preview_png": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\frameana_image2stl_3d_preview.png",
        "bytes": 93434
      },
      "engraving": {
        "path": "D:\\FRAMEANA\\data\\jobs\\1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67\\output\\engraving.stl",
        "bytes": 7884,
        "triangles": 156,
        "bounds_mm": {
          "min": [
            70.915,
            5.191,
            -26.9968
          ],
          "max": [
            72.015,
            10.509,
            -16.7069
          ],
          "size": [
            1.1,
            5.3181,
            10.2899
          ]
        }
      }
    },
    "job_id": "1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67",
    "style": "sport",
    "material": "acetate",
    "frame_color": "tortoise",
    "engraving_text": "Nael",
    "engraving_color": "#C9A14A",
    "customization": {
      "style": "sport",
      "material": "acetate",
      "frame_color": "tortoise",
      "engraving": "Nael",
      "engraving_color": "#C9A14A"
    },
    "stage2c6_assets": {
      "customer_tryon": "customer_tryon.png",
      "frame_orthographic": "frame_orthographic_views.png",
      "frame_3d_preview": "frame_preview.png",
      "front_trace": "frameana_image2stl_front_trace.png",
      "side_trace": "frameana_image2stl_side_trace.png",
      "engraving_stl": "engraving.stl"
    }
  },
  "outputs": {
    "customer_tryon": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/customer_tryon.png",
    "frame_preview": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_orthographic_views.png",
    "frame_orthographic": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_orthographic_views.png",
    "frame_3d_preview": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_preview.png",
    "frame_front_trace": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frameana_image2stl_front_trace.png",
    "frame_side_trace": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frameana_image2stl_side_trace.png",
    "frame_metadata": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_metadata.json",
    "frame_front": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/frame_front.stl",
    "left_arm": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/left_arm.stl",
    "right_arm": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/right_arm.stl",
    "full_frame": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/full_frame.stl",
    "engraving_stl": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/engraving.stl",
    "engraving": "/outputs/1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67/output/engraving.stl"
  },
  "job_id": "1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67"
}', NULL, '1787425456960-ee94bbf6-355b-4245-b4df-523c65be8b67');
INSERT INTO "users" ("id", "name", "email", "password_hash", "created_at", "is_active", "is_admin") VALUES (1, 'Nael Hafiz Ghannam', 'nael.ghannam@schoolscom.com', 'scrypt$ePaMpn-JYFGEGAJOSOAVDA$0AdmBwCiFVdFJOrZXFsaF7KRF5f-czo3KghN6PCkWtap68TEzPuBV17QYvs4oEsteZfkMeDPCmulHcHBqlNl1w', '2026-08-16T20:39:42.841Z', 1, 0);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence (name, seq) VALUES ('order_status_history', 5);
INSERT INTO sqlite_sequence (name, seq) VALUES ('orders', 4);
INSERT INTO sqlite_sequence (name, seq) VALUES ('users', 1);
COMMIT;
PRAGMA foreign_keys=ON;
