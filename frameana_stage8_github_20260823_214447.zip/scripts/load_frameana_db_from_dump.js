"use strict";

const fs = require("fs");
const path = require("path");
const { DatabaseSync } = require("node:sqlite");

function timestamp() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "_");
}

function usage() {
  console.log("Usage:");
  console.log("  node scripts/load_frameana_db_from_dump.js <dump.sql> <target.sqlite>");
  console.log("");
  console.log("Example:");
  console.log("  node scripts/load_frameana_db_from_dump.js database/frameana_full_dump.sql D:\\FRAMEANA\\data\\frameana.sqlite");
}

function main() {
  const dumpPath = process.argv[2];
  const targetDbPath = process.argv[3];

  if (!dumpPath || !targetDbPath) {
    usage();
    process.exit(1);
  }

  const resolvedDumpPath = path.resolve(dumpPath);
  const resolvedTargetDbPath = path.resolve(targetDbPath);

  if (!fs.existsSync(resolvedDumpPath)) {
    throw new Error(`Dump file was not found: ${resolvedDumpPath}`);
  }

  fs.mkdirSync(path.dirname(resolvedTargetDbPath), { recursive: true });

  if (fs.existsSync(resolvedTargetDbPath)) {
    const backupPath = `${resolvedTargetDbPath}.before_load_${timestamp()}`;
    fs.renameSync(resolvedTargetDbPath, backupPath);
    for (const suffix of ["-wal", "-shm"]) {
      const companionPath = `${resolvedTargetDbPath}${suffix}`;
      if (fs.existsSync(companionPath)) fs.renameSync(companionPath, `${backupPath}${suffix}`);
    }
    console.log(`Existing database moved to: ${backupPath}`);
  }

  const sql = fs.readFileSync(resolvedDumpPath, "utf8");
  const db = new DatabaseSync(resolvedTargetDbPath);
  db.exec(sql);
  db.close();

  console.log(`Database loaded: ${resolvedTargetDbPath}`);
}

if (require.main === module) {
  main();
}
