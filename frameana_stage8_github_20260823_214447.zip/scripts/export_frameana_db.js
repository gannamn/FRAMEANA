"use strict";

const fs = require("fs");
const path = require("path");
const { DatabaseSync } = require("node:sqlite");

const DEFAULT_DB_PATH = process.platform === "win32"
  ? "D:\\FRAMEANA\\data\\frameana.sqlite"
  : path.resolve("data", "frameana.sqlite");

function timestamp() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\..+/, "").replace("T", "_");
}

function sqlString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function sqlIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function sqlValue(value) {
  if (value === null || value === undefined) return "NULL";
  if (Buffer.isBuffer(value)) return `X'${value.toString("hex")}'`;
  if (typeof value === "number") return Number.isFinite(value) ? String(value) : "NULL";
  if (typeof value === "bigint") return String(value);
  return sqlString(value);
}

function ensureDirectory(directoryPath) {
  fs.mkdirSync(directoryPath, { recursive: true });
}

function writeLines(filePath, lines) {
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function schemaRows(db) {
  return db.prepare(`
    SELECT type, name, tbl_name, sql
    FROM sqlite_schema
    WHERE sql IS NOT NULL
      AND name NOT LIKE 'sqlite_%'
    ORDER BY
      CASE type
        WHEN 'table' THEN 1
        WHEN 'view' THEN 2
        WHEN 'index' THEN 3
        WHEN 'trigger' THEN 4
        ELSE 5
      END,
      name
  `).all();
}

function userTableNames(db) {
  return db.prepare(`
    SELECT name
    FROM sqlite_schema
    WHERE type = 'table'
      AND name NOT LIKE 'sqlite_%'
    ORDER BY name
  `).all().map((row) => row.name);
}

function dumpTableData(db, tableName) {
  const columns = db.prepare(`PRAGMA table_info(${sqlIdentifier(tableName)})`).all().map((column) => column.name);
  if (columns.length === 0) return [];

  const quotedTable = sqlIdentifier(tableName);
  const quotedColumns = columns.map(sqlIdentifier).join(", ");
  const rows = db.prepare(`SELECT * FROM ${quotedTable}`).all();
  return rows.map((row) => {
    const values = columns.map((column) => sqlValue(row[column])).join(", ");
    return `INSERT INTO ${quotedTable} (${quotedColumns}) VALUES (${values});`;
  });
}

function dumpSqliteSequence(db) {
  const hasSequence = db.prepare(`
    SELECT 1 AS exists_flag
    FROM sqlite_schema
    WHERE type = 'table' AND name = 'sqlite_sequence'
  `).get();

  if (!hasSequence) return [];

  const rows = db.prepare("SELECT name, seq FROM sqlite_sequence ORDER BY name").all();
  if (rows.length === 0) return [];

  return [
    "DELETE FROM sqlite_sequence;",
    ...rows.map((row) => `INSERT INTO sqlite_sequence (name, seq) VALUES (${sqlValue(row.name)}, ${sqlValue(row.seq)});`),
  ];
}

function exportDatabase({ sourceDbPath, exportDir }) {
  if (!fs.existsSync(sourceDbPath)) {
    throw new Error(`Database was not found: ${sourceDbPath}`);
  }

  ensureDirectory(exportDir);

  const backupDbPath = path.join(exportDir, "frameana.sqlite.backup");
  const schemaPath = path.join(exportDir, "frameana_schema.sql");
  const dataPath = path.join(exportDir, "frameana_data.sql");
  const fullDumpPath = path.join(exportDir, "frameana_full_dump.sql");
  fs.rmSync(backupDbPath, { force: true });

  const sourceDb = new DatabaseSync(sourceDbPath);
  sourceDb.exec(`VACUUM INTO ${sqlString(backupDbPath)}`);
  sourceDb.close();

  const db = new DatabaseSync(backupDbPath);
  const schema = schemaRows(db).map((row) => `${row.sql};`);
  const data = [
    "PRAGMA foreign_keys=OFF;",
    "BEGIN TRANSACTION;",
    ...userTableNames(db).flatMap((tableName) => dumpTableData(db, tableName)),
    ...dumpSqliteSequence(db),
    "COMMIT;",
    "PRAGMA foreign_keys=ON;",
  ];
  db.close();

  const fullDump = [
    "PRAGMA foreign_keys=OFF;",
    "BEGIN TRANSACTION;",
    ...schema,
    ...data.filter((line) => !["PRAGMA foreign_keys=OFF;", "BEGIN TRANSACTION;", "COMMIT;", "PRAGMA foreign_keys=ON;"].includes(line)),
    "COMMIT;",
    "PRAGMA foreign_keys=ON;",
  ];

  writeLines(schemaPath, schema);
  writeLines(dataPath, data);
  writeLines(fullDumpPath, fullDump);

  return { backupDbPath, schemaPath, dataPath, fullDumpPath };
}

function main() {
  const sourceDbPath = path.resolve(process.env.FRAMEANA_DB_PATH || process.argv[2] || DEFAULT_DB_PATH);
  const defaultExportDir = process.platform === "win32"
    ? path.join("D:\\FRAMEANA\\db_exports", `frameana_db_export_${timestamp()}`)
    : path.resolve("db_exports", `frameana_db_export_${timestamp()}`);
  const exportDir = path.resolve(process.env.FRAMEANA_DB_EXPORT_DIR || process.argv[3] || defaultExportDir);

  const result = exportDatabase({ sourceDbPath, exportDir });
  console.log(JSON.stringify({ sourceDbPath, exportDir, ...result }, null, 2));
}

if (require.main === module) {
  main();
}

module.exports = { exportDatabase };
