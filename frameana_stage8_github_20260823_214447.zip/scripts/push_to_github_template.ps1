param(
  [Parameter(Mandatory = $true)]
  [string]$RemoteUrl,

  [string]$CommitMessage = "Backup FRAMEANA Stage 8 platform"
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git was not found on PATH."
}

if (-not (Test-Path ".git")) {
  git init
}

git add .
git commit -m $CommitMessage
git branch -M main

$existingRemote = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0 -and $existingRemote) {
  git remote set-url origin $RemoteUrl
} else {
  git remote add origin $RemoteUrl
}

git push -u origin main
