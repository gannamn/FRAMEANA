"""
FRAMEANA - Stage 2C-3
ChatGPT Segmind GPT Image Try-On Experiment
File: chatgpt_segmind_tryon.py

Purpose:
- Use Segmind GPT Image model to generate a realistic front try-on image.
- Keep the experiment isolated from FRAMEANA core files.
- No FastAPI server.
- No port 8000.
- Does not modify main.py, face.py, svg_template_tryon.py, or cad.py.

Important:
- Segmind GPT Image API needs public image URLs for image_urls and mask_image_url/mask.
- This script can prepare the prompt, mask, and request JSON locally for free.
- To call Segmind from the script, provide public URLs using --image-url and --mask-url
  or provide --public-base-url after hosting chatgpt_output publicly.

Recommended first run, free/no API call:
    python chatgpt_segmind_tryon.py --image nael_1024.jpg --mode prepare

Frontend-ready style variables:
    --frame-color black
    --frame-shape classic|round|sport
    --arm-text "NAEL"
    --arm-text-color white
    --frame-edit "make the rims thinner"
    --include-frame-preview

Example with style variables, free/no API call:
    python chatgpt_segmind_tryon.py --image nael_1024.jpg --mode prepare --frame-color tortoise --frame-shape round --arm-text NAEL --arm-text-color gold --frame-edit "slimmer bridge"

Example with an additional front/side frame product preview:
    python chatgpt_segmind_tryon.py --image nael_1024.jpg --mode call --include-frame-preview --frame-color tortoise --frame-shape round --arm-text Nael --arm-text-color gold

Call Segmind GPT Image 2 after you have public URLs:
    set SEGMIND_API_KEY=your_key_here
    python chatgpt_segmind_tryon.py --image nael_1024.jpg --mode call --image-url https://.../chatgpt_input_image.jpg --mask-url https://.../chatgpt_edit_mask.png --quality low

Alternative model:
    python chatgpt_segmind_tryon.py --image nael_1024.jpg --mode call --model gpt-image-1-edit --image-url https://.../chatgpt_input_image.jpg --mask-url https://.../chatgpt_edit_mask.png --quality low
"""

from __future__ import annotations

import argparse
import atexit
import functools
import hashlib
import http.server
import json
import math
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
from PIL import Image, ImageDraw


Point = Tuple[float, float]


DEFAULT_MEASUREMENTS: Dict[str, Any] = {
    "face_width": 478.74,
    "eye_distance": 214.42,
    "nose_width": 81.48,
    "head_angle": -3.37,
    "center_x": 332.21,
    "center_y": 407.86,
    "debug": {
        "left_eye": [225.18, 414.17],
        "right_eye": [439.23, 401.55],
    },
}


@dataclass
class TryOnStyle:
    frame_color: str
    frame_shape: str
    arm_text: str
    arm_text_color: str
    frame_edit: str


@dataclass
class FrameFit:
    face_width: float
    eye_distance: float
    nose_width: float
    head_angle: float
    left_eye_x: float
    left_eye_y: float
    right_eye_x: float
    right_eye_y: float
    eye_mid_x: float
    eye_mid_y: float
    lens_center_y: float
    bridge_width: float
    lens_width: float
    lens_height: float
    frame_width: float
    rim_thickness: float
    brow_thickness: float
    mask_width: float
    mask_height: float
    front_has_arms: bool
    front_has_hinge_tabs: bool
    front_has_engraving: bool


def safe_float(value: Any, fallback: float = 0.0) -> float:
    try:
        if value is None:
            return fallback
        return float(value)
    except Exception:
        return fallback


def clamp(value: float, min_value: float, max_value: float) -> float:
    return max(min_value, min(value, max_value))


def ensure_output_dir(output_dir: str) -> Path:
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, data: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def save_text(path: Path, text: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def image_hash(image_path: str) -> str:
    h = hashlib.sha256()
    with open(image_path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def round_value(value: Any, ndigits: int = 2) -> Any:
    if isinstance(value, float):
        return round(value, ndigits)
    if isinstance(value, dict):
        return {k: round_value(v, ndigits) for k, v in value.items()}
    if isinstance(value, list):
        return [round_value(v, ndigits) for v in value]
    return value


def normalize_public_base_url(url: str) -> str:
    return url.rstrip("/")


def is_http_url(value: Optional[str]) -> bool:
    if not value:
        return False
    return value.startswith("http://") or value.startswith("https://")


def first_existing_path(paths: List[Path]) -> Optional[Path]:
    for path in paths:
        if path and path.exists():
            return path
    return None


def default_api_key_file() -> Optional[Path]:
    script_dir = Path(__file__).resolve().parent
    return first_existing_path(
        [
            script_dir / "segmind_api_key.txt",
            script_dir / "backend" / "segmind_api_key.txt",
            Path.cwd() / "segmind_api_key.txt",
            Path.home() / "segmind_api_key.txt",
        ]
    )


def read_api_key_file(path_value: Optional[str]) -> str:
    path = Path(path_value).expanduser() if path_value else default_api_key_file()
    if not path or not path.exists():
        return ""

    for line in path.read_text(encoding="utf-8").splitlines():
        key = line.strip()
        if key and not key.startswith("#"):
            return key
    return ""


def resolve_api_key(api_key: Optional[str], api_key_file: Optional[str]) -> str:
    return (api_key or os.getenv("SEGMIND_API_KEY") or read_api_key_file(api_key_file)).strip()


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


class QuietDirectoryHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        return


class CloudflaredTunnel:
    def __init__(self, directory: Path, cloudflared_path: str, timeout_seconds: int) -> None:
        self.directory = directory
        self.cloudflared_path = cloudflared_path
        self.timeout_seconds = timeout_seconds
        self.port = find_free_port()
        self.public_url = ""
        self._server: Optional[http.server.ThreadingHTTPServer] = None
        self._server_thread: Optional[threading.Thread] = None
        self._process: Optional[subprocess.Popen[str]] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self._logs: List[str] = []

    def start(self) -> str:
        handler = functools.partial(QuietDirectoryHandler, directory=str(self.directory))
        self._server = http.server.ThreadingHTTPServer(("127.0.0.1", self.port), handler)
        self._server_thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._server_thread.start()

        command = [
            self.cloudflared_path,
            "tunnel",
            "--url",
            f"http://127.0.0.1:{self.port}",
            "--no-autoupdate",
        ]
        self._process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        self._reader_thread = threading.Thread(target=self._read_cloudflared_output, daemon=True)
        self._reader_thread.start()

        if not self._ready.wait(timeout=self.timeout_seconds):
            tail = "\n".join(self._logs[-12:])
            self.close()
            raise RuntimeError(f"Could not create cloudflared public URL within {self.timeout_seconds}s.\n{tail}")

        # Cloudflare prints the URL before DNS is always ready everywhere.
        time.sleep(3.0)
        return self.public_url

    def _read_cloudflared_output(self) -> None:
        if not self._process or not self._process.stdout:
            return

        pattern = re.compile(r"https://[-a-zA-Z0-9.]+\.trycloudflare\.com")
        for line in self._process.stdout:
            text = line.strip()
            if text:
                self._logs.append(text)
            match = pattern.search(text)
            if match:
                self.public_url = match.group(0).rstrip("/")
                self._ready.set()

    def close(self) -> None:
        if self._process and self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
        if self._server:
            self._server.shutdown()
            self._server.server_close()


def copy_input_image(image_path: str, output_dir: Path) -> Path:
    src = Path(image_path)
    suffix = src.suffix.lower()
    if suffix not in [".jpg", ".jpeg", ".png", ".webp"]:
        suffix = ".jpg"
    dst = output_dir / f"chatgpt_input_image{suffix}"
    shutil.copyfile(src, dst)
    return dst


def extract_measurements(raw: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if raw is None:
        return dict(DEFAULT_MEASUREMENTS)

    if isinstance(raw.get("measurements"), dict):
        source = dict(raw["measurements"])
    else:
        source = dict(raw)

    if "debug" not in source and isinstance(raw.get("debug"), dict):
        source["debug"] = raw["debug"]

    debug = source.get("debug")
    if isinstance(debug, dict) and isinstance(debug.get("fit"), dict):
        fit = debug["fit"]
        if "left_eye" not in debug and "left_eye_x" in fit and "left_eye_y" in fit:
            debug["left_eye"] = [fit["left_eye_x"], fit["left_eye_y"]]
        if "right_eye" not in debug and "right_eye_x" in fit and "right_eye_y" in fit:
            debug["right_eye"] = [fit["right_eye_x"], fit["right_eye_y"]]

    merged = dict(DEFAULT_MEASUREMENTS)
    merged.update(source)

    if "debug" not in merged or not isinstance(merged["debug"], dict):
        merged["debug"] = DEFAULT_MEASUREMENTS["debug"]

    return merged


def get_eye_points(measurements: Dict[str, Any]) -> Tuple[Point, Point]:
    eye_distance = safe_float(measurements.get("eye_distance"), 214.42)
    center_x = safe_float(measurements.get("center_x"), 332.21)
    center_y = safe_float(measurements.get("center_y"), 407.86)

    debug = measurements.get("debug")
    if isinstance(debug, dict):
        left_eye = debug.get("left_eye")
        right_eye = debug.get("right_eye")
        if isinstance(left_eye, (list, tuple)) and isinstance(right_eye, (list, tuple)):
            if len(left_eye) >= 2 and len(right_eye) >= 2:
                return (
                    (safe_float(left_eye[0]), safe_float(left_eye[1])),
                    (safe_float(right_eye[0]), safe_float(right_eye[1])),
                )

    return (
        (center_x - eye_distance / 2.0, center_y),
        (center_x + eye_distance / 2.0, center_y),
    )


def compute_frame_fit(
    measurements: Dict[str, Any],
    frame_shape: str = "classic",
    show_arm_text: bool = False,
) -> FrameFit:
    face_width = safe_float(measurements.get("face_width"), 478.74)
    eye_distance = safe_float(measurements.get("eye_distance"), 214.42)
    nose_width = safe_float(measurements.get("nose_width"), 81.48)
    head_angle = safe_float(measurements.get("head_angle"), 0.0)

    left_eye, right_eye = get_eye_points(measurements)
    landmark_eye_distance = math.dist(left_eye, right_eye)
    if landmark_eye_distance > 20.0:
        eye_distance = landmark_eye_distance

    eye_mid_x = (left_eye[0] + right_eye[0]) / 2.0
    eye_mid_y = (left_eye[1] + right_eye[1]) / 2.0

    # Stage 2C-3 fitting rule:
    # The bridge must be clearly visible and must represent the actual distance
    # between the lens openings. Keep lens_width + bridge_width = eye_distance.
    bridge_width = clamp(
        nose_width * 0.60,
        eye_distance * 0.20,
        eye_distance * 0.25,
    )

    lens_width = eye_distance - bridge_width
    lens_width = clamp(
        lens_width,
        eye_distance * 0.73,
        eye_distance * 0.82,
    )
    bridge_width = eye_distance - lens_width

    if frame_shape == "round":
        lens_height = lens_width * 0.88
        brow_multiplier = 1.08
    elif frame_shape == "sport":
        lens_height = lens_width * 0.52
        brow_multiplier = 1.18
    else:
        lens_height = lens_width * 0.575
        brow_multiplier = 1.42

    rim_thickness = clamp(lens_width * 0.055, 7.5, 10.5)
    brow_thickness = rim_thickness * brow_multiplier
    lens_center_y = eye_mid_y + lens_height * 0.065

    frame_width = lens_width * 2.0 + bridge_width + rim_thickness * 3.2
    side_margin_multiplier = 12.0 if show_arm_text else 1.0
    mask_width = frame_width + rim_thickness * side_margin_multiplier
    mask_height = lens_height + rim_thickness * 8.5

    return FrameFit(
        face_width=face_width,
        eye_distance=eye_distance,
        nose_width=nose_width,
        head_angle=head_angle,
        left_eye_x=left_eye[0],
        left_eye_y=left_eye[1],
        right_eye_x=right_eye[0],
        right_eye_y=right_eye[1],
        eye_mid_x=eye_mid_x,
        eye_mid_y=eye_mid_y,
        lens_center_y=lens_center_y,
        bridge_width=bridge_width,
        lens_width=lens_width,
        lens_height=lens_height,
        frame_width=frame_width,
        rim_thickness=rim_thickness,
        brow_thickness=brow_thickness,
        mask_width=mask_width,
        mask_height=mask_height,
        front_has_arms=show_arm_text,
        front_has_hinge_tabs=False,
        front_has_engraving=show_arm_text,
    )


def rotate_point(x: float, y: float, angle_degrees: float, center: Point) -> Point:
    cx, cy = center
    a = math.radians(angle_degrees)
    cos_a = math.cos(a)
    sin_a = math.sin(a)
    dx = x - cx
    dy = y - cy
    return (
        cx + dx * cos_a - dy * sin_a,
        cy + dx * sin_a + dy * cos_a,
    )


def rotated_rect_polygon(center: Point, width: float, height: float, angle_degrees: float) -> List[Point]:
    cx, cy = center
    hw = width / 2.0
    hh = height / 2.0
    points = [
        (cx - hw, cy - hh),
        (cx + hw, cy - hh),
        (cx + hw, cy + hh),
        (cx - hw, cy + hh),
    ]
    return [rotate_point(x, y, angle_degrees, center) for x, y in points]


def create_segmind_edit_mask(image_path: str, fit: FrameFit, output_path: Path) -> None:
    """
    Segmind GPT Image 2 mask rule:
    - white regions are edited
    - outside stays preserved

    We create a black image and paint a white glasses/bridge zone.
    """
    with Image.open(image_path) as img:
        width, height = img.size

    edit_region = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(edit_region)

    main_zone = rotated_rect_polygon(
        center=(fit.eye_mid_x, fit.lens_center_y),
        width=fit.mask_width,
        height=fit.mask_height,
        angle_degrees=fit.head_angle,
    )
    draw.polygon(main_zone, fill=255)

    bridge_zone = rotated_rect_polygon(
        center=(fit.eye_mid_x, fit.lens_center_y + fit.lens_height * 0.05),
        width=fit.bridge_width + fit.rim_thickness * 7.0,
        height=fit.lens_height * 0.65,
        angle_degrees=fit.head_angle,
    )
    draw.polygon(bridge_zone, fill=255)

    if fit.front_has_arms:
        arm_width = fit.rim_thickness * 9.0
        arm_height = fit.rim_thickness * 3.0
        arm_offset = fit.lens_width * 0.52 + fit.rim_thickness * 5.0
        arm_y = fit.lens_center_y - fit.lens_height * 0.08
        for direction in (-1.0, 1.0):
            arm_zone = rotated_rect_polygon(
                center=(fit.eye_mid_x + direction * arm_offset, arm_y),
                width=arm_width,
                height=arm_height,
                angle_degrees=fit.head_angle,
            )
            draw.polygon(arm_zone, fill=255)

    # GPT Image edit masks require an alpha channel: transparent pixels are edited.
    alpha = Image.new("L", (width, height), 255)
    alpha.paste(0, mask=edit_region)
    mask = Image.new("RGBA", (width, height), (255, 255, 255, 255))
    mask.putalpha(alpha)
    mask.save(output_path)


def frame_shape_description(frame_shape: str) -> str:
    if frame_shape == "round":
        return "round acetate eyeglasses front frame with rounded circular lenses"
    if frame_shape == "sport":
        return "sport acetate eyeglasses front frame with angular wrap-inspired rectangular lenses"
    return "classic wayfarer acetate front frame with softly rectangular lenses"


def build_prompt(fit: FrameFit, style: TryOnStyle) -> str:
    fit_dict = round_value(asdict(fit))
    shape_description = frame_shape_description(style.frame_shape)
    if style.arm_text:
        text_rules = f"""
ARM TEXT / TEMPLE TEXT:
- Add the exact customer text "{style.arm_text}" on the temple arm, after the hinge, on the straight side arm surface.
- Do not place the text on the hinge, hinge dot, hinge screw, hinge plate, front corner, lens rim, or lens.
- Keep the hinge area blank with no letters on it.
- Text color must be {style.arm_text_color}.
- Keep the text small, clean, readable, and aligned with the arm perspective.
- Do not add any other text, logo, brand mark, watermark, or UI text.
- Show a short visible temple arm segment after the hinge so the text sits on the arm, not on the hinge.
- Do not draw long arms reaching the ears.
""".strip()
        arm_rules = """
- Front try-on view with short side temple arm areas after the hinges if needed for the requested arm text.
- No long arms reaching toward the ears.
- No large hinge tabs protruding from the sides.
- Keep hinge dots/screws clean and separate from the customer text.
""".strip()
    else:
        text_rules = """
TEXT / LOGO RULES:
- Do not add any text, logo, engraving, brand mark, watermark, or UI text on the glasses.
""".strip()
        arm_rules = """
- Front try-on view only.
- No visible arms or temples.
- No side bars, no earpieces, no horizontal extensions toward the ears.
- No large hinge tabs protruding from the sides.
- The front frame must stop at the outer lens rims with only short front-frame corners.
""".strip()

    if style.frame_edit:
        frame_edit_rules = f"""
CUSTOM FRAME MODIFICATION:
- Apply this customer frame modification request: "{style.frame_edit}".
- Keep the modification limited to the eyeglasses frame only.
- Do not change the face, eyes, skin, hair, clothing, background, camera angle, or lighting.
""".strip()
    else:
        frame_edit_rules = """
CUSTOM FRAME MODIFICATION:
- No additional custom frame modification was requested.
""".strip()

    return f"""
Edit the provided portrait photo by adding realistic eyeglasses only.

ABSOLUTE OUTPUT RULES:
- Return only the edited portrait photo.
- No UI, no before/after layout, no panels, no labels, no measurement text, no watermark.
- Do not create a mockup screen.
- Do not add text or logo except the optional customer arm text defined below.

IDENTITY PRESERVATION:
- Preserve the exact same person, face shape, eyes, eyebrows, nose, beard, hair, skin texture, clothing, background, camera angle, and lighting.
- Do not beautify the face.
- Do not change the eyes.
- Keep both eyes fully visible through the lenses.

GLASSES STYLE:
- Add a realistic {style.frame_color} {shape_description}.
{arm_rules}
- Clear transparent lenses, with very subtle natural reflections only.
- The frame must be realistic, not cartoonish, not toy-like, and not a flat sticker.
- Use a smooth saddle bridge above the nose and between the eyes.
- The bridge must be clearly visible and realistic, not tiny.
- For classic shape, the top brow should be slightly thicker than the lower rim.
- For round shape, keep the rims balanced and rounded.
- For sport shape, keep the lenses angular, lower, and wider with a dynamic brow line.
- Natural soft shadow on the face matching the original indoor lighting.

{text_rules}

{frame_edit_rules}

PARAMETRIC FRAME FIT IN PIXELS:
{json.dumps(fit_dict, ensure_ascii=False, indent=2)}

GEOMETRY RULES:
- Align the left lens center with left_eye_x/left_eye_y.
- Align the right lens center with right_eye_x/right_eye_y.
- Use head_angle for rotation.
- lens_width + bridge_width must visually equal eye_distance.
- The bridge must sit above the nose, not over the eyes.
- Do not cover the pupils.
- The result should look like a clean front eyewear try-on preview.
""".strip()


def build_frame_preview_prompt(style: TryOnStyle) -> str:
    shape_description = frame_shape_description(style.frame_shape)
    if style.arm_text:
        text_rules = f"""
- Put the exact customer text "{style.arm_text}" on the side-view temple arm only.
- Text color must be {style.arm_text_color}.
- The text must sit after the hinge on the straight arm surface, not on the hinge, hinge dot, screw, front corner, rim, or lens.
- Keep the hinge area blank with no letters on it.
""".strip()
    else:
        text_rules = """
- Do not add any text, logo, engraving, brand mark, watermark, or UI text.
""".strip()

    if style.frame_edit:
        frame_edit_rules = f"""
- Apply this customer frame modification: "{style.frame_edit}".
- Keep the modification limited to the eyeglasses frame.
""".strip()
    else:
        frame_edit_rules = "- No additional custom frame modification was requested."

    return f"""
Create a clean product preview image of the eyeglasses frame only.

ABSOLUTE OUTPUT RULES:
- Show only the eyeglasses frame product.
- No person, no face, no mannequin, no hands, no UI, no mockup screen, no text labels, no arrows, no measurements, no watermark.
- Use a clean flat white or very light off-white background.
- No shadows of any kind: no cast shadow, no drop shadow, no ambient shadow, no ground shadow, no contact shadow.
- No dramatic lighting, no gradient lighting, no dark vignette, no table surface, no floor, no reflection on the background.
- Keep the frame as a clean 2D orthographic product reference with crisp edges and clear silhouette.

PRODUCT VIEWS:
- Include two views of the same frame in one image: a front view and a side view.
- Front view: show the full frame from the front with both lenses, bridge, rims, and hinges visible.
- Front view must be front-only: no temple arms, no earpieces, no folded side arms, and no diagonal inner bars visible behind or inside the lens openings.
- The inside of each lens opening must remain empty/transparent except for the rim outline; do not place any brown/black frame pieces inside the lenses.
- Do not draw extra support struts, diagonal arms, nose pads, folded temples, or rear arms inside the front view.
- Side view: show one side profile with the temple arm extended enough to see the arm shape and optional customer text.
- Arrange the views like a premium eyewear product catalog image, with enough spacing between front and side view.
- Keep the front view and side view clearly separated; they must not overlap or visually merge.
- Keep both views flat and easy to threshold for STL tracing.

FRAME STYLE:
- Frame color/material: {style.frame_color}.
- Frame shape: {shape_description}.
- Clear transparent lenses with minimal or no reflections.
- Realistic acetate/plastic material, but without lighting shadows.
- Crisp edges, high detail, clean silhouette, professional CAD reference look.
{text_rules}

CUSTOM FRAME MODIFICATION:
{frame_edit_rules}
""".strip()


def build_payload(
    model: str,
    prompt: str,
    image_url: Optional[str],
    mask_url: Optional[str],
    size: str,
    quality: str,
    output_format: str,
) -> Dict[str, Any]:
    if model == "gpt-image-2":
        payload: Dict[str, Any] = {
            "prompt": prompt,
            "background": "opaque",
            "image_urls": [image_url] if image_url else [],
            "mask_image_url": mask_url or "",
            "moderation": "auto",
            "output_format": output_format,
            "output_compression": 100,
            "quality": quality,
            "size": size,
        }
        return payload

    if model == "gpt-image-1-edit":
        if not image_url:
            raise ValueError("gpt-image-1-edit requires --image-url")
        payload = {
            "prompt": prompt,
            "image_urls": [image_url],
            "mask": mask_url,
            "size": size,
            "quality": quality,
            "background": "opaque",
            "output_compression": 100,
            "output_format": output_format,
            "moderation": "auto",
        }
        return payload

    raise ValueError(f"Unsupported model: {model}")


def build_frame_preview_payload(
    model: str,
    prompt: str,
    size: str,
    quality: str,
    output_format: str,
) -> Dict[str, Any]:
    if model != "gpt-image-2":
        raise ValueError("Frame preview generation currently requires --model gpt-image-2")

    return {
        "prompt": prompt,
        "background": "opaque",
        "image_urls": [],
        "mask_image_url": "",
        "moderation": "auto",
        "output_format": output_format,
        "output_compression": 100,
        "quality": quality,
        "size": size,
    }


def endpoint_for_model(model: str) -> str:
    if model == "gpt-image-2":
        return "https://api.segmind.com/v1/gpt-image-2"
    if model == "gpt-image-1-edit":
        return "https://api.segmind.com/v1/gpt-image-1-edit"
    raise ValueError(f"Unsupported model: {model}")


def download_binary(url: str, output_path: Path, timeout: int = 180) -> None:
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    with open(output_path, "wb") as f:
        f.write(response.content)


def extract_output_url_from_json(data: Dict[str, Any]) -> Optional[str]:
    candidates = [
        data.get("output"),
        data.get("image"),
        data.get("url"),
        data.get("result"),
    ]

    for item in candidates:
        if isinstance(item, str) and is_http_url(item):
            return item
        if isinstance(item, list):
            for sub in item:
                if isinstance(sub, str) and is_http_url(sub):
                    return sub
                if isinstance(sub, dict):
                    for key in ["url", "image", "output"]:
                        value = sub.get(key)
                        if isinstance(value, str) and is_http_url(value):
                            return value

    if isinstance(data.get("data"), list):
        for sub in data["data"]:
            if isinstance(sub, dict):
                for key in ["url", "image", "output"]:
                    value = sub.get(key)
                    if isinstance(value, str) and is_http_url(value):
                        return value

    return None


def call_segmind(
    api_key: str,
    model: str,
    payload: Dict[str, Any],
    output_path: Path,
    response_json_path: Path,
    timeout: int = 300,
) -> Dict[str, Any]:
    url = endpoint_for_model(model)
    headers = {
        "x-api-key": api_key,
        "Content-Type": "application/json",
    }

    response = requests.post(url, headers=headers, json=payload, timeout=timeout)

    content_type = response.headers.get("content-type", "").lower()
    status_info: Dict[str, Any] = {
        "http_status": response.status_code,
        "content_type": content_type,
        "endpoint": url,
        "model": model,
        "created_at_unix": int(time.time()),
    }

    if response.status_code >= 400:
        status_info["error_text"] = response.text[:4000]
        save_json(response_json_path, status_info)
        raise RuntimeError(
            f"Segmind request failed with HTTP {response.status_code}: {response.text[:1000]}"
        )

    if content_type.startswith("image/"):
        with open(output_path, "wb") as f:
            f.write(response.content)
        status_info["saved_output"] = str(output_path)
        save_json(response_json_path, status_info)
        return status_info

    try:
        data = response.json()
    except Exception:
        raw_path = output_path.with_suffix(".raw_response.txt")
        raw_path.write_bytes(response.content)
        status_info["raw_response_path"] = str(raw_path)
        save_json(response_json_path, status_info)
        raise RuntimeError(
            "Segmind response was not image bytes and not valid JSON. "
            f"Saved raw response to {raw_path}"
        )

    status_info["response_json"] = data
    output_url = extract_output_url_from_json(data)
    if output_url:
        download_binary(output_url, output_path)
        status_info["output_url"] = output_url
        status_info["saved_output"] = str(output_path)
    else:
        status_info["warning"] = "No direct output URL found in JSON response. Check response_json."

    save_json(response_json_path, status_info)
    return status_info


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="FRAMEANA ChatGPT Segmind GPT Image Try-On Experiment. No port 8000."
    )
    parser.add_argument("--image", required=True, help="Local input face image path.")
    parser.add_argument("--measurements", default=None, help="Optional JSON from face.py or Stage 2.")
    parser.add_argument("--output-dir", default="chatgpt_output", help="Output folder.")
    parser.add_argument(
        "--mode",
        default="prepare",
        choices=["prepare", "call"],
        help="prepare = free local files only. call = send to Segmind API.",
    )
    parser.add_argument(
        "--model",
        default="gpt-image-2",
        choices=["gpt-image-2", "gpt-image-1-edit"],
        help="Segmind model.",
    )
    parser.add_argument("--image-url", default=None, help="Public URL for chatgpt_input_image file.")
    parser.add_argument("--mask-url", default=None, help="Public URL for chatgpt_edit_mask.png.")
    parser.add_argument(
        "--public-base-url",
        default=None,
        help="Public base URL exposing chatgpt_output files. Example: https://your-tunnel.trycloudflare.com/chatgpt_output",
    )
    parser.add_argument("--api-key", default=None, help="Optional Segmind API key. Prefer SEGMIND_API_KEY env var.")
    parser.add_argument(
        "--api-key-file",
        default=None,
        help="Optional text file containing the Segmind API key. Defaults to segmind_api_key.txt beside this script.",
    )
    parser.add_argument(
        "--auto-public-url",
        dest="auto_public_url",
        action="store_true",
        default=True,
        help="Automatically expose --output-dir with cloudflared when --mode call needs image/mask public URLs.",
    )
    parser.add_argument(
        "--no-auto-public-url",
        dest="auto_public_url",
        action="store_false",
        help="Disable automatic cloudflared public URL creation.",
    )
    parser.add_argument("--cloudflared-path", default="cloudflared", help="Path to cloudflared executable.")
    parser.add_argument("--public-url-timeout", type=int, default=45, help="Seconds to wait for cloudflared URL.")
    parser.add_argument("--quality", default="low", choices=["low", "medium", "high", "auto"])
    parser.add_argument("--size", default="1024x1536")
    parser.add_argument("--output-format", default="png", choices=["png", "jpeg", "webp"])
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument(
        "--frame-color",
        default="black",
        help="Customer-selected frame color, for example black, tortoise, clear, red, or #222222.",
    )
    parser.add_argument(
        "--frame-shape",
        default="classic",
        choices=["classic", "round", "sport"],
        help="Customer-selected frame shape.",
    )
    parser.add_argument(
        "--arm-text",
        "--temple-text",
        default="",
        help="Optional customer text to place on the visible side arm/temple.",
    )
    parser.add_argument(
        "--arm-text-color",
        "--temple-text-color",
        default="white",
        help="Color for optional arm/temple text.",
    )
    parser.add_argument(
        "--frame-edit",
        "--frame-modification",
        "--frame-modification-text",
        default="",
        help="Optional free-text customer request for modifying the eyeglasses frame.",
    )
    parser.add_argument(
        "--include-frame-preview",
        action="store_true",
        help="Also prepare/call an eyeglasses frame product preview with front and side views.",
    )
    parser.add_argument(
        "--frame-preview-only",
        action="store_true",
        help="Only prepare/call the front-and-side frame product preview. Useful when a try-on image already exists.",
    )
    parser.add_argument(
        "--frame-preview-size",
        default="1024x1024",
        help="Output size for the frame product preview image.",
    )
    return parser.parse_args()


def style_from_args(args: argparse.Namespace) -> TryOnStyle:
    return TryOnStyle(
        frame_color=(args.frame_color or "black").strip() or "black",
        frame_shape=(args.frame_shape or "classic").strip().lower() or "classic",
        arm_text=(args.arm_text or "").strip(),
        arm_text_color=(args.arm_text_color or "white").strip() or "white",
        frame_edit=(args.frame_edit or "").strip(),
    )


def main() -> int:
    args = parse_args()

    if not os.path.exists(args.image):
        print(f"ERROR: Image not found: {args.image}", file=sys.stderr)
        return 1

    raw_measurements: Optional[Dict[str, Any]] = None
    if args.measurements:
        if not os.path.exists(args.measurements):
            print(f"ERROR: Measurements JSON not found: {args.measurements}", file=sys.stderr)
            return 1
        raw_measurements = load_json(args.measurements)

    output_dir = ensure_output_dir(args.output_dir)

    input_copy_path = copy_input_image(args.image, output_dir)
    mask_path = output_dir / "chatgpt_edit_mask.png"
    prompt_path = output_dir / "chatgpt_prompt.txt"
    request_path = output_dir / "chatgpt_segmind_request.json"
    response_path = output_dir / "chatgpt_segmind_response.json"
    output_path = output_dir / f"chatgpt_segmind_tryon.{args.output_format}"
    frame_preview_prompt_path = output_dir / "chatgpt_frame_preview_prompt.txt"
    frame_preview_request_path = output_dir / "chatgpt_frame_preview_request.json"
    frame_preview_response_path = output_dir / "chatgpt_frame_preview_response.json"
    frame_preview_output_path = output_dir / f"chatgpt_frame_preview.{args.output_format}"

    style = style_from_args(args)
    include_frame_preview = args.include_frame_preview or args.frame_preview_only
    measurements = extract_measurements(raw_measurements)
    fit = compute_frame_fit(
        measurements,
        frame_shape=style.frame_shape,
        show_arm_text=bool(style.arm_text),
    )
    prompt = build_prompt(fit, style)
    create_segmind_edit_mask(args.image, fit, mask_path)
    save_text(prompt_path, prompt)

    frame_preview_prompt: Optional[str] = None
    frame_preview_payload: Optional[Dict[str, Any]] = None
    if include_frame_preview:
        frame_preview_prompt = build_frame_preview_prompt(style)
        frame_preview_payload = build_frame_preview_payload(
            model=args.model,
            prompt=frame_preview_prompt,
            size=args.frame_preview_size,
            quality=args.quality,
            output_format=args.output_format,
        )
        save_text(frame_preview_prompt_path, frame_preview_prompt)

    image_url = args.image_url
    mask_url = args.mask_url
    tunnel: Optional[CloudflaredTunnel] = None

    if args.public_base_url:
        base = normalize_public_base_url(args.public_base_url)
        if not image_url:
            image_url = f"{base}/{input_copy_path.name}"
        if not mask_url:
            mask_url = f"{base}/{mask_path.name}"

    if (
        args.mode == "call"
        and args.auto_public_url
        and not args.frame_preview_only
        and (not is_http_url(image_url) or not is_http_url(mask_url))
    ):
        tunnel = CloudflaredTunnel(
            directory=output_dir,
            cloudflared_path=args.cloudflared_path,
            timeout_seconds=args.public_url_timeout,
        )
        public_base_url = tunnel.start()
        atexit.register(tunnel.close)
        if not image_url:
            image_url = f"{public_base_url}/{input_copy_path.name}"
        if not mask_url:
            mask_url = f"{public_base_url}/{mask_path.name}"

    payload = build_payload(
        model=args.model,
        prompt=prompt,
        image_url=image_url,
        mask_url=mask_url,
        size=args.size,
        quality=args.quality,
        output_format=args.output_format,
    )

    request_info = {
        "stage": "FRAMEANA Stage 2C-3 - ChatGPT Segmind GPT Image Try-On Experiment",
        "mode": args.mode,
        "uses_port_8000": False,
        "touches_main_py": False,
        "touches_face_py": False,
        "touches_svg_template_tryon_py": False,
        "local_input_image": str(input_copy_path),
        "local_mask": str(mask_path),
        "prompt_file": str(prompt_path),
        "expected_output": str(output_path),
        "include_frame_preview": include_frame_preview,
        "frame_preview_only": args.frame_preview_only,
        "frame_preview_prompt_file": str(frame_preview_prompt_path) if include_frame_preview else None,
        "frame_preview_request_file": str(frame_preview_request_path) if include_frame_preview else None,
        "frame_preview_expected_output": str(frame_preview_output_path) if include_frame_preview else None,
        "image_hash": image_hash(args.image),
        "model": args.model,
        "endpoint": endpoint_for_model(args.model),
        "quality": args.quality,
        "size": args.size,
        "output_format": args.output_format,
        "image_url": image_url,
        "mask_url": mask_url,
        "style_options": asdict(style),
        "measurements": round_value(measurements),
        "fit": round_value(asdict(fit)),
        "payload": payload,
        "rules": {
            "front_tryon_has_arms": bool(style.arm_text),
            "front_tryon_has_hinge_tabs": False,
            "front_tryon_has_engraving": bool(style.arm_text),
            "eyes_must_remain_visible": True,
            "bridge_sits_above_nose": True,
            "lens_width_plus_bridge_width_equals_eye_distance": True,
            "customer_arm_text_allowed": bool(style.arm_text),
            "custom_frame_edit_allowed": bool(style.frame_edit),
        },
    }
    save_json(request_path, request_info)

    if include_frame_preview and frame_preview_payload is not None:
        frame_preview_request_info = {
            "stage": "FRAMEANA Stage 2C-3 - ChatGPT Segmind GPT Image Frame Preview",
            "mode": args.mode,
            "uses_port_8000": False,
            "touches_main_py": False,
            "touches_face_py": False,
            "touches_svg_template_tryon_py": False,
            "preview_type": "frame_product_front_and_side",
            "prompt_file": str(frame_preview_prompt_path),
            "expected_output": str(frame_preview_output_path),
            "model": args.model,
            "endpoint": endpoint_for_model(args.model),
            "quality": args.quality,
            "size": args.frame_preview_size,
            "output_format": args.output_format,
            "style_options": asdict(style),
            "payload": frame_preview_payload,
            "rules": {
                "no_person": True,
                "front_view_included": True,
                "side_view_included": True,
                "customer_arm_text_on_arm_not_hinge": bool(style.arm_text),
                "no_labels_or_ui": True,
            },
        }
        save_json(frame_preview_request_path, frame_preview_request_info)

    print("FRAMEANA Stage 2C-3 - ChatGPT Segmind GPT Image Try-On")
    print("No FastAPI server. No port 8000. Core files untouched.")
    print(f"Local image copy: {input_copy_path}")
    print(f"Mask:             {mask_path}")
    print(f"Prompt:           {prompt_path}")
    print(f"Request JSON:     {request_path}")
    print(f"Expected output:  {output_path}")
    if include_frame_preview:
        print(f"Frame prompt:     {frame_preview_prompt_path}")
        print(f"Frame request:    {frame_preview_request_path}")
        print(f"Frame output:     {frame_preview_output_path}")
    print("")
    print("Computed fit:")
    print(json.dumps(round_value(asdict(fit)), ensure_ascii=False, indent=2))
    print("")
    print("Style options:")
    print(json.dumps(asdict(style), ensure_ascii=False, indent=2))
    if tunnel and tunnel.public_url:
        print("")
        print(f"Auto public URL: {tunnel.public_url}")

    if args.mode == "prepare":
        print("")
        print("PREPARE ONLY: no Segmind API call was made.")
        print("Next options:")
        print("1) Upload the local image copy and mask to Segmind Playground manually.")
        print("2) Or host chatgpt_output publicly and run --mode call with --public-base-url.")
        print("3) Or pass --image-url and --mask-url directly.")
        return 0

    api_key = resolve_api_key(args.api_key, args.api_key_file)
    if not api_key:
        print("", file=sys.stderr)
        print("ERROR: Missing Segmind API key.", file=sys.stderr)
        print("Set it on Windows:", file=sys.stderr)
        print("  set SEGMIND_API_KEY=your_key_here", file=sys.stderr)
        print("Or create segmind_api_key.txt beside chatgpt_segmind_tryon.py.", file=sys.stderr)
        return 1

    if args.frame_preview_only:
        if frame_preview_payload is None:
            print("", file=sys.stderr)
            print("ERROR: --frame-preview-only needs a frame preview payload.", file=sys.stderr)
            return 3

        try:
            frame_result = call_segmind(
                api_key=api_key,
                model=args.model,
                payload=frame_preview_payload,
                output_path=frame_preview_output_path,
                response_json_path=frame_preview_response_path,
                timeout=args.timeout,
            )
        except Exception as exc:
            print("", file=sys.stderr)
            print("Segmind frame preview call failed.", file=sys.stderr)
            print(str(exc), file=sys.stderr)
            print("", file=sys.stderr)
            print("Check:", file=sys.stderr)
            print("1) SEGMIND_API_KEY", file=sys.stderr)
            print("2) model supports text-only product preview generation", file=sys.stderr)
            print("3) credits/subscription", file=sys.stderr)
            print("4) try --quality low --frame-preview-size 1024x1024", file=sys.stderr)
            return 3

        print("")
        print("Segmind frame preview call completed.")
        print(f"Frame response JSON: {frame_preview_response_path}")
        if frame_preview_output_path.exists():
            print(f"Generated frame preview: {frame_preview_output_path}")
        else:
            print("No frame preview image file was saved. Check response JSON.")
        print(json.dumps(round_value(frame_result), ensure_ascii=False, indent=2))
        return 0

    if not is_http_url(image_url):
        print("", file=sys.stderr)
        print("ERROR: --mode call needs a public --image-url or --public-base-url.", file=sys.stderr)
        return 1

    if args.model == "gpt-image-2" and not is_http_url(mask_url):
        print("", file=sys.stderr)
        print("ERROR: gpt-image-2 surgical edit needs a public --mask-url or --public-base-url.", file=sys.stderr)
        return 1

    if args.model == "gpt-image-1-edit" and not is_http_url(mask_url):
        print("", file=sys.stderr)
        print("ERROR: gpt-image-1-edit needs a public --mask-url or --public-base-url.", file=sys.stderr)
        return 1

    try:
        result = call_segmind(
            api_key=api_key,
            model=args.model,
            payload=payload,
            output_path=output_path,
            response_json_path=response_path,
            timeout=args.timeout,
        )
    except Exception as exc:
        print("", file=sys.stderr)
        print("Segmind call failed.", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        print("", file=sys.stderr)
        print("Check:", file=sys.stderr)
        print("1) SEGMIND_API_KEY", file=sys.stderr)
        print("2) image_url and mask_url are public and open in browser", file=sys.stderr)
        print("3) credits/subscription", file=sys.stderr)
        print("4) try --quality low --size 1024x1536", file=sys.stderr)
        return 2

    print("")
    print("Segmind call completed.")
    print(f"Response JSON: {response_path}")
    if output_path.exists():
        print(f"Generated image: {output_path}")
    else:
        print("No image file was saved. Check response JSON.")
    print(json.dumps(round_value(result), ensure_ascii=False, indent=2))

    if include_frame_preview:
        if frame_preview_payload is None:
            print("", file=sys.stderr)
            print("ERROR: Frame preview payload was not prepared.", file=sys.stderr)
            return 3

        try:
            frame_result = call_segmind(
                api_key=api_key,
                model=args.model,
                payload=frame_preview_payload,
                output_path=frame_preview_output_path,
                response_json_path=frame_preview_response_path,
                timeout=args.timeout,
            )
        except Exception as exc:
            print("", file=sys.stderr)
            print("Segmind frame preview call failed.", file=sys.stderr)
            print(str(exc), file=sys.stderr)
            print("", file=sys.stderr)
            print("Check:", file=sys.stderr)
            print("1) SEGMIND_API_KEY", file=sys.stderr)
            print("2) model supports text-only product preview generation", file=sys.stderr)
            print("3) credits/subscription", file=sys.stderr)
            print("4) try --quality low --frame-preview-size 1024x1024", file=sys.stderr)
            return 3

        print("")
        print("Segmind frame preview call completed.")
        print(f"Frame response JSON: {frame_preview_response_path}")
        if frame_preview_output_path.exists():
            print(f"Generated frame preview: {frame_preview_output_path}")
        else:
            print("No frame preview image file was saved. Check response JSON.")
        print(json.dumps(round_value(frame_result), ensure_ascii=False, indent=2))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
