# FRAMEANA Responsive Frontend V3

This version adds two manual interface buttons under the centered FRAMEANA logo:

- **Laptop**
- **Mobile**

## How it works

- `Laptop` uses the full responsive laptop layout.
- `Mobile` reduces the application container to approximately `430px`.
- The responsive CSS uses **container queries**, so selecting Mobile activates the real mobile layout even while testing on a laptop.
- The chosen mode is saved in `localStorage` under:

  `FRAMEANA_DEVICE_MODE`

The V2 corrections remain included:

- centered official logo
- no duplicated logo text
- complete image display
- no cropped face
- full-screen image viewer

## Safe installation

Extract the ZIP and run:

`install_frameana_frontend_responsive_v3.bat`

A timestamped backup is created first:

`C:\Users\Dell\glasses-app\src\frameana\src\backup_before_responsive_v3_YYYYMMDD_HHMMSS`

## Run

```bat
cd /d C:\Users\Dell\glasses-app\src\frameana
npm start
```

Then refresh with:

`Ctrl + F5`
