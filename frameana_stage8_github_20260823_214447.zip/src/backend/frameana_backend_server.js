"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { resolveReferenceImagePath, runFrameGenerator } = require("./frameana_generator_adapter");
const { createStage8Store } = require("./frameana_stage8_store");

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "127.0.0.1";
const BASE_DIR = __dirname;
const DEFAULT_DATA_DIR = process.platform === "win32" ? "D:\\FRAMEANA\\data" : path.join(BASE_DIR, "data");
const DATA_DIR = path.resolve(process.env.FRAMEANA_DATA_DIR || DEFAULT_DATA_DIR);
const JOBS_DIR = path.resolve(process.env.FRAMEANA_JOBS_DIR || path.join(DATA_DIR, "jobs"));
const DB_PATH = path.resolve(process.env.FRAMEANA_DB_PATH || path.join(DATA_DIR, "frameana.sqlite"));
const JWT_SECRET = process.env.FRAMEANA_JWT_SECRET || "frameana-stage8-local-dev-secret-change-me";
const ADMIN_TOKEN = safeText(process.env.FRAMEANA_ADMIN_TOKEN || "");
const GENERATOR_PATH = path.resolve(
  process.env.FRAMEANA_GENERATOR_PATH || path.join(BASE_DIR, "frameana_image2stl_generator.js")
);
const TRYON_API_URL = (process.env.FRAMEANA_TRYON_API_URL || "").trim();
const TRYON_TIMEOUT_MS = Number(process.env.FRAMEANA_TRYON_TIMEOUT_MS || 30000);
const AI_TRYON_IMAGE_PATH = path.resolve(
  process.env.FRAMEANA_AI_TRYON_IMAGE_PATH || path.join(BASE_DIR, "references", "frame_tryon.png")
);
const SEGMIND_SCRIPT_PATH = path.resolve(
  process.env.FRAMEANA_SEGMIND_SCRIPT_PATH || path.join(BASE_DIR, "..", "chatgpt_segmind_tryon.py")
);
const SEGMIND_API_KEY_FILE = path.resolve(
  process.env.FRAMEANA_SEGMIND_API_KEY_FILE || path.join(BASE_DIR, "..", "segmind_api_key.txt")
);
const DEFAULT_VENV_PYTHON = path.resolve(BASE_DIR, "..", "venv", "Scripts", "python.exe");
const PYTHON_EXE = process.env.FRAMEANA_PYTHON_EXE || (fs.existsSync(DEFAULT_VENV_PYTHON) ? DEFAULT_VENV_PYTHON : "python");
const SEGMIND_LIVE_MODE = safeText(process.env.FRAMEANA_SEGMIND_LIVE, "auto").toLowerCase();
const SEGMIND_FRAME_PREVIEW_MODE = safeText(process.env.FRAMEANA_SEGMIND_FRAME_PREVIEW, "auto").toLowerCase();
const SEGMIND_TIMEOUT_MS = Number(process.env.FRAMEANA_SEGMIND_TIMEOUT_MS || 420000);
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const MAX_JOB_FOLDERS = Math.max(3, Number(process.env.FRAMEANA_MAX_JOB_FOLDERS || 12));

const ALLOWED_STYLES = new Set(["classic", "round", "sport"]);
const ALLOWED_MATERIALS = new Set(["acetate", "nylon", "pla"]);
const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const NAMED_FRAME_COLORS = new Set(["tortoise", "black", "brown", "navy", "gold"]);
const DEFAULT_FRONT_CROP = { x: 210, y: 20, width: 1120, height: 370 };
const DEFAULT_SIDE_CROP = { x: 340, y: 392, width: 1005, height: 275 };

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(JOBS_DIR, { recursive: true });
const stage8Store = createStage8Store({ dbPath: DB_PATH, jwtSecret: JWT_SECRET });

const app = express();
app.disable("x-powered-by");
app.use(cors({ origin: true, credentials: false }));
app.use(express.json({ limit: "3mb" }));
app.use("/outputs", express.static(JOBS_DIR, { fallthrough: false, maxAge: "5m" }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES, files: 1 },
  fileFilter: (_request, file, callback) => {
    if (!ALLOWED_IMAGE_TYPES.has(file.mimetype)) {
      callback(new Error("نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP."));
      return;
    }
    callback(null, true);
  },
});

function bearerToken(request) {
  const header = request.get("authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : "";
}

function requireUser(request, response, next) {
  try {
    request.user = stage8Store.getUserByToken(bearerToken(request));
    next();
  } catch (error) {
    response.status(error.httpStatus || 401).json({
      status: "error",
      message: error.message || "تسجيل الدخول مطلوب.",
    });
  }
}

function requireAdmin(request, response, next) {
  const adminHeader = safeText(request.get("x-frameana-admin-token") || "");
  const adminHeaderBuffer = Buffer.from(adminHeader);
  const adminTokenBuffer = Buffer.from(ADMIN_TOKEN);
  if (
    ADMIN_TOKEN &&
    adminHeader &&
    adminHeaderBuffer.length === adminTokenBuffer.length &&
    crypto.timingSafeEqual(adminHeaderBuffer, adminTokenBuffer)
  ) {
    request.adminUser = null;
    next();
    return;
  }

  try {
    const user = stage8Store.getUserByToken(bearerToken(request));
    if (!user.is_admin) {
      response.status(403).json({ status: "error", message: "صلاحيات الإدارة مطلوبة." });
      return;
    }
    request.adminUser = user;
    next();
  } catch (error) {
    response.status(error.httpStatus || 401).json({
      status: "error",
      message: error.message || "تسجيل دخول الإدارة مطلوب.",
    });
  }
}

function sendStage8Error(response, error) {
  console.error("FRAMEANA Stage 8 API error:", error);
  response.status(error.httpStatus || 500).json({
    status: "error",
    message: error.message || "حدث خطأ غير متوقع في المرحلة 8.",
  });
}

function safeText(value, fallback = "") {
  if (typeof value !== "string") return fallback;
  return value.replace(/[\u0000-\u001f\u007f]/g, "").trim();
}

function directorySizeBytes(dirPath) {
  let total = 0;
  try {
    for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
      const entryPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        total += directorySizeBytes(entryPath);
      } else if (entry.isFile()) {
        total += fs.statSync(entryPath).size;
      }
    }
  } catch {
    return total;
  }
  return total;
}

function pruneOldJobFolders(excludeJobId = "") {
  let entries = [];
  try {
    entries = fs.readdirSync(JOBS_DIR, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && entry.name !== excludeJobId)
      .map((entry) => {
        const fullPath = path.join(JOBS_DIR, entry.name);
        const stat = fs.statSync(fullPath);
        return { name: entry.name, fullPath, mtimeMs: stat.mtimeMs };
      })
      .sort((a, b) => b.mtimeMs - a.mtimeMs);
  } catch (error) {
    console.warn("Could not inspect old job folders:", error.message);
    return;
  }

  const removable = entries.slice(MAX_JOB_FOLDERS);
  let removed = 0;
  let freedBytes = 0;

  for (const job of removable) {
    const resolved = path.resolve(job.fullPath);
    if (!resolved.startsWith(`${JOBS_DIR}${path.sep}`)) continue;
    freedBytes += directorySizeBytes(resolved);
    fs.rmSync(resolved, { recursive: true, force: true });
    removed += 1;
  }

  if (removed > 0) {
    console.log(
      `Pruned ${removed} old FRAMEANA job folders, freed about ${Math.round(freedBytes / 1024 / 1024)} MB.`
    );
  }
}

function validHexColor(value, fallback) {
  const normalized = safeText(value);
  return /^#[0-9a-fA-F]{6}$/.test(normalized) ? normalized.toUpperCase() : fallback;
}

function normalizeFrameColor(value) {
  const normalized = safeText(value).toLowerCase();
  if (!normalized || normalized === "#1f2d57") return "tortoise";
  if (NAMED_FRAME_COLORS.has(normalized)) return normalized;
  return validHexColor(value, "tortoise");
}

function cssColor(value, fallback = "#6B3A18") {
  const normalized = safeText(value).toLowerCase();
  const named = {
    tortoise: "#6B3A18",
    brown: "#6B3A18",
    black: "#111111",
    navy: "#1F2D57",
    gold: "#C9A14A",
  };

  if (named[normalized]) return named[normalized];
  return validHexColor(value, fallback);
}

function normalizeStyle(value) {
  const style = safeText(value, "classic").toLowerCase();
  return ALLOWED_STYLES.has(style) ? style : "classic";
}

function normalizeMaterial(value) {
  const material = safeText(value, "acetate").toLowerCase();
  return ALLOWED_MATERIALS.has(material) ? material : "acetate";
}

function extensionForMime(mimeType) {
  if (mimeType === "image/png") return ".png";
  if (mimeType === "image/webp") return ".webp";
  return ".jpg";
}

function mimeForPath(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  if (extension === ".png") return "image/png";
  if (extension === ".webp") return "image/webp";
  if (extension === ".svg") return "image/svg+xml";
  return "image/jpeg";
}

function clamp(value, minValue, maxValue) {
  return Math.max(minValue, Math.min(maxValue, value));
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function toDataUri(filePath) {
  const mimeType = mimeForPath(filePath);
  const data = fs.readFileSync(filePath).toString("base64");
  return `data:${mimeType};base64,${data}`;
}

function readPngDimensions(buffer) {
  if (buffer.length < 24 || buffer.toString("ascii", 1, 4) !== "PNG") return null;
  return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
}

function readJpegDimensions(buffer) {
  if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) return null;

  let offset = 2;
  while (offset < buffer.length - 9) {
    if (buffer[offset] !== 0xff) {
      offset += 1;
      continue;
    }

    const marker = buffer[offset + 1];
    const length = buffer.readUInt16BE(offset + 2);
    if (length < 2) return null;

    const isStartOfFrame =
      (marker >= 0xc0 && marker <= 0xc3) ||
      (marker >= 0xc5 && marker <= 0xc7) ||
      (marker >= 0xc9 && marker <= 0xcb) ||
      (marker >= 0xcd && marker <= 0xcf);

    if (isStartOfFrame) {
      return {
        width: buffer.readUInt16BE(offset + 7),
        height: buffer.readUInt16BE(offset + 5),
      };
    }

    offset += 2 + length;
  }

  return null;
}

function readWebpDimensions(buffer) {
  if (
    buffer.length < 30 ||
    buffer.toString("ascii", 0, 4) !== "RIFF" ||
    buffer.toString("ascii", 8, 12) !== "WEBP"
  ) {
    return null;
  }

  const chunk = buffer.toString("ascii", 12, 16);
  if (chunk === "VP8X" && buffer.length >= 30) {
    return {
      width: 1 + buffer.readUIntLE(24, 3),
      height: 1 + buffer.readUIntLE(27, 3),
    };
  }

  if (chunk === "VP8 " && buffer.length >= 30) {
    return {
      width: buffer.readUInt16LE(26) & 0x3fff,
      height: buffer.readUInt16LE(28) & 0x3fff,
    };
  }

  return null;
}

function readImageDimensions(filePath, fallback = { width: 900, height: 1100 }) {
  const buffer = fs.readFileSync(filePath);
  return readPngDimensions(buffer) || readJpegDimensions(buffer) || readWebpDimensions(buffer) || fallback;
}

function scaledStage2C4Crops(referenceImagePath) {
  const dimensions = readImageDimensions(referenceImagePath, { width: 1254, height: 1254 });
  const scaleX = dimensions.width / 1254;
  const scaleY = dimensions.height / 1254;
  const scaleCrop = ([x, y, width, height]) =>
    [x * scaleX, y * scaleY, width * scaleX, height * scaleY]
      .map((value) => Math.max(1, Math.round(value)))
      .join(",");

  return {
    frontCrop: scaleCrop([55, 105, 1145, 500]),
    sideCrop: scaleCrop([230, 735, 955, 365]),
  };
}

function firstExisting(outputDir, names) {
  for (const name of names) {
    const candidate = path.join(outputDir, name);
    try {
      if (fs.statSync(candidate).isFile()) return name;
    } catch {
      // Continue searching.
    }
  }
  return null;
}

function fileExists(filePath) {
  try {
    return fs.statSync(filePath).isFile();
  } catch {
    return false;
  }
}

function segmindLiveEnabled() {
  if (["0", "false", "off", "no"].includes(SEGMIND_LIVE_MODE)) return false;
  if (["1", "true", "on", "yes"].includes(SEGMIND_LIVE_MODE)) return true;
  return fileExists(SEGMIND_SCRIPT_PATH) && fileExists(SEGMIND_API_KEY_FILE);
}

function segmindFramePreviewEnabled() {
  if (SEGMIND_FRAME_PREVIEW_MODE === "auto") return segmindLiveEnabled();
  return ["1", "true", "on", "yes"].includes(SEGMIND_FRAME_PREVIEW_MODE);
}

function runCommandCapture(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: { ...process.env, ...(options.env || {}) },
      shell: false,
      windowsHide: true,
    });

    let stdout = "";
    let stderr = "";
    const timeout = setTimeout(() => {
      child.kill("SIGTERM");
      reject(new Error(`${path.basename(command)} timed out after ${options.timeoutMs}ms.`));
    }, options.timeoutMs || 300000);

    child.stdout.on("data", (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", (code) => {
      clearTimeout(timeout);
      if (code === 0) {
        resolve({ stdout, stderr, code });
        return;
      }
      const error = new Error(stderr || stdout || `${path.basename(command)} exited with code ${code}.`);
      error.code = code;
      error.stdout = stdout;
      error.stderr = stderr;
      reject(error);
    });
  });
}

function lensShapeSvg({ style, x, y, width, height, radius }) {
  if (style === "round") {
    return `<ellipse cx="${x + width / 2}" cy="${y + height / 2}" rx="${width / 2}" ry="${height / 2}" />`;
  }

  if (style === "classic") {
    const topY = y + height * 0.03;
    const bottomY = y + height * 0.94;
    const leftTop = x + width * 0.07;
    const rightTop = x + width * 0.97;
    const rightBottom = x + width * 0.82;
    const leftBottom = x + width * 0.16;
    return `<path d="M ${leftTop} ${topY} C ${x + width * 0.34} ${y - height * 0.02}, ${x + width * 0.71} ${y - height * 0.02}, ${rightTop} ${topY} L ${rightBottom} ${bottomY} C ${x + width * 0.61} ${y + height * 1.05}, ${x + width * 0.35} ${y + height * 1.05}, ${leftBottom} ${bottomY} Z" />`;
  }

  if (style === "sport") {
    const points = [
      [x + width * 0.08, y + height * 0.12],
      [x + width * 0.92, y],
      [x + width, y + height * 0.5],
      [x + width * 0.84, y + height],
      [x + width * 0.12, y + height * 0.92],
      [x, y + height * 0.42],
    ];
    return `<polygon points="${points.map((point) => point.join(",")).join(" ")}" />`;
  }

  return `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="${radius}" ry="${radius}" />`;
}

function createLocalTryonPreview(inputImagePath, outputDir, config) {
  const dimensions = readImageDimensions(inputImagePath);
  const width = dimensions.width;
  const height = dimensions.height;
  const frameColor = cssColor(config.frame_color);
  const engravingColor = cssColor(config.engraving_color, "#C9A14A");
  const frameWidth = clamp(width * 0.56, width * 0.42, width * 0.72);
  const lensWidth = frameWidth * 0.36;
  const lensHeight =
    config.style === "sport" ? lensWidth * 0.52 : config.style === "round" ? lensWidth * 0.94 : lensWidth * 0.86;
  const bridgeWidth = frameWidth * 0.11;
  const strokeWidth = clamp(width * 0.016, 7, 18);
  const centerX = width / 2;
  const centerY = height * (height > width ? 0.405 : 0.46);
  const leftX = centerX - bridgeWidth / 2 - lensWidth;
  const rightX = centerX + bridgeWidth / 2;
  const lensY = centerY - lensHeight / 2;
  const radius = lensHeight * 0.3;
  const templeInset = lensWidth * 0.33;
  const dataUri = toDataUri(inputImagePath);
  const engraving = escapeXml(config.engraving || "");

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <image href="${dataUri}" x="0" y="0" width="${width}" height="${height}" preserveAspectRatio="xMidYMid slice"/>
  <g fill="none" stroke="${escapeXml(frameColor)}" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round">
    ${lensShapeSvg({ style: config.style, x: leftX, y: lensY, width: lensWidth, height: lensHeight, radius })}
    ${lensShapeSvg({ style: config.style, x: rightX, y: lensY, width: lensWidth, height: lensHeight, radius })}
    <path d="M ${leftX + lensWidth} ${centerY - lensHeight * 0.07} C ${centerX - bridgeWidth * 0.25} ${centerY - lensHeight * 0.22}, ${centerX + bridgeWidth * 0.25} ${centerY - lensHeight * 0.22}, ${rightX} ${centerY - lensHeight * 0.07}" />
    <path d="M ${leftX + lensWidth * 0.06} ${centerY - lensHeight * 0.1} L ${clamp(leftX - templeInset, 8, width)} ${centerY - lensHeight * 0.2}" />
    <path d="M ${rightX + lensWidth * 0.94} ${centerY - lensHeight * 0.1} L ${clamp(rightX + lensWidth + templeInset, 0, width - 8)} ${centerY - lensHeight * 0.2}" />
  </g>
  <g fill="${escapeXml(engravingColor)}" opacity="0.9">
    <circle cx="${leftX + lensWidth * 0.18}" cy="${lensY + lensHeight * 0.22}" r="${strokeWidth * 0.42}"/>
    <circle cx="${rightX + lensWidth * 0.82}" cy="${lensY + lensHeight * 0.22}" r="${strokeWidth * 0.42}"/>
  </g>
  ${
    engraving
      ? `<text x="${rightX + lensWidth + strokeWidth}" y="${centerY - lensHeight * 0.25}" font-family="Arial, sans-serif" font-size="${Math.max(11, strokeWidth * 1.8)}" font-weight="700" fill="${escapeXml(engravingColor)}">${engraving}</text>`
      : ""
  }
</svg>`;

  const filename = "customer_tryon.svg";
  fs.writeFileSync(path.join(outputDir, filename), svg, "utf8");
  return filename;
}

function cropImageElement({ dataUri, source, crop, x, y, width, height, clipId, mirror = false }) {
  const scale = Math.min(width / crop.width, height / crop.height);
  const imageWidth = source.width * scale;
  const imageHeight = source.height * scale;
  const imageX = x + (width - crop.width * scale) / 2 - crop.x * scale;
  const imageY = y + (height - crop.height * scale) / 2 - crop.y * scale;
  const transform = mirror ? ` transform="translate(${x + width} 0) scale(-1 1)"` : "";
  const drawX = mirror ? -x - width + imageX : imageX;

  return `<g clip-path="url(#${clipId})"${transform}><image href="${dataUri}" x="${drawX}" y="${imageY}" width="${imageWidth}" height="${imageHeight}" preserveAspectRatio="none"/></g>`;
}

function createFrameOrthographicPreview(referenceImagePath, outputDir, config) {
  const extension = path.extname(referenceImagePath).toLowerCase();
  const safeExtension = [".png", ".jpg", ".jpeg", ".webp"].includes(extension) ? extension : ".png";
  const filename = `frame_orthographic_views${safeExtension}`;
  const outputPath = path.join(outputDir, filename);

  fs.copyFileSync(referenceImagePath, outputPath);
  writeJson(path.join(outputDir, "frame_orthographic_source.json"), {
    stage: "FRAMEANA Stage 2C-6",
    source_stage: "FRAMEANA Stage 2C-4 - accepted AI frame reference",
    source_role: "front_and_side_frame_reference_for_preview_and_stl",
    source_image: referenceImagePath,
    output_image: outputPath,
    customization: {
      style: config.style,
      material: config.material,
      frame_color: config.frame_color,
      engraving: config.engraving,
      engraving_color: config.engraving_color,
    },
  });

  return filename;
}

function publicOutputUrl(jobId, outputName) {
  if (!outputName) return null;
  return `/outputs/${encodeURIComponent(jobId)}/output/${encodeURIComponent(outputName)}`;
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
}

function mergeMetadata(metadataPath, requestConfig, jobId) {
  const existing = readJson(metadataPath);
  const merged = {
    ...existing,
    stage: "FRAMEANA Stage 2C-6",
    job_id: jobId,
    style: existing.style || requestConfig.style,
    material: existing.material || requestConfig.material,
    frame_color: existing.frame_color || existing.color || requestConfig.frame_color,
    engraving_text:
      existing.engraving_text || existing.engraving?.text || requestConfig.engraving,
    engraving_color:
      existing.engraving_color || existing.engraving?.color || requestConfig.engraving_color,
    customization: {
      ...(existing.customization || {}),
      style: requestConfig.style,
      material: requestConfig.material,
      frame_color: requestConfig.frame_color,
      engraving: requestConfig.engraving,
      engraving_color: requestConfig.engraving_color,
    },
  };

  writeJson(metadataPath, merged);
  return merged;
}

async function requestSegmindLiveAssets({ inputImagePath, outputDir, config }) {
  if (!segmindLiveEnabled()) return null;

  const segmindDir = path.join(outputDir, "segmind_live");
  fs.mkdirSync(segmindDir, { recursive: true });

  const frameShape = ALLOWED_STYLES.has(config.style) ? config.style : "classic";
  const includeFramePreview = segmindFramePreviewEnabled();
  const args = [
    SEGMIND_SCRIPT_PATH,
    "--image",
    inputImagePath,
    "--output-dir",
    segmindDir,
    "--mode",
    "call",
    "--auto-public-url",
    "--api-key-file",
    SEGMIND_API_KEY_FILE,
    "--frame-color",
    config.frame_color,
    "--frame-shape",
    frameShape,
    "--arm-text",
    config.engraving,
    "--arm-text-color",
    config.engraving_color,
    "--quality",
    process.env.FRAMEANA_SEGMIND_QUALITY || "low",
    "--size",
    process.env.FRAMEANA_SEGMIND_TRYON_SIZE || "1024x1536",
    "--frame-preview-size",
    process.env.FRAMEANA_SEGMIND_FRAME_SIZE || "1024x1024",
    "--output-format",
    "png",
    "--timeout",
    String(Math.ceil(SEGMIND_TIMEOUT_MS / 1000)),
  ];
  if (includeFramePreview) args.push("--include-frame-preview");

  await runCommandCapture(PYTHON_EXE, args, {
    cwd: path.dirname(SEGMIND_SCRIPT_PATH),
    timeoutMs: SEGMIND_TIMEOUT_MS,
  });

  const tryonOutput = path.join(segmindDir, "chatgpt_segmind_tryon.png");
  const frameOutput = path.join(segmindDir, "chatgpt_frame_preview.png");
  const result = {
    customerTryonName: null,
    frameReferencePath: null,
    frameOrthographicName: null,
    sourceDir: segmindDir,
  };

  if (fileExists(tryonOutput)) {
    result.customerTryonName = "customer_tryon.png";
    fs.copyFileSync(tryonOutput, path.join(outputDir, result.customerTryonName));
  }

  if (fileExists(frameOutput)) {
    result.frameReferencePath = path.join(outputDir, "ai_frame_reference.png");
    result.frameOrthographicName = "frame_orthographic_views.png";
    fs.copyFileSync(frameOutput, result.frameReferencePath);
    fs.copyFileSync(frameOutput, path.join(outputDir, result.frameOrthographicName));
  }

  writeJson(path.join(outputDir, "segmind_live_assets.json"), {
    stage: "FRAMEANA Stage 2C-6",
    source_stage: "Segmind GPT Image live generation",
    segmind_output_dir: segmindDir,
    frame_preview_requested: includeFramePreview,
    customer_tryon: result.customerTryonName,
    frame_reference: result.frameReferencePath,
    frame_orthographic: result.frameOrthographicName,
  });

  return result.customerTryonName || result.frameReferencePath ? result : null;
}

async function requestTryonPreview({ inputImagePath, outputDir, config }) {
  if (!TRYON_API_URL) return null;

  const imageBuffer = fs.readFileSync(inputImagePath);
  const form = new FormData();
  const blob = new Blob([imageBuffer]);
  form.append("image", blob, path.basename(inputImagePath));
  form.append("file", blob, path.basename(inputImagePath));
  form.append("style", config.style);
  form.append("selected_style", config.style);
  form.append("frame_shape", config.style);
  form.append("material", config.material);
  form.append("frame_color", config.frame_color);
  form.append("text", config.engraving);
  form.append("engraving", config.engraving);
  form.append("text_color", config.engraving_color);
  form.append("engraving_color", config.engraving_color);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TRYON_TIMEOUT_MS);

  let payload = {};
  try {
    const response = await fetch(TRYON_API_URL, {
      method: "POST",
      body: form,
      signal: controller.signal,
    });
    payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.status === "error") {
      throw new Error(
        payload.message || payload.detail || `Try-on service failed with HTTP ${response.status}`
      );
    }
  } finally {
    clearTimeout(timeout);
  }

  const remotePath =
    payload.outputs?.customer_tryon ||
    payload.outputs?.segmind_tryon ||
    payload.outputs?.tryon_realistic ||
    payload.result_image ||
    payload.output_image ||
    payload.output;

  if (!remotePath) return null;
  const remoteUrl = /^https?:\/\//i.test(remotePath)
    ? remotePath
    : new URL(remotePath, TRYON_API_URL).href;

  const imageResponse = await fetch(remoteUrl);
  if (!imageResponse.ok) return null;
  const contentType = imageResponse.headers.get("content-type") || "image/png";
  const extension = contentType.includes("jpeg") ? ".jpg" : contentType.includes("webp") ? ".webp" : ".png";
  const filename = `customer_tryon${extension}`;
  const destination = path.join(outputDir, filename);
  const bytes = Buffer.from(await imageResponse.arrayBuffer());
  fs.writeFileSync(destination, bytes);
  return filename;
}

function copyAiTryonPreview(outputDir) {
  if (!fs.existsSync(AI_TRYON_IMAGE_PATH)) return null;

  const extension = path.extname(AI_TRYON_IMAGE_PATH).toLowerCase();
  const safeExtension = [".png", ".jpg", ".jpeg", ".webp"].includes(extension) ? extension : ".png";
  const filename = `customer_tryon${safeExtension}`;
  const destination = path.join(outputDir, filename);

  fs.copyFileSync(AI_TRYON_IMAGE_PATH, destination);
  writeJson(path.join(outputDir, "customer_tryon_source.json"), {
    stage: "FRAMEANA Stage 2C-6",
    source_stage: "FRAMEANA Stage 2C-4 / AI try-on",
    source_role: "realistic_customer_tryon_preview",
    source_image: AI_TRYON_IMAGE_PATH,
    output_image: destination,
  });

  return filename;
}

app.post("/api/auth/register", (request, response) => {
  try {
    const result = stage8Store.registerUser(request.body);
    response.status(201).json({ status: "success", ...result });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.post("/api/auth/login", (request, response) => {
  try {
    const result = stage8Store.loginUser(request.body);
    response.json({ status: "success", ...result });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.get("/api/auth/me", requireUser, (request, response) => {
  response.json({ status: "success", user: request.user });
});

app.post("/api/orders", requireUser, (request, response) => {
  try {
    const order = stage8Store.createOrder({
      userId: request.user.id,
      status: request.body?.status,
      design: request.body?.design,
    });
    response.status(201).json({ status: "success", order });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.get("/api/orders", requireUser, (request, response) => {
  try {
    response.json({ status: "success", orders: stage8Store.listOrders(request.user.id) });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.get("/api/orders/:orderId", requireUser, (request, response) => {
  try {
    const order = stage8Store.getOrder(request.user.id, Number(request.params.orderId));
    response.json({ status: "success", order });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.post("/api/orders/:orderId/submit", requireUser, (request, response) => {
  try {
    const order = stage8Store.submitOrder(request.user.id, Number(request.params.orderId));
    response.json({ status: "success", order });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.delete("/api/orders/:orderId", requireUser, (request, response) => {
  try {
    const result = stage8Store.deleteOrder(request.user.id, Number(request.params.orderId));
    response.json({ status: "success", ...result });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.post("/api/orders/:orderId/feedback", requireUser, (request, response) => {
  try {
    const order = stage8Store.addFeedback(
      request.user.id,
      Number(request.params.orderId),
      request.body?.feedback
    );
    response.json({ status: "success", order });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.get("/api/admin/orders", requireAdmin, (_request, response) => {
  try {
    response.json({ status: "success", orders: stage8Store.listAdminOrders() });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.patch("/api/admin/orders/:orderId/status", requireAdmin, (request, response) => {
  try {
    const order = stage8Store.updateAdminStatus(
      Number(request.params.orderId),
      request.body?.status,
      request.adminUser?.id || null
    );
    response.json({ status: "success", order });
  } catch (error) {
    sendStage8Error(response, error);
  }
});

app.get("/api/health", (_request, response) => {
  let referenceImage = null;
  try {
    referenceImage = resolveReferenceImagePath({ generatorPath: GENERATOR_PATH, style: "classic" });
  } catch {
    referenceImage = null;
  }

  response.json({
    status: "ok",
    stage: "FRAMEANA Stage 8",
    generator_path: GENERATOR_PATH,
    generator_exists: fs.existsSync(GENERATOR_PATH),
    data_dir: DATA_DIR,
    db_path: DB_PATH,
    jobs_dir: JOBS_DIR,
    jobs_dir_exists: fs.existsSync(JOBS_DIR),
    reference_image: referenceImage,
    reference_image_exists: Boolean(referenceImage),
    ai_tryon_image: AI_TRYON_IMAGE_PATH,
    ai_tryon_image_exists: fs.existsSync(AI_TRYON_IMAGE_PATH),
    segmind_live_enabled: segmindLiveEnabled(),
    segmind_script: SEGMIND_SCRIPT_PATH,
    segmind_script_exists: fileExists(SEGMIND_SCRIPT_PATH),
    segmind_key_file_exists: fileExists(SEGMIND_API_KEY_FILE),
    python_exe: PYTHON_EXE,
    generator_mode: process.env.FRAMEANA_GENERATOR_MODE || "cli",
    tryon_service_enabled: Boolean(TRYON_API_URL),
    segmind_frame_preview_enabled: segmindFramePreviewEnabled(),
  });
});

app.post("/api/frameana/generate", upload.single("image"), async (request, response) => {
  const startedAt = Date.now();
  const jobId = `${Date.now()}-${crypto.randomUUID()}`;
  const jobDir = path.join(JOBS_DIR, jobId);
  const inputDir = path.join(jobDir, "input");
  const outputDir = path.join(jobDir, "output");

  try {
    pruneOldJobFolders(jobId);

    if (!request.file) {
      response.status(400).json({ status: "error", message: "الصورة مطلوبة." });
      return;
    }

    const config = {
      style: normalizeStyle(request.body.style),
      material: normalizeMaterial(request.body.material),
      frame_color: normalizeFrameColor(request.body.frame_color),
      engraving: safeText(request.body.engraving, "Nael").slice(0, 40),
      engraving_color: validHexColor(request.body.engraving_color, "#C9A14A"),
    };
    const referenceImagePath = resolveReferenceImagePath({
      generatorPath: GENERATOR_PATH,
      style: config.style,
    });

    fs.mkdirSync(inputDir, { recursive: true });
    fs.mkdirSync(outputDir, { recursive: true });

    const inputImagePath = path.join(inputDir, `customer${extensionForMime(request.file.mimetype)}`);
    fs.writeFileSync(inputImagePath, request.file.buffer);

    const configPath = path.join(jobDir, "generation_config.json");
    writeJson(configPath, {
      ...config,
      stage: "FRAMEANA Stage 2C-6",
      job_id: jobId,
      input_image: inputImagePath,
      reference_image: referenceImagePath,
      output_dir: outputDir,
    });

    let segmindAssets = null;
    try {
      segmindAssets = await requestSegmindLiveAssets({ inputImagePath, outputDir, config });
    } catch (segmindError) {
      console.warn("Segmind live generation warning:", segmindError.message);
    }

    const activeReferenceImagePath = segmindAssets?.frameReferencePath || referenceImagePath;
    const stage2c4Crops = scaledStage2C4Crops(activeReferenceImagePath);

    await runFrameGenerator({
      generatorPath: GENERATOR_PATH,
      inputImagePath,
      referenceImagePath: activeReferenceImagePath,
      outputDir,
      configPath,
      frontCrop: stage2c4Crops.frontCrop,
      sideCrop: stage2c4Crops.sideCrop,
      style: config.style,
      material: config.material,
      frameColor: config.frame_color,
      engraving: config.engraving,
      engravingColor: config.engraving_color,
    });

    const frameOrthographicName =
      segmindAssets?.frameOrthographicName || createFrameOrthographicPreview(activeReferenceImagePath, outputDir, config);

    let customerTryonName = segmindAssets?.customerTryonName || copyAiTryonPreview(outputDir);
    try {
      customerTryonName = customerTryonName || (await requestTryonPreview({ inputImagePath, outputDir, config }));
    } catch (tryonError) {
      console.warn("Try-on service warning:", tryonError.message);
    }

    customerTryonName =
      customerTryonName ||
      firstExisting(outputDir, [
        "customer_tryon.png",
        "customer_tryon.jpg",
        "customer_tryon.jpeg",
        "customer_tryon.webp",
        "customer_tryon.svg",
        "tryon_preview.png",
        "tryon.png",
        "preview_customer.png",
      ]) ||
      createLocalTryonPreview(inputImagePath, outputDir, config);

    const frame3dPreviewName = firstExisting(outputDir, [
      "frame_preview.png",
      "frame_preview.jpg",
      "preview.png",
      "frame_only.png",
      "product_preview.png",
      "frameana_image2stl_3d_preview.png",
    ]);
    const frontTraceName = firstExisting(outputDir, ["frameana_image2stl_front_trace.png"]);
    const sideTraceName = firstExisting(outputDir, ["frameana_image2stl_side_trace.png"]);
    const engravingStlName = firstExisting(outputDir, ["engraving.stl"]);

    const metadataPath = path.join(outputDir, "frame_metadata.json");
    const metadata = mergeMetadata(metadataPath, config, jobId);
    metadata.stage2c6_assets = {
      customer_tryon: customerTryonName,
      frame_orthographic: frameOrthographicName,
      frame_3d_preview: frame3dPreviewName,
      front_trace: frontTraceName,
      side_trace: sideTraceName,
      engraving_stl: engravingStlName,
    };
    writeJson(metadataPath, metadata);

    response.json({
      status: "success",
      stage: "FRAMEANA Stage 2C-6",
      job_id: jobId,
      duration_ms: Date.now() - startedAt,
      metadata,
      outputs: {
        customer_tryon: publicOutputUrl(jobId, customerTryonName),
        frame_preview: publicOutputUrl(jobId, frameOrthographicName || frame3dPreviewName),
        frame_orthographic: publicOutputUrl(jobId, frameOrthographicName),
        frame_3d_preview: publicOutputUrl(jobId, frame3dPreviewName),
        frame_front_trace: publicOutputUrl(jobId, frontTraceName),
        frame_side_trace: publicOutputUrl(jobId, sideTraceName),
        frame_metadata: publicOutputUrl(jobId, "frame_metadata.json"),
        frame_front: publicOutputUrl(jobId, "frame_front.stl"),
        left_arm: publicOutputUrl(jobId, "left_arm.stl"),
        right_arm: publicOutputUrl(jobId, "right_arm.stl"),
        full_frame: publicOutputUrl(jobId, "full_frame.stl"),
        engraving_stl: publicOutputUrl(jobId, engravingStlName),
        engraving: publicOutputUrl(jobId, engravingStlName),
      },
    });
  } catch (error) {
    console.error(`[${jobId}] Generation failed:`, error);
    response.status(500).json({
      status: "error",
      stage: "FRAMEANA Stage 2C-6",
      job_id: jobId,
      message: error.message || "حدث خطأ غير متوقع أثناء إنشاء التصميم.",
    });
  }
});

app.use((error, _request, response, _next) => {
  if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
    response.status(413).json({ status: "error", message: "حجم الصورة يتجاوز حد 10MB." });
    return;
  }

  response.status(400).json({
    status: "error",
    message: error.message || "الطلب غير صالح.",
  });
});

app.listen(PORT, HOST, () => {
  console.log(`FRAMEANA Stage 8 backend: http://${HOST}:${PORT}`);
  console.log(`Generator: ${GENERATOR_PATH}`);
  console.log(`Data: ${DATA_DIR}`);
  console.log(`Database: ${DB_PATH}`);
  console.log(`Outputs: ${JOBS_DIR}`);
});
