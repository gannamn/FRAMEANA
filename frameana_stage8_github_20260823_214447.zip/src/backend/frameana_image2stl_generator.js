#!/usr/bin/env node
"use strict";

/*
FRAMEANA Stage 2C-4/2C-5 - 2D reference image to STL

This generator treats the accepted 2D CAD reference image as the geometry source:
- top/front view -> frame_front.stl
- middle side view -> temple arms
- metadata keeps color/material/frontend provenance because STL is geometry only

No npm dependencies.
*/

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const DEFAULT_STYLE = {
  frame_color: "tortoise",
  material: "acetate",
  frame_shape: "round",
  arm_text: "Nael",
  arm_text_color: "gold",
  text_mode: "emboss",
};

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith("--")) continue;
    const key = token.slice(2).replace(/-/g, "_");
    const next = argv[i + 1];
    if (next === undefined || next.startsWith("--")) {
      args[key] = true;
    } else {
      args[key] = next;
      i += 1;
    }
  }
  return args;
}

function safeFloat(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function safeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n) : fallback;
}

function clamp(value, minValue, maxValue) {
  return Math.max(minValue, Math.min(maxValue, value));
}

function normalizeColorToken(value, fallback = "#1F2D57") {
  const raw = String(value || "").trim();
  const named = {
    tortoise: "#6B3A18",
    brown: "#6B3A18",
    black: "#111111",
    navy: "#1F2D57",
    gold: "#C9A14A",
    white: "#FFFFFF",
    silver: "#C9CDD4",
    clear: "#D8E4EA",
  };
  const lower = raw.toLowerCase();
  const css = named[lower] || (/^#[0-9a-fA-F]{6}$/.test(raw) ? raw.toUpperCase() : fallback);
  return {
    original: raw || fallback,
    css,
    rgba: [
      parseInt(css.slice(1, 3), 16),
      parseInt(css.slice(3, 5), 16),
      parseInt(css.slice(5, 7), 16),
      255,
    ],
    isTortoise: lower === "tortoise" || lower === "brown",
  };
}

function shadeRgba(rgba, shade) {
  return [
    clamp(Math.round(rgba[0] * shade), 0, 255),
    clamp(Math.round(rgba[1] * shade), 0, 255),
    clamp(Math.round(rgba[2] * shade), 0, 255),
    rgba[3] === undefined ? 255 : rgba[3],
  ];
}

function roundValue(value, digits = 4) {
  if (typeof value === "number") return Number(value.toFixed(digits));
  if (Array.isArray(value)) return value.map((item) => roundValue(item, digits));
  if (value && typeof value === "object") {
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = roundValue(item, digits);
    return out;
  }
  return value;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function fmt(n) {
  return Number.isFinite(n) ? n.toFixed(6).replace(/\.?0+$/, "") : "0";
}

function parseCrop(text, image, fallback) {
  const source = text || fallback;
  const parts = String(source)
    .split(",")
    .map((part) => safeInt(part.trim(), 0));
  if (parts.length !== 4) {
    throw new Error(`Invalid crop "${source}". Expected x,y,width,height.`);
  }
  const x = clamp(parts[0], 0, image.width - 1);
  const y = clamp(parts[1], 0, image.height - 1);
  return {
    x,
    y,
    width: clamp(parts[2], 1, image.width - x),
    height: clamp(parts[3], 1, image.height - y),
  };
}

function paethPredictor(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  return pb <= pc ? b : c;
}

function decodePng(filePath) {
  const buffer = fs.readFileSync(filePath);
  if (buffer.length < 8 || buffer.toString("ascii", 1, 4) !== "PNG") {
    throw new Error(`Not a PNG file: ${filePath}`);
  }

  let offset = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idatParts = [];

  while (offset < buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.toString("ascii", offset + 4, offset + 8);
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    const data = buffer.subarray(dataStart, dataEnd);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") {
      idatParts.push(data);
    } else if (type === "IEND") {
      break;
    }
    offset = dataEnd + 4;
  }

  if (bitDepth !== 8) throw new Error(`Unsupported PNG bit depth ${bitDepth}; expected 8-bit PNG.`);
  const channelsByColorType = { 0: 1, 2: 3, 4: 2, 6: 4 };
  const channels = channelsByColorType[colorType];
  if (!channels) throw new Error(`Unsupported PNG color type ${colorType}; use RGB/RGBA PNG.`);

  const raw = zlib.inflateSync(Buffer.concat(idatParts));
  const rgba = Buffer.alloc(width * height * 4);
  const stride = width * channels;
  let rawOffset = 0;
  let prev = Buffer.alloc(stride);

  for (let y = 0; y < height; y += 1) {
    const filter = raw[rawOffset];
    rawOffset += 1;
    const row = Buffer.from(raw.subarray(rawOffset, rawOffset + stride));
    rawOffset += stride;
    for (let x = 0; x < stride; x += 1) {
      const left = x >= channels ? row[x - channels] : 0;
      const up = prev[x] || 0;
      const upLeft = x >= channels ? prev[x - channels] || 0 : 0;
      if (filter === 1) row[x] = (row[x] + left) & 255;
      else if (filter === 2) row[x] = (row[x] + up) & 255;
      else if (filter === 3) row[x] = (row[x] + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) row[x] = (row[x] + paethPredictor(left, up, upLeft)) & 255;
      else if (filter !== 0) throw new Error(`Unsupported PNG filter ${filter}`);
    }
    for (let x = 0; x < width; x += 1) {
      const src = x * channels;
      const dst = (y * width + x) * 4;
      if (colorType === 0) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src];
        rgba[dst + 2] = row[src];
        rgba[dst + 3] = 255;
      } else if (colorType === 2) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src + 1];
        rgba[dst + 2] = row[src + 2];
        rgba[dst + 3] = 255;
      } else if (colorType === 4) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src];
        rgba[dst + 2] = row[src];
        rgba[dst + 3] = row[src + 1];
      } else {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src + 1];
        rgba[dst + 2] = row[src + 2];
        rgba[dst + 3] = row[src + 3];
      }
    }
    prev = row;
  }

  return { width, height, rgba };
}

function pixelAt(image, x, y) {
  const px = clamp(x, 0, image.width - 1);
  const py = clamp(y, 0, image.height - 1);
  const x0 = Math.floor(px);
  const y0 = Math.floor(py);
  const x1 = clamp(x0 + 1, 0, image.width - 1);
  const y1 = clamp(y0 + 1, 0, image.height - 1);
  const tx = px - x0;
  const ty = py - y0;

  const sample = (sx, sy, channel) => image.rgba[(sy * image.width + sx) * 4 + channel];
  const out = [];
  for (let channel = 0; channel < 4; channel += 1) {
    const top = sample(x0, y0, channel) * (1 - tx) + sample(x1, y0, channel) * tx;
    const bottom = sample(x0, y1, channel) * (1 - tx) + sample(x1, y1, channel) * tx;
    out[channel] = top * (1 - ty) + bottom * ty;
  }
  return out;
}

function colorStats(pixel) {
  const [r, g, b, a] = pixel;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  const sat = max === 0 ? 0 : (max - min) / max;
  return { r, g, b, a, lum, sat };
}

function estimateBackground(image, crop) {
  const points = [];
  const step = 16;
  for (let x = crop.x; x < crop.x + crop.width; x += step) {
    points.push([x, crop.y + 2], [x, crop.y + crop.height - 3]);
  }
  for (let y = crop.y; y < crop.y + crop.height; y += step) {
    points.push([crop.x + 2, y], [crop.x + crop.width - 3, y]);
  }
  const light = points
    .map(([x, y]) => pixelAt(image, x, y))
    .sort((a, b) => colorStats(b).lum - colorStats(a).lum)
    .slice(0, Math.max(4, Math.floor(points.length * 0.35)));
  const bg = [0, 0, 0, 0];
  for (const p of light) {
    for (let i = 0; i < 4; i += 1) bg[i] += p[i] / light.length;
  }
  return bg;
}

function isForegroundPixel(pixel, background, options) {
  const p = colorStats(pixel);
  const bg = colorStats(background);
  const dr = p.r - bg.r;
  const dg = p.g - bg.g;
  const db = p.b - bg.b;
  const d = Math.sqrt(dr * dr + dg * dg + db * db);
  const isWarmAcetate = p.r > p.b + 14 && p.g > p.b + 4 && p.sat > 0.07 && p.lum < 238;
  const isDark = p.lum < options.luminanceMax;
  return p.a > 18 && d >= options.threshold && (isDark || isWarmAcetate || p.sat >= options.saturationMin);
}

function buildMaskFromCrop(image, crop, options) {
  const width = Math.max(80, Math.round(options.gridWidth));
  const height = Math.max(24, Math.round((crop.height / crop.width) * width));
  const background = estimateBackground(image, crop);
  const mask = new Uint8Array(width * height);
  const samples = options.samples || 3;
  const minHits = options.minHits || Math.ceil((samples * samples) * 0.3);
  let hitsTotal = 0;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      let hits = 0;
      for (let sy = 0; sy < samples; sy += 1) {
        for (let sx = 0; sx < samples; sx += 1) {
          const px = crop.x + ((x + (sx + 0.5) / samples) / width) * crop.width;
          const py = crop.y + ((y + (sy + 0.5) / samples) / height) * crop.height;
          if (isForegroundPixel(pixelAt(image, px, py), background, options)) hits += 1;
        }
      }
      if (hits >= minHits) {
        mask[y * width + x] = 1;
        hitsTotal += 1;
      }
    }
  }

  return { mask, width, height, crop, background_rgba: roundValue(background, 2), foreground_pixels_raw: hitsTotal };
}

function countNeighbors(mask, width, height, x, y) {
  let count = 0;
  for (let dy = -1; dy <= 1; dy += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
      if (mask[ny * width + nx]) count += 1;
    }
  }
  return count;
}

function majoritySmooth(mask, width, height) {
  const out = new Uint8Array(mask.length);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const index = y * width + x;
      const count = countNeighbors(mask, width, height, x, y);
      if (mask[index]) out[index] = count >= 3 ? 1 : 0;
      else out[index] = count >= 6 ? 1 : 0;
    }
  }
  return out;
}

function bridgePixelGaps(mask, width, height) {
  const out = new Uint8Array(mask);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const index = y * width + x;
      const count = countNeighbors(mask, width, height, x, y);

      if (!mask[index]) {
        const horizontal = at(mask, width, height, x - 1, y) && at(mask, width, height, x + 1, y);
        const vertical = at(mask, width, height, x, y - 1) && at(mask, width, height, x, y + 1);
        const diagonalA = at(mask, width, height, x - 1, y - 1) && at(mask, width, height, x + 1, y + 1);
        const diagonalB = at(mask, width, height, x + 1, y - 1) && at(mask, width, height, x - 1, y + 1);
        if (horizontal || vertical || diagonalA || diagonalB || count >= 5) out[index] = 1;
      } else if (count <= 2) {
        out[index] = 0;
      }
    }
  }
  return out;
}

function erodeMask(mask, width, height, iterations = 1) {
  let current = mask;
  for (let iteration = 0; iteration < iterations; iteration += 1) {
    const out = new Uint8Array(current.length);
    for (let y = 1; y < height - 1; y += 1) {
      for (let x = 1; x < width - 1; x += 1) {
        const index = y * width + x;
        if (
          current[index] &&
          current[index - 1] &&
          current[index + 1] &&
          current[index - width] &&
          current[index + width] &&
          current[index - width - 1] &&
          current[index - width + 1] &&
          current[index + width - 1] &&
          current[index + width + 1]
        ) {
          out[index] = 1;
        }
      }
    }
    current = out;
  }
  return current;
}

function localMaskCoverage(mask, width, height, x, y) {
  let total = 0;
  let weight = 0;
  for (let dy = -1; dy <= 1; dy += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const nx = clamp(x + dx, 0, width - 1);
      const ny = clamp(y + dy, 0, height - 1);
      const w = dx === 0 && dy === 0 ? 4 : (dx === 0 || dy === 0 ? 2 : 1);
      total += (mask[ny * width + nx] ? 1 : 0) * w;
      weight += w;
    }
  }
  return total / weight;
}

function sampleMaskCoverage(mask, width, height, x, y) {
  const x0 = clamp(Math.floor(x), 0, width - 1);
  const y0 = clamp(Math.floor(y), 0, height - 1);
  const x1 = clamp(x0 + 1, 0, width - 1);
  const y1 = clamp(y0 + 1, 0, height - 1);
  const tx = clamp(x - x0, 0, 1);
  const ty = clamp(y - y0, 0, 1);

  const a = localMaskCoverage(mask, width, height, x0, y0);
  const b = localMaskCoverage(mask, width, height, x1, y0);
  const c = localMaskCoverage(mask, width, height, x0, y1);
  const d = localMaskCoverage(mask, width, height, x1, y1);
  return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
}

function upscaleMask(mask, width, height, scale, threshold = 0.48) {
  const outWidth = Math.max(width, Math.round(width * scale));
  const outHeight = Math.max(height, Math.round(height * scale));
  const out = new Uint8Array(outWidth * outHeight);

  for (let y = 0; y < outHeight; y += 1) {
    for (let x = 0; x < outWidth; x += 1) {
      const srcX = ((x + 0.5) / outWidth) * width - 0.5;
      const srcY = ((y + 0.5) / outHeight) * height - 0.5;
      if (sampleMaskCoverage(mask, width, height, srcX, srcY) >= threshold) {
        out[y * outWidth + x] = 1;
      }
    }
  }

  return { mask: out, width: outWidth, height: outHeight };
}

function componentFilter(mask, width, height, options) {
  const visited = new Uint8Array(mask.length);
  const components = [];
  const stack = [];

  for (let start = 0; start < mask.length; start += 1) {
    if (!mask[start] || visited[start]) continue;
    const component = [];
    stack.push(start);
    visited[start] = 1;
    while (stack.length) {
      const index = stack.pop();
      component.push(index);
      const x = index % width;
      const y = Math.floor(index / width);
      const neighbors = [
        [x - 1, y],
        [x + 1, y],
        [x, y - 1],
        [x, y + 1],
        [x - 1, y - 1],
        [x + 1, y - 1],
        [x - 1, y + 1],
        [x + 1, y + 1],
      ];
      for (const [nx, ny] of neighbors) {
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        const next = ny * width + nx;
        if (mask[next] && !visited[next]) {
          visited[next] = 1;
          stack.push(next);
        }
      }
    }
    components.push(component);
  }

  components.sort((a, b) => b.length - a.length);
  const out = new Uint8Array(mask.length);
  let kept = 0;
  const minPixels = options.minPixels || 20;
  for (let i = 0; i < components.length; i += 1) {
    const component = components[i];
    if (options.keepLargestOnly && i > 0) continue;
    if (component.length < minPixels) continue;
    kept += 1;
    for (const index of component) out[index] = 1;
  }
  return { mask: out, components_total: components.length, components_kept: kept, largest_component_pixels: components[0] ? components[0].length : 0 };
}

function maskBounds(mask, width, height) {
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  let count = 0;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      count += 1;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }
  if (!count) return null;
  return { minX, minY, maxX, maxY, width: maxX - minX + 1, height: maxY - minY + 1, pixels: count };
}

function trimMask(mask, width, height, padding = 2) {
  const bounds = maskBounds(mask, width, height);
  if (!bounds) throw new Error("No foreground pixels found after cleanup.");
  const minX = Math.max(0, bounds.minX - padding);
  const minY = Math.max(0, bounds.minY - padding);
  const maxX = Math.min(width - 1, bounds.maxX + padding);
  const maxY = Math.min(height - 1, bounds.maxY + padding);
  const outWidth = maxX - minX + 1;
  const outHeight = maxY - minY + 1;
  const out = new Uint8Array(outWidth * outHeight);
  for (let y = 0; y < outHeight; y += 1) {
    for (let x = 0; x < outWidth; x += 1) {
      out[y * outWidth + x] = mask[(minY + y) * width + (minX + x)];
    }
  }
  return { mask: out, width: outWidth, height: outHeight, bounds_px: { min_x: minX, min_y: minY, max_x: maxX, max_y: maxY } };
}

function finalizeTrace(rawTrace, options) {
  let mask = rawTrace.mask;
  for (let i = 0; i < (options.gapRepairIterations || 0); i += 1) {
    mask = bridgePixelGaps(mask, rawTrace.width, rawTrace.height);
  }
  for (let i = 0; i < (options.smoothIterations || 1); i += 1) {
    mask = majoritySmooth(mask, rawTrace.width, rawTrace.height);
  }
  const filtered = componentFilter(mask, rawTrace.width, rawTrace.height, {
    minPixels: options.minPixels,
    keepLargestOnly: options.keepLargestOnly,
  });
  const trimmed = trimMask(filtered.mask, rawTrace.width, rawTrace.height, options.padding || 2);
  const bounds = maskBounds(trimmed.mask, trimmed.width, trimmed.height);
  return {
    ...trimmed,
    crop: rawTrace.crop,
    source_grid_px: { width: rawTrace.width, height: rawTrace.height },
    background_rgba: rawTrace.background_rgba,
    foreground_pixels_raw: rawTrace.foreground_pixels_raw,
    foreground_pixels_final: bounds ? bounds.pixels : 0,
    components_total: filtered.components_total,
    components_kept: filtered.components_kept,
    largest_component_pixels: filtered.largest_component_pixels,
  };
}

function refineTraceResolution(trace, options = {}) {
  const scale = clamp(safeInt(options.scale, 1), 1, 3);
  if (scale <= 1) {
    return {
      ...trace,
      pixel_smoothing: { refine_scale: 1, applied: false },
    };
  }

  let refined = upscaleMask(trace.mask, trace.width, trace.height, scale, options.threshold || 0.48);
  for (let i = 0; i < (options.gapRepairIterations || 1); i += 1) {
    refined.mask = bridgePixelGaps(refined.mask, refined.width, refined.height);
  }
  for (let i = 0; i < (options.smoothIterations || 1); i += 1) {
    refined.mask = majoritySmooth(refined.mask, refined.width, refined.height);
  }
  const filtered = componentFilter(refined.mask, refined.width, refined.height, {
    minPixels: Math.max(1, Math.round((options.minPixels || 20) * scale * scale)),
    keepLargestOnly: options.keepLargestOnly,
  });
  const trimmed = trimMask(filtered.mask, refined.width, refined.height, Math.max(1, Math.round((options.padding || 2) * scale)));
  const bounds = maskBounds(trimmed.mask, trimmed.width, trimmed.height);

  return {
    ...trimmed,
    crop: trace.crop,
    source_grid_px: trace.source_grid_px || { width: trace.width, height: trace.height },
    source_bounds_px: trace.bounds_px,
    background_rgba: trace.background_rgba,
    foreground_pixels_raw: trace.foreground_pixels_raw,
    foreground_pixels_final: bounds ? bounds.pixels : 0,
    components_total: filtered.components_total,
    components_kept: filtered.components_kept,
    largest_component_pixels: filtered.largest_component_pixels,
    pixel_smoothing: {
      applied: true,
      refine_scale: scale,
      source_trace_grid_px: { width: trace.width, height: trace.height },
      refined_trace_grid_px: { width: trimmed.width, height: trimmed.height },
    },
  };
}

function traceSummary(trace) {
  return {
    crop_px: trace.crop,
    source_grid_px: trace.source_grid_px,
    trace_grid_px: { width: trace.width, height: trace.height },
    bounds_px: trace.bounds_px,
    pixel_smoothing: trace.pixel_smoothing,
    background_rgba: trace.background_rgba,
    foreground_pixels_raw: trace.foreground_pixels_raw,
    foreground_pixels_final: trace.foreground_pixels_final,
    components_total: trace.components_total,
    components_kept: trace.components_kept,
    largest_component_pixels: trace.largest_component_pixels,
  };
}

class Mesh {
  constructor(name) {
    this.name = name;
    this.triangles = [];
  }
  addTriangle(a, b, c, material = "acetate") {
    this.triangles.push({ a, b, c, material });
  }
  addQuad(a, b, c, d, material = "acetate") {
    this.addTriangle(a, b, c, material);
    this.addTriangle(a, c, d, material);
  }
  merge(other) {
    for (const triangle of other.triangles) {
      this.triangles.push(triangle);
    }
  }
  bounds() {
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (const tri of this.triangles) {
      for (const p of [tri.a, tri.b, tri.c]) {
        for (let i = 0; i < 3; i += 1) {
          min[i] = Math.min(min[i], p[i]);
          max[i] = Math.max(max[i], p[i]);
        }
      }
    }
    return { min, max, size: [max[0] - min[0], max[1] - min[1], max[2] - min[2]] };
  }
}

function normal(a, b, c) {
  const ux = b[0] - a[0];
  const uy = b[1] - a[1];
  const uz = b[2] - a[2];
  const vx = c[0] - a[0];
  const vy = c[1] - a[1];
  const vz = c[2] - a[2];
  const nx = uy * vz - uz * vy;
  const ny = uz * vx - ux * vz;
  const nz = ux * vy - uy * vx;
  const len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
  return [nx / len, ny / len, nz / len];
}

function writeAsciiStl(mesh, filePath) {
  const lines = [`solid ${mesh.name}`];
  for (const tri of mesh.triangles) {
    const n = normal(tri.a, tri.b, tri.c);
    lines.push(`  facet normal ${fmt(n[0])} ${fmt(n[1])} ${fmt(n[2])}`);
    lines.push("    outer loop");
    for (const p of [tri.a, tri.b, tri.c]) lines.push(`      vertex ${fmt(p[0])} ${fmt(p[1])} ${fmt(p[2])}`);
    lines.push("    endloop");
    lines.push("  endfacet");
  }
  lines.push(`endsolid ${mesh.name}`);
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeBinaryStl(mesh, filePath) {
  const header = Buffer.alloc(80, 0);
  header.write(`FRAMEANA ${mesh.name}`.slice(0, 79), 0, "ascii");
  const count = Buffer.alloc(4);
  count.writeUInt32LE(mesh.triangles.length, 0);
  const body = Buffer.alloc(mesh.triangles.length * 50);
  let offset = 0;
  for (const tri of mesh.triangles) {
    const n = normal(tri.a, tri.b, tri.c);
    for (const value of [...n, ...tri.a, ...tri.b, ...tri.c]) {
      body.writeFloatLE(Number.isFinite(value) ? value : 0, offset);
      offset += 4;
    }
    body.writeUInt16LE(0, offset);
    offset += 2;
  }
  fs.writeFileSync(filePath, Buffer.concat([header, count, body]));
}

function at(mask, width, height, x, y) {
  return x >= 0 && y >= 0 && x < width && y < height && mask[y * width + x];
}

function pointKey(x, y) {
  return `${x},${y}`;
}

function edgeLengthSq(a, b) {
  const dx = a[0] - b[0];
  const dy = a[1] - b[1];
  return dx * dx + dy * dy;
}

function addBoundaryEdge(edgeMap, from, to) {
  const edge = { from, to, used: false };
  const key = pointKey(from[0], from[1]);
  if (!edgeMap.has(key)) edgeMap.set(key, []);
  edgeMap.get(key).push(edge);
}

function chooseNextBoundaryEdge(candidates, previous, current) {
  if (candidates.length <= 1 || !previous) return candidates[0];
  const incoming = [current[0] - previous[0], current[1] - previous[1]];
  let best = candidates[0];
  let bestScore = -Infinity;
  for (const edge of candidates) {
    const outgoing = [edge.to[0] - current[0], edge.to[1] - current[1]];
    const score = incoming[0] * outgoing[0] + incoming[1] * outgoing[1];
    if (score > bestScore) {
      best = edge;
      bestScore = score;
    }
  }
  return best;
}

function extractBoundaryLoops(mask, width, height) {
  const edgeMap = new Map();

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      if (!at(mask, width, height, x, y - 1)) addBoundaryEdge(edgeMap, [x, y], [x + 1, y]);
      if (!at(mask, width, height, x + 1, y)) addBoundaryEdge(edgeMap, [x + 1, y], [x + 1, y + 1]);
      if (!at(mask, width, height, x, y + 1)) addBoundaryEdge(edgeMap, [x + 1, y + 1], [x, y + 1]);
      if (!at(mask, width, height, x - 1, y)) addBoundaryEdge(edgeMap, [x, y + 1], [x, y]);
    }
  }

  const loops = [];
  for (const edges of edgeMap.values()) {
    for (const firstEdge of edges) {
      if (firstEdge.used) continue;
      const start = firstEdge.from;
      const loop = [start];
      let edge = firstEdge;
      let previous = null;
      let current = firstEdge.from;
      let guard = 0;

      while (edge && !edge.used && guard < mask.length * 6) {
        edge.used = true;
        previous = current;
        current = edge.to;
        guard += 1;

        if (current[0] === start[0] && current[1] === start[1]) break;
        loop.push(current);

        const nextEdges = (edgeMap.get(pointKey(current[0], current[1])) || []).filter((item) => !item.used);
        edge = chooseNextBoundaryEdge(nextEdges, previous, current);
      }

      if (current[0] === start[0] && current[1] === start[1] && loop.length >= 4) {
        loops.push(loop);
      }
    }
  }

  return loops;
}

function simplifyClosedLoop(points, minDistanceSq) {
  if (points.length <= 8) return points;
  const simplified = [];
  for (const point of points) {
    const previous = simplified[simplified.length - 1];
    if (!previous || edgeLengthSq(previous, point) >= minDistanceSq) simplified.push(point);
  }
  if (simplified.length > 1 && edgeLengthSq(simplified[0], simplified[simplified.length - 1]) < minDistanceSq) {
    simplified.pop();
  }
  return simplified.length >= 4 ? simplified : points;
}

function chaikinClosedLoop(points, iterations) {
  let out = points;
  for (let iteration = 0; iteration < iterations; iteration += 1) {
    if (out.length < 4) break;
    const next = [];
    for (let i = 0; i < out.length; i += 1) {
      const a = out[i];
      const b = out[(i + 1) % out.length];
      next.push([
        a[0] * 0.78 + b[0] * 0.22,
        a[1] * 0.78 + b[1] * 0.22,
      ]);
      next.push([
        a[0] * 0.22 + b[0] * 0.78,
        a[1] * 0.22 + b[1] * 0.78,
      ]);
    }
    out = next;
  }
  return out;
}

function gridPointToFrontMm(point, width, height, cell) {
  return [
    (point[0] - width / 2) * cell,
    (height / 2 - point[1]) * cell,
  ];
}

function addContourFaceCoverStripXY(mesh, points, width, height, cell, z, coverWidthMm, material, frontFace) {
  const halfWidth = coverWidthMm / 2;
  let stripCount = 0;

  for (let i = 0; i < points.length; i += 1) {
    const p0 = gridPointToFrontMm(points[i], width, height, cell);
    const p1 = gridPointToFrontMm(points[(i + 1) % points.length], width, height, cell);
    const dx = p1[0] - p0[0];
    const dy = p1[1] - p0[1];
    const length = Math.sqrt(dx * dx + dy * dy);
    if (length < 0.001) continue;

    const nx = -dy / length;
    const ny = dx / length;
    const a = [p0[0] + nx * halfWidth, p0[1] + ny * halfWidth, z];
    const b = [p1[0] + nx * halfWidth, p1[1] + ny * halfWidth, z];
    const c = [p1[0] - nx * halfWidth, p1[1] - ny * halfWidth, z];
    const d = [p0[0] - nx * halfWidth, p0[1] - ny * halfWidth, z];

    if (frontFace) {
      mesh.addQuad(d, c, b, a, material);
    } else {
      mesh.addQuad(a, b, c, d, material);
    }
    stripCount += 1;
  }

  return stripCount;
}

function addSmoothContourSideWallsXY(mesh, trace, targetWidthMm, depthMm, material, options = {}) {
  const { mask, width, height } = trace;
  const cell = targetWidthMm / width;
  const zFront = depthMm / 2;
  const zBack = -depthMm / 2;
  const loops = extractBoundaryLoops(mask, width, height);
  const minArea = options.minAreaPx || 18;
  const minSegmentGrid = options.minSegmentGrid || 1.15;
  const smoothIterations = options.smoothIterations || 2;
  const coverStrips = options.coverStrips !== false;
  const requestedCoverWidthMm = safeFloat(options.coverWidthMm, NaN);
  const coverWidthMm = Number.isFinite(requestedCoverWidthMm) && requestedCoverWidthMm > 0
    ? requestedCoverWidthMm
    : Math.max(cell * 2.35, 0.75);
  const coverZOffsetMm = safeFloat(options.coverZOffsetMm, 0.035);
  let usedLoops = 0;
  let segmentCount = 0;
  let faceCoverStrips = 0;

  for (const loop of loops) {
    if (Math.abs(polygonArea(loop)) < minArea) continue;
    let points = simplifyClosedLoop(loop, minSegmentGrid * minSegmentGrid);
    points = chaikinClosedLoop(points, smoothIterations);
    points = simplifyClosedLoop(points, Math.max(0.5, minSegmentGrid * 0.55) ** 2);
    if (points.length < 4) continue;

    usedLoops += 1;
    for (let i = 0; i < points.length; i += 1) {
      const p0 = gridPointToFrontMm(points[i], width, height, cell);
      const p1 = gridPointToFrontMm(points[(i + 1) % points.length], width, height, cell);
      if ((p0[0] - p1[0]) ** 2 + (p0[1] - p1[1]) ** 2 < 0.0001) continue;
      mesh.addQuad([p0[0], p0[1], zBack], [p1[0], p1[1], zBack], [p1[0], p1[1], zFront], [p0[0], p0[1], zFront], material);
      segmentCount += 1;
    }

    if (coverStrips) {
      faceCoverStrips += addContourFaceCoverStripXY(
        mesh,
        points,
        width,
        height,
        cell,
        zFront + coverZOffsetMm,
        coverWidthMm,
        material,
        true,
      );
      faceCoverStrips += addContourFaceCoverStripXY(
        mesh,
        points,
        width,
        height,
        cell,
        zBack - coverZOffsetMm,
        coverWidthMm,
        material,
        false,
      );
    }
  }

  return {
    sidewall_method: "smoothed_contour",
    contour_loops: usedLoops,
    contour_segments: segmentCount,
    contour_smooth_iterations: smoothIterations,
    contour_face_cover_strips: faceCoverStrips,
    contour_cover_width_mm: coverStrips ? coverWidthMm : 0,
  };
}

function addRasterExtrusionXY(mesh, trace, targetWidthMm, depthMm, material, options = {}) {
  const { mask, width, height } = trace;
  const cell = targetWidthMm / width;
  const zFront = depthMm / 2;
  const zBack = -depthMm / 2;
  let sidewallProfile = { sidewall_method: "raster_edges" };
  const capInsetPx = options.smoothSideWalls
    ? safeInt(options.capInsetPx, Math.max(2, Math.round(0.38 / cell)))
    : 0;
  const capMask = capInsetPx > 0 ? erodeMask(mask, width, height, capInsetPx) : mask;

  for (let y = 0; y < height; y += 1) {
    let start = -1;
    for (let x = 0; x <= width; x += 1) {
      const on = x < width && capMask[y * width + x];
      if (on && start < 0) {
        start = x;
      } else if (!on && start >= 0) {
        const x0 = (start - width / 2) * cell;
        const x1 = (x - width / 2) * cell;
        const yTop = (height / 2 - y) * cell;
        const yBottom = yTop - cell;
        mesh.addQuad([x0, yBottom, zFront], [x1, yBottom, zFront], [x1, yTop, zFront], [x0, yTop, zFront], material);
        mesh.addQuad([x0, yBottom, zBack], [x0, yTop, zBack], [x1, yTop, zBack], [x1, yBottom, zBack], material);
        start = -1;
      }
    }
  }

  if (options.smoothSideWalls) {
    sidewallProfile = addSmoothContourSideWallsXY(mesh, trace, targetWidthMm, depthMm, material, options);
  } else {
    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        if (!mask[y * width + x]) continue;
        const x0 = (x - width / 2) * cell;
        const x1 = x0 + cell;
        const yTop = (height / 2 - y) * cell;
        const yBottom = yTop - cell;
        if (!at(mask, width, height, x - 1, y)) {
          mesh.addQuad([x0, yBottom, zBack], [x0, yBottom, zFront], [x0, yTop, zFront], [x0, yTop, zBack], material);
        }
        if (!at(mask, width, height, x + 1, y)) {
          mesh.addQuad([x1, yBottom, zBack], [x1, yTop, zBack], [x1, yTop, zFront], [x1, yBottom, zFront], material);
        }
        if (!at(mask, width, height, x, y - 1)) {
          mesh.addQuad([x0, yTop, zBack], [x0, yTop, zFront], [x1, yTop, zFront], [x1, yTop, zBack], material);
        }
        if (!at(mask, width, height, x, y + 1)) {
          mesh.addQuad([x0, yBottom, zBack], [x1, yBottom, zBack], [x1, yBottom, zFront], [x0, yBottom, zFront], material);
        }
      }
    }
  }

  return {
    cell_mm: cell,
    target_width_mm: targetWidthMm,
    target_height_mm: height * cell,
    depth_mm: depthMm,
    cap_inset_px: capInsetPx,
    cap_inset_mm: capInsetPx * cell,
    ...sidewallProfile,
  };
}

function addRasterExtrusionYZ(mesh, trace, options) {
  const { mask, width, height } = trace;
  const cell = options.targetLengthMm / width;
  const xCenter = options.xCenter;
  const side = options.side;
  const thickness = options.thicknessMm;
  const xOuter = xCenter + side * thickness / 2;
  const xInner = xCenter - side * thickness / 2;
  const zStart = options.zStart;
  const yOffset = options.yOffset || 0;
  const material = options.material || "acetate";

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      const z0 = zStart - x * cell;
      const z1 = z0 - cell;
      const yTop = yOffset + (height / 2 - y) * cell;
      const yBottom = yTop - cell;

      mesh.addQuad([xOuter, yBottom, z1], [xOuter, yBottom, z0], [xOuter, yTop, z0], [xOuter, yTop, z1], material);
      mesh.addQuad([xInner, yBottom, z1], [xInner, yTop, z1], [xInner, yTop, z0], [xInner, yBottom, z0], material);

      if (!at(mask, width, height, x - 1, y)) {
        mesh.addQuad([xInner, yBottom, z0], [xInner, yTop, z0], [xOuter, yTop, z0], [xOuter, yBottom, z0], material);
      }
      if (!at(mask, width, height, x + 1, y)) {
        mesh.addQuad([xInner, yBottom, z1], [xOuter, yBottom, z1], [xOuter, yTop, z1], [xInner, yTop, z1], material);
      }
      if (!at(mask, width, height, x, y - 1)) {
        mesh.addQuad([xInner, yTop, z1], [xOuter, yTop, z1], [xOuter, yTop, z0], [xInner, yTop, z0], material);
      }
      if (!at(mask, width, height, x, y + 1)) {
        mesh.addQuad([xInner, yBottom, z1], [xInner, yBottom, z0], [xOuter, yBottom, z0], [xOuter, yBottom, z1], material);
      }
    }
  }

  return {
    cell_mm: cell,
    target_length_mm: options.targetLengthMm,
    target_height_mm: height * cell,
    thickness_mm: thickness,
    x_center_mm: xCenter,
    y_offset_mm: yOffset,
    z_start_mm: zStart,
    side,
  };
}

function addCylinderZ(mesh, cx, cy, cz, radius, depth, segments, material) {
  const z0 = cz - depth / 2;
  const z1 = cz + depth / 2;
  const top = [cx, cy, z1];
  const bottom = [cx, cy, z0];
  for (let i = 0; i < segments; i += 1) {
    const t0 = Math.PI * 2 * i / segments;
    const t1 = Math.PI * 2 * (i + 1) / segments;
    const p0b = [cx + Math.cos(t0) * radius, cy + Math.sin(t0) * radius, z0];
    const p1b = [cx + Math.cos(t1) * radius, cy + Math.sin(t1) * radius, z0];
    const p0t = [p0b[0], p0b[1], z1];
    const p1t = [p1b[0], p1b[1], z1];
    mesh.addTriangle(top, p0t, p1t, material);
    mesh.addTriangle(bottom, p1b, p0b, material);
    mesh.addQuad(p0b, p1b, p1t, p0t, material);
  }
}

function addBox(mesh, cx, cy, cz, sx, sy, sz, material = "acetate") {
  const x0 = cx - sx / 2;
  const x1 = cx + sx / 2;
  const y0 = cy - sy / 2;
  const y1 = cy + sy / 2;
  const z0 = cz - sz / 2;
  const z1 = cz + sz / 2;
  const p000 = [x0, y0, z0];
  const p100 = [x1, y0, z0];
  const p110 = [x1, y1, z0];
  const p010 = [x0, y1, z0];
  const p001 = [x0, y0, z1];
  const p101 = [x1, y0, z1];
  const p111 = [x1, y1, z1];
  const p011 = [x0, y1, z1];
  mesh.addQuad(p001, p101, p111, p011, material);
  mesh.addQuad(p000, p010, p110, p100, material);
  mesh.addQuad(p000, p001, p011, p010, material);
  mesh.addQuad(p100, p110, p111, p101, material);
  mesh.addQuad(p010, p011, p111, p110, material);
  mesh.addQuad(p000, p100, p101, p001, material);
}

function polygonArea(points) {
  let area = 0;
  for (let i = 0; i < points.length; i += 1) {
    const j = (i + 1) % points.length;
    area += points[i][0] * points[j][1] - points[j][0] * points[i][1];
  }
  return area / 2;
}

function addExtrudedPolygonXY(mesh, points, depth, zCenter, material = "acetate") {
  const pts = polygonArea(points) >= 0 ? points : points.slice().reverse();
  const zFront = zCenter + depth / 2;
  const zBack = zCenter - depth / 2;
  const center = pts.reduce((acc, p) => [acc[0] + p[0] / pts.length, acc[1] + p[1] / pts.length], [0, 0]);
  const cf = [center[0], center[1], zFront];
  const cb = [center[0], center[1], zBack];
  for (let i = 0; i < pts.length; i += 1) {
    const j = (i + 1) % pts.length;
    const p0f = [pts[i][0], pts[i][1], zFront];
    const p1f = [pts[j][0], pts[j][1], zFront];
    const p0b = [pts[i][0], pts[i][1], zBack];
    const p1b = [pts[j][0], pts[j][1], zBack];
    mesh.addTriangle(cf, p0f, p1f, material);
    mesh.addTriangle(cb, p1b, p0b, material);
    mesh.addQuad(p0b, p1b, p1f, p0f, material);
  }
}

function addFrontRivets(mesh, frontBounds, depthMm) {
  const radius = 1.15;
  const y = frontBounds.min[1] + frontBounds.size[1] * 0.67;
  const z = depthMm / 2 + 0.24;
  const leftBase = frontBounds.min[0] + frontBounds.size[0] * 0.058;
  const rightBase = frontBounds.max[0] - frontBounds.size[0] * 0.058;
  for (const x of [leftBase, leftBase + 3.0, rightBase - 3.0, rightBase]) {
    addCylinderZ(mesh, x, y, z, radius, 0.48, 30, "hardware");
  }
}

function addNoseBridgeCompletion(mesh, frontDepthMm) {
  const depth = frontDepthMm * 0.72;
  const zCenter = 0.16;
  const bridge = [
    [-9.6, 2.25],
    [-7.4, 4.65],
    [-2.8, 5.05],
    [2.8, 5.05],
    [7.4, 4.65],
    [9.6, 2.25],
    [8.25, 1.35],
    [3.9, 2.05],
    [0, 2.15],
    [-3.9, 2.05],
    [-8.25, 1.35],
  ];
  addExtrudedPolygonXY(mesh, bridge, depth, zCenter, "acetate");

  const sideTab = [
    [-12.35, -0.45],
    [-10.95, 0.1],
    [-10.95, 5.55],
    [-12.35, 4.85],
  ];
  addExtrudedPolygonXY(mesh, sideTab, depth * 0.96, zCenter, "acetate");
  addExtrudedPolygonXY(
    mesh,
    sideTab.map(([x, y]) => [-x, y]),
    depth * 0.96,
    zCenter,
    "acetate",
  );

  return {
    method: "front_bridge_completion_from_2d_reference",
    depth_mm: depth,
    z_center_mm: zCenter,
    bridge_width_mm: 19.2,
    bridge_height_mm: 5.5,
  };
}

function addArmHingeConnector(mesh, side, frontBounds, frontDepthMm, armThicknessMm) {
  const xOuter = side > 0 ? frontBounds.max[0] - 1.0 : frontBounds.min[0] + 1.0;
  const yCenter = frontBounds.min[1] + frontBounds.size[1] * 0.61;
  const zCenter = -frontDepthMm / 2 - 1.45;
  const hinge = {
    x_center_mm: xOuter,
    y_center_mm: yCenter,
    z_center_mm: zCenter,
    size_mm: {
      x: armThicknessMm + 1.5,
      y: 10.2,
      z: frontDepthMm + 0.9,
    },
  };

  addBox(mesh, xOuter, yCenter, zCenter, hinge.size_mm.x, hinge.size_mm.y, hinge.size_mm.z, "acetate");
  return hinge;
}

function addStrokeOnXSurface(mesh, xSurface, side, p0, p1, width, relief, material) {
  const dz = p1[0] - p0[0];
  const dy = p1[1] - p0[1];
  const len = Math.sqrt(dz * dz + dy * dy) || 1;
  const nz = (-dy / len) * width / 2;
  const ny = (dz / len) * width / 2;
  const yz = [
    [p0[0] + nz, p0[1] + ny],
    [p1[0] + nz, p1[1] + ny],
    [p1[0] - nz, p1[1] - ny],
    [p0[0] - nz, p0[1] - ny],
  ];
  const x0 = xSurface;
  const x1 = xSurface + side * relief;
  const a0 = [x0, yz[0][1], yz[0][0]];
  const b0 = [x0, yz[1][1], yz[1][0]];
  const c0 = [x0, yz[2][1], yz[2][0]];
  const d0 = [x0, yz[3][1], yz[3][0]];
  const a1 = [x1, yz[0][1], yz[0][0]];
  const b1 = [x1, yz[1][1], yz[1][0]];
  const c1 = [x1, yz[2][1], yz[2][0]];
  const d1 = [x1, yz[3][1], yz[3][0]];
  mesh.addQuad(a1, b1, c1, d1, material);
  mesh.addQuad(a0, d0, c0, b0, material);
  mesh.addQuad(a0, a1, d1, d0, material);
  mesh.addQuad(b0, c0, c1, b1, material);
  mesh.addQuad(a0, b0, b1, a1, material);
  mesh.addQuad(d0, d1, c1, c0, material);
}

function addStrokeOnYSurface(mesh, ySurface, p0, p1, width, relief, material) {
  const dz = p1[0] - p0[0];
  const dx = p1[1] - p0[1];
  const len = Math.sqrt(dz * dz + dx * dx) || 1;
  const nz = (-dx / len) * width / 2;
  const nx = (dz / len) * width / 2;
  const zx = [
    [p0[0] + nz, p0[1] + nx],
    [p1[0] + nz, p1[1] + nx],
    [p1[0] - nz, p1[1] - nx],
    [p0[0] - nz, p0[1] - nx],
  ];
  const y0 = ySurface - 0.08;
  const y1 = ySurface + relief;
  const a0 = [zx[0][1], y0, zx[0][0]];
  const b0 = [zx[1][1], y0, zx[1][0]];
  const c0 = [zx[2][1], y0, zx[2][0]];
  const d0 = [zx[3][1], y0, zx[3][0]];
  const a1 = [zx[0][1], y1, zx[0][0]];
  const b1 = [zx[1][1], y1, zx[1][0]];
  const c1 = [zx[2][1], y1, zx[2][0]];
  const d1 = [zx[3][1], y1, zx[3][0]];
  mesh.addQuad(a1, b1, c1, d1, material);
  mesh.addQuad(a0, d0, c0, b0, material);
  mesh.addQuad(a0, a1, d1, d0, material);
  mesh.addQuad(b0, c0, c1, b1, material);
  mesh.addQuad(a0, b0, b1, a1, material);
  mesh.addQuad(d0, d1, c1, c0, material);
}

const STROKE_FONT = {
  a: { advance: 0.82, strokes: [[0.12, 0.1, 0.12, 0.58], [0.12, 0.58, 0.66, 0.58], [0.66, 0.58, 0.66, 0.1], [0.12, 0.34, 0.66, 0.34], [0.12, 0.1, 0.66, 0.1]] },
  b: { advance: 0.82, strokes: [[0.12, 0, 0.12, 1], [0.12, 0.55, 0.66, 0.55], [0.66, 0.55, 0.66, 0.1], [0.12, 0.1, 0.66, 0.1]] },
  c: { advance: 0.78, strokes: [[0.66, 0.58, 0.12, 0.58], [0.12, 0.58, 0.12, 0.1], [0.12, 0.1, 0.66, 0.1]] },
  d: { advance: 0.82, strokes: [[0.66, 0, 0.66, 1], [0.12, 0.58, 0.66, 0.58], [0.12, 0.58, 0.12, 0.1], [0.12, 0.1, 0.66, 0.1]] },
  e: { advance: 0.82, strokes: [[0.12, 0.34, 0.68, 0.34], [0.68, 0.58, 0.12, 0.58], [0.12, 0.58, 0.12, 0.1], [0.12, 0.1, 0.68, 0.1]] },
  f: { advance: 0.64, strokes: [[0.42, 0, 0.42, 0.96], [0.42, 0.96, 0.72, 0.96], [0.18, 0.58, 0.66, 0.58]] },
  g: { advance: 0.86, strokes: [[0.68, 0.58, 0.14, 0.58], [0.14, 0.58, 0.14, 0.1], [0.14, 0.1, 0.68, 0.1], [0.68, 0.1, 0.68, -0.22], [0.68, -0.22, 0.22, -0.22]] },
  h: { advance: 0.82, strokes: [[0.12, 0, 0.12, 1], [0.12, 0.56, 0.66, 0.56], [0.66, 0.56, 0.66, 0.1]] },
  i: { advance: 0.38, strokes: [[0.2, 0.1, 0.2, 0.58], [0.2, 0.82, 0.2, 0.86]] },
  j: { advance: 0.44, strokes: [[0.26, 0.58, 0.26, -0.18], [0.26, -0.18, 0.08, -0.18], [0.26, 0.82, 0.26, 0.86]] },
  k: { advance: 0.78, strokes: [[0.12, 0, 0.12, 1], [0.12, 0.34, 0.66, 0.58], [0.12, 0.34, 0.68, 0.1]] },
  l: { advance: 0.38, strokes: [[0.2, 0, 0.2, 1]] },
  m: { advance: 1.04, strokes: [[0.12, 0.1, 0.12, 0.58], [0.12, 0.58, 0.44, 0.1], [0.44, 0.1, 0.76, 0.58], [0.76, 0.58, 0.76, 0.1]] },
  n: { advance: 0.82, strokes: [[0.12, 0.1, 0.12, 0.58], [0.12, 0.58, 0.66, 0.1], [0.66, 0.1, 0.66, 0.58]] },
  o: { advance: 0.82, strokes: [[0.12, 0.1, 0.12, 0.58], [0.12, 0.58, 0.66, 0.58], [0.66, 0.58, 0.66, 0.1], [0.66, 0.1, 0.12, 0.1]] },
  p: { advance: 0.82, strokes: [[0.12, -0.22, 0.12, 0.58], [0.12, 0.58, 0.66, 0.58], [0.66, 0.58, 0.66, 0.18], [0.66, 0.18, 0.12, 0.18]] },
  q: { advance: 0.86, strokes: [[0.66, -0.22, 0.66, 0.58], [0.12, 0.58, 0.66, 0.58], [0.12, 0.58, 0.12, 0.18], [0.12, 0.18, 0.66, 0.18]] },
  r: { advance: 0.62, strokes: [[0.12, 0.1, 0.12, 0.58], [0.12, 0.58, 0.58, 0.58]] },
  s: { advance: 0.76, strokes: [[0.64, 0.58, 0.12, 0.58], [0.12, 0.58, 0.12, 0.34], [0.12, 0.34, 0.64, 0.34], [0.64, 0.34, 0.64, 0.1], [0.64, 0.1, 0.12, 0.1]] },
  t: { advance: 0.62, strokes: [[0.34, 0, 0.34, 0.86], [0.12, 0.58, 0.58, 0.58]] },
  u: { advance: 0.82, strokes: [[0.12, 0.58, 0.12, 0.1], [0.12, 0.1, 0.66, 0.1], [0.66, 0.1, 0.66, 0.58]] },
  v: { advance: 0.78, strokes: [[0.1, 0.58, 0.38, 0.1], [0.38, 0.1, 0.68, 0.58]] },
  w: { advance: 1.04, strokes: [[0.08, 0.58, 0.28, 0.1], [0.28, 0.1, 0.52, 0.58], [0.52, 0.58, 0.76, 0.1], [0.76, 0.1, 0.96, 0.58]] },
  x: { advance: 0.76, strokes: [[0.12, 0.58, 0.66, 0.1], [0.66, 0.58, 0.12, 0.1]] },
  y: { advance: 0.78, strokes: [[0.1, 0.58, 0.38, 0.18], [0.66, 0.58, 0.38, 0.18], [0.38, 0.18, 0.18, -0.22]] },
  z: { advance: 0.78, strokes: [[0.12, 0.58, 0.66, 0.58], [0.66, 0.58, 0.12, 0.1], [0.12, 0.1, 0.66, 0.1]] },
};

const UPPERCASE_STROKES = {
  a: [[0.1, 0, 0.4, 1], [0.4, 1, 0.7, 0], [0.22, 0.45, 0.58, 0.45]],
  e: [[0.68, 1, 0.12, 1], [0.12, 1, 0.12, 0], [0.12, 0.5, 0.58, 0.5], [0.12, 0, 0.68, 0]],
  g: [[0.68, 0.88, 0.5, 1], [0.5, 1, 0.14, 0.82], [0.14, 0.82, 0.14, 0.14], [0.14, 0.14, 0.66, 0.14], [0.66, 0.14, 0.66, 0.46], [0.66, 0.46, 0.42, 0.46]],
  h: [[0.12, 0, 0.12, 1], [0.68, 0, 0.68, 1], [0.12, 0.5, 0.68, 0.5]],
  n: [[0.12, 0, 0.12, 1], [0.12, 1, 0.68, 0], [0.68, 0, 0.68, 1]],
};

function engravingGlyph(char) {
  if (char === " ") return { advance: 0.46, strokes: [] };
  if (char === "-" || char === "_") return { advance: 0.62, strokes: [[0.12, 0.36, 0.52, 0.36]] };
  if (char === ".") return { advance: 0.28, strokes: [[0.14, 0.08, 0.14, 0.12]] };
  const lower = char.toLowerCase();
  const base = STROKE_FONT[lower] || STROKE_FONT.x;
  if (char !== lower && UPPERCASE_STROKES[lower]) {
    return { ...base, strokes: UPPERCASE_STROKES[lower] };
  }
  return base;
}

function normalizeEngravingText(text) {
  return String(text || "Nael").replace(/\s+/g, " ").trim();
}

function measureEngravingText(text, spacing) {
  let width = 0;
  for (const char of text) width += engravingGlyph(char).advance + spacing;
  return Math.max(0, width - spacing);
}

function addTextEmbossOnXSurface(mesh, options) {
  const text = normalizeEngravingText(options.text);
  if (!text || text.toLowerCase() === "none") return null;
  const side = options.side;
  const xSurface = options.xSurface;
  const startZ = options.startZ;
  const baseY = options.baseY;
  const requestedHeight = options.heightMm || 4.4;
  const spacing = 0.18;
  const normalizedWidth = measureEngravingText(text, spacing);
  const maxLengthMm = options.maxLengthMm || 62;
  const heightMm = Math.max(1.85, Math.min(requestedHeight, maxLengthMm / Math.max(normalizedWidth * 0.62, 1)));
  const widthMm = heightMm * 0.62;
  const strokeWidth = Math.max(0.18, Math.min(0.36, heightMm * 0.085));
  const relief = options.reliefMm || 0.5;
  const material = options.material || "engraving";
  let cursor = 0;
  let strokeCount = 0;

  for (const char of text) {
    const glyph = engravingGlyph(char);
    for (const st of glyph.strokes) {
      const p0 = [startZ - (cursor + st[0]) * widthMm, baseY + st[1] * heightMm];
      const p1 = [startZ - (cursor + st[2]) * widthMm, baseY + st[3] * heightMm];
      addStrokeOnXSurface(mesh, xSurface, side, p0, p1, strokeWidth, relief, material);
      strokeCount += 1;
    }
    cursor += glyph.advance + spacing;
  }

  return {
    text,
    surface: "outside_right_arm",
    start_z_mm: startZ,
    base_y_mm: baseY,
    height_mm: heightMm,
    max_length_mm: maxLengthMm,
    rendered_length_mm: normalizedWidth * widthMm,
    relief_mm: relief,
    stroke_count: strokeCount,
  };
}

function addNaelEmboss(mesh, options) {
  return addTextEmbossOnXSurface(mesh, options);
}

function addNaelTopEmboss(mesh, options) {
  const text = normalizeEngravingText(options.text);
  if (!text || text.toLowerCase() === "none") return null;
  const side = options.side;
  const topY = options.topY;
  const startZ = options.startZ;
  const baseX = options.baseX;
  const spacing = 0.18;
  const normalizedWidth = measureEngravingText(text, spacing);
  const h = Math.max(1.85, Math.min(options.heightMm || 4.4, (options.maxLengthMm || 62) / Math.max(normalizedWidth * 0.62, 1)));
  const w = h * 0.62;
  const strokeWidth = Math.max(0.18, Math.min(0.4, h * 0.1));
  const relief = options.reliefMm || 0.8;
  const material = options.material || "engraving";
  let cursor = 0;
  let strokeCount = 0;
  for (const char of text) {
    const glyph = engravingGlyph(char);
    for (const st of glyph.strokes) {
      const p0 = [startZ - (cursor + st[0]) * w, baseX + side * st[1] * h];
      const p1 = [startZ - (cursor + st[2]) * w, baseX + side * st[3] * h];
      addStrokeOnYSurface(mesh, topY, p0, p1, strokeWidth, relief, material);
      strokeCount += 1;
    }
    cursor += glyph.advance + spacing;
  }
  return {
    text,
    surface: "top_of_right_arm",
    start_z_mm: startZ,
    base_x_mm: baseX,
    top_y_mm: topY,
    height_mm: h,
    relief_mm: relief,
    stroke_count: strokeCount,
  };
}

function cloneMesh(mesh, name) {
  const out = new Mesh(name || mesh.name);
  for (const tri of mesh.triangles) {
    out.addTriangle([...tri.a], [...tri.b], [...tri.c], tri.material);
  }
  return out;
}

function mirrorMeshX(mesh, name) {
  const out = new Mesh(name);
  for (const tri of mesh.triangles) {
    out.addTriangle([-tri.a[0], tri.a[1], tri.a[2]], [-tri.c[0], tri.c[1], tri.c[2]], [-tri.b[0], tri.b[1], tri.b[2]], tri.material);
  }
  return out;
}

function writeTraceSvg(filePath, trace, color) {
  const rects = [];
  for (let y = 0; y < trace.height; y += 1) {
    let start = -1;
    for (let x = 0; x <= trace.width; x += 1) {
      const on = x < trace.width && trace.mask[y * trace.width + x];
      if (on && start < 0) start = x;
      else if (!on && start >= 0) {
        rects.push(`<rect x="${start}" y="${y}" width="${x - start}" height="1"/>`);
        start = -1;
      }
    }
  }
  const svg = [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${trace.width} ${trace.height}" width="${trace.width * 2}" height="${trace.height * 2}">`,
    `<rect width="100%" height="100%" fill="#f7f7f5"/>`,
    `<g fill="${color}">`,
    rects.join("\n"),
    `</g>`,
    `</svg>`,
  ].join("\n");
  fs.writeFileSync(filePath, `${svg}\n`, "utf8");
}

function makeCrcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
}

const CRC_TABLE = makeCrcTable();

function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBuffer = Buffer.from(type, "ascii");
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), 0);
  return Buffer.concat([length, typeBuffer, data, crc]);
}

function writePng(filePath, width, height, rgba) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) {
    const rowStart = y * (width * 4 + 1);
    raw[rowStart] = 0;
    rgba.copy(raw, rowStart + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const signature = Buffer.from("89504e470d0a1a0a", "hex");
  fs.writeFileSync(filePath, Buffer.concat([signature, pngChunk("IHDR", ihdr), pngChunk("IDAT", zlib.deflateSync(raw)), pngChunk("IEND", Buffer.alloc(0))]));
}

function setPixel(buffer, width, height, x, y, color) {
  const px = Math.round(x);
  const py = Math.round(y);
  if (px < 0 || py < 0 || px >= width || py >= height) return;
  const i = (py * width + px) * 4;
  buffer[i] = color[0];
  buffer[i + 1] = color[1];
  buffer[i + 2] = color[2];
  buffer[i + 3] = color[3] === undefined ? 255 : color[3];
}

function fillTriangle(buffer, width, height, p0, p1, p2, color) {
  const minX = clamp(Math.floor(Math.min(p0[0], p1[0], p2[0])), 0, width - 1);
  const maxX = clamp(Math.ceil(Math.max(p0[0], p1[0], p2[0])), 0, width - 1);
  const minY = clamp(Math.floor(Math.min(p0[1], p1[1], p2[1])), 0, height - 1);
  const maxY = clamp(Math.ceil(Math.max(p0[1], p1[1], p2[1])), 0, height - 1);
  const area = (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1]);
  if (Math.abs(area) < 0.001) return;
  for (let y = minY; y <= maxY; y += 1) {
    for (let x = minX; x <= maxX; x += 1) {
      const sampleX = x + 0.5;
      const sampleY = y + 0.5;
      const w0 = (p1[0] - p0[0]) * (sampleY - p0[1]) - (p1[1] - p0[1]) * (sampleX - p0[0]);
      const w1 = (p2[0] - p1[0]) * (sampleY - p1[1]) - (p2[1] - p1[1]) * (sampleX - p1[0]);
      const w2 = (p0[0] - p2[0]) * (sampleY - p2[1]) - (p0[1] - p2[1]) * (sampleX - p2[0]);
      if ((area > 0 && w0 >= 0 && w1 >= 0 && w2 >= 0) || (area < 0 && w0 <= 0 && w1 <= 0 && w2 <= 0)) {
        setPixel(buffer, width, height, x, y, color);
      }
    }
  }
}

function fillTriangleZ(buffer, zBuffer, width, height, p0, p1, p2, color) {
  const minX = clamp(Math.floor(Math.min(p0[0], p1[0], p2[0])), 0, width - 1);
  const maxX = clamp(Math.ceil(Math.max(p0[0], p1[0], p2[0])), 0, width - 1);
  const minY = clamp(Math.floor(Math.min(p0[1], p1[1], p2[1])), 0, height - 1);
  const maxY = clamp(Math.ceil(Math.max(p0[1], p1[1], p2[1])), 0, height - 1);
  const area = (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1]);
  if (Math.abs(area) < 0.001) return;

  for (let y = minY; y <= maxY; y += 1) {
    for (let x = minX; x <= maxX; x += 1) {
      const sampleX = x + 0.5;
      const sampleY = y + 0.5;
      const b0 = ((p1[0] - sampleX) * (p2[1] - sampleY) - (p2[0] - sampleX) * (p1[1] - sampleY)) / area;
      const b1 = ((p2[0] - sampleX) * (p0[1] - sampleY) - (p0[0] - sampleX) * (p2[1] - sampleY)) / area;
      const b2 = 1 - b0 - b1;
      if (b0 < -0.0001 || b1 < -0.0001 || b2 < -0.0001) continue;

      const depth = b0 * p0[2] + b1 * p1[2] + b2 * p2[2];
      const pixelIndex = y * width + x;
      if (depth < zBuffer[pixelIndex]) continue;
      zBuffer[pixelIndex] = depth;

      const colorIndex = pixelIndex * 4;
      buffer[colorIndex] = color[0];
      buffer[colorIndex + 1] = color[1];
      buffer[colorIndex + 2] = color[2];
      buffer[colorIndex + 3] = color[3] === undefined ? 255 : color[3];
    }
  }
}

function downsampleRgba(source, width, height, factor) {
  if (factor <= 1) return source;
  const targetWidth = Math.floor(width / factor);
  const targetHeight = Math.floor(height / factor);
  const target = Buffer.alloc(targetWidth * targetHeight * 4);
  const sampleCount = factor * factor;

  for (let y = 0; y < targetHeight; y += 1) {
    for (let x = 0; x < targetWidth; x += 1) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      for (let yy = 0; yy < factor; yy += 1) {
        for (let xx = 0; xx < factor; xx += 1) {
          const sourceIndex = (((y * factor + yy) * width) + (x * factor + xx)) * 4;
          r += source[sourceIndex];
          g += source[sourceIndex + 1];
          b += source[sourceIndex + 2];
          a += source[sourceIndex + 3];
        }
      }
      const targetIndex = (y * targetWidth + x) * 4;
      target[targetIndex] = Math.round(r / sampleCount);
      target[targetIndex + 1] = Math.round(g / sampleCount);
      target[targetIndex + 2] = Math.round(b / sampleCount);
      target[targetIndex + 3] = Math.round(a / sampleCount);
    }
  }

  return target;
}

function previewLum(buffer, index) {
  return buffer[index] * 0.2126 + buffer[index + 1] * 0.7152 + buffer[index + 2] * 0.0722;
}

function isPreviewDark(buffer, index) {
  return previewLum(buffer, index) < 72;
}

function isPreviewBackground(buffer, index) {
  const maxChannel = Math.max(buffer[index], buffer[index + 1], buffer[index + 2]);
  const minChannel = Math.min(buffer[index], buffer[index + 1], buffer[index + 2]);
  return previewLum(buffer, index) > 214 && maxChannel - minChannel < 28;
}

function repairPreviewEdgePixels(rgba, width, height) {
  let current = Buffer.from(rgba);
  const background = [246, 246, 244, 255];

  for (let pass = 0; pass < 2; pass += 1) {
    const out = Buffer.from(current);
    for (let y = 2; y < height - 2; y += 1) {
      for (let x = 2; x < width - 2; x += 1) {
        const index = (y * width + x) * 4;
        const light = isPreviewBackground(current, index);
        const dark = isPreviewDark(current, index);
        if (!light && !dark) continue;

        let darkCount = 0;
        let lightCount = 0;
        const darkSum = [0, 0, 0, 0];
        for (let yy = -2; yy <= 2; yy += 1) {
          for (let xx = -2; xx <= 2; xx += 1) {
            if (xx === 0 && yy === 0) continue;
            const neighbor = ((y + yy) * width + (x + xx)) * 4;
            if (isPreviewDark(current, neighbor)) {
              darkCount += 1;
              darkSum[0] += current[neighbor];
              darkSum[1] += current[neighbor + 1];
              darkSum[2] += current[neighbor + 2];
              darkSum[3] += current[neighbor + 3];
            } else if (isPreviewBackground(current, neighbor)) {
              lightCount += 1;
            }
          }
        }

        if (light && darkCount >= 14) {
          out[index] = Math.round(darkSum[0] / darkCount);
          out[index + 1] = Math.round(darkSum[1] / darkCount);
          out[index + 2] = Math.round(darkSum[2] / darkCount);
          out[index + 3] = 255;
        } else if (dark && darkCount <= 3 && lightCount >= 16) {
          out[index] = background[0];
          out[index + 1] = background[1];
          out[index + 2] = background[2];
          out[index + 3] = background[3];
        }
      }
    }
    current = out;
  }

  const softened = Buffer.from(current);
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const index = (y * width + x) * 4;
      if (!isPreviewDark(current, index) && !isPreviewBackground(current, index)) continue;

      let darkCount = 0;
      let lightCount = 0;
      const sum = [0, 0, 0, 0];
      for (let yy = -1; yy <= 1; yy += 1) {
        for (let xx = -1; xx <= 1; xx += 1) {
          const neighbor = ((y + yy) * width + (x + xx)) * 4;
          const neighborDark = isPreviewDark(current, neighbor);
          const neighborLight = isPreviewBackground(current, neighbor);
          if (!neighborDark && !neighborLight) continue;
          if (neighborDark) darkCount += 1;
          if (neighborLight) lightCount += 1;
          sum[0] += current[neighbor];
          sum[1] += current[neighbor + 1];
          sum[2] += current[neighbor + 2];
          sum[3] += current[neighbor + 3];
        }
      }

      const count = darkCount + lightCount;
      if (count <= 0 || darkCount <= 0 || lightCount <= 0) continue;
      const blend = isPreviewDark(current, index) ? 0.24 : 0.34;
      softened[index] = Math.round(current[index] * (1 - blend) + (sum[0] / count) * blend);
      softened[index + 1] = Math.round(current[index + 1] * (1 - blend) + (sum[1] / count) * blend);
      softened[index + 2] = Math.round(current[index + 2] * (1 - blend) + (sum[2] / count) * blend);
      softened[index + 3] = 255;
    }
  }

  return softened;
}

function transformPoint(p, rotation) {
  const cy = Math.cos(rotation.y);
  const sy = Math.sin(rotation.y);
  const cx = Math.cos(rotation.x);
  const sx = Math.sin(rotation.x);
  const x1 = p[0] * cy + p[2] * sy;
  const z1 = -p[0] * sy + p[2] * cy;
  const y2 = p[1] * cx - z1 * sx;
  const z2 = p[1] * sx + z1 * cx;
  return [x1, y2, z2];
}

function materialColor(material, center, shade, palette) {
  if (material === "gold" || material === "hardware") {
    return shadeRgba(palette.hardware.rgba, shade);
  }
  if (material === "engraving") {
    return shadeRgba(palette.engraving.rgba, shade);
  }
  if (!palette.frame.isTortoise) {
    return shadeRgba(palette.frame.rgba, shade);
  }
  const n =
    Math.sin(center[0] * 0.29 + center[2] * 0.11) +
    Math.sin(center[0] * 0.07 - center[1] * 0.33 + 1.7) +
    Math.sin(center[2] * 0.19 + 2.2);
  const warm = n > 0.65;
  const base = warm ? [112, 52, 18] : [45, 28, 20];
  const flicker = warm ? 1.08 : 0.9;
  return [
    clamp(Math.round(base[0] * shade * flicker), 0, 255),
    clamp(Math.round(base[1] * shade * flicker), 0, 255),
    clamp(Math.round(base[2] * shade * flicker), 0, 255),
    255,
  ];
}

function renderMeshPreview(mesh, filePath, style, options = {}) {
  const outputWidth = 1500;
  const outputHeight = 900;
  const supersample = clamp(safeInt(options.supersample, 3), 1, 4);
  const width = outputWidth * supersample;
  const height = outputHeight * supersample;
  const palette = {
    frame: normalizeColorToken(style.frame_color, "#1F2D57"),
    engraving: normalizeColorToken(style.arm_text_color, "#C9A14A"),
    hardware: normalizeColorToken("gold", "#C9A14A"),
  };
  const rgba = Buffer.alloc(width * height * 4);
  const zBuffer = new Float32Array(width * height);
  zBuffer.fill(-Infinity);
  for (let i = 0; i < rgba.length; i += 4) {
    rgba[i] = 246;
    rgba[i + 1] = 246;
    rgba[i + 2] = 244;
    rgba[i + 3] = 255;
  }
  const rotation = { x: (-14 * Math.PI) / 180, y: (-28 * Math.PI) / 180 };
  const transformed = [];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const tri of mesh.triangles) {
    const pts = [tri.a, tri.b, tri.c].map((p) => transformPoint(p, rotation));
    for (const p of pts) {
      minX = Math.min(minX, p[0]);
      minY = Math.min(minY, p[1]);
      maxX = Math.max(maxX, p[0]);
      maxY = Math.max(maxY, p[1]);
    }
    const center = [
      (tri.a[0] + tri.b[0] + tri.c[0]) / 3,
      (tri.a[1] + tri.b[1] + tri.c[1]) / 3,
      (tri.a[2] + tri.b[2] + tri.c[2]) / 3,
    ];
    transformed.push({ tri, pts, center, depth: (pts[0][2] + pts[1][2] + pts[2][2]) / 3 });
  }

  const scale = Math.min((width * 0.82) / (maxX - minX || 1), (height * 0.78) / (maxY - minY || 1));
  const offsetX = width / 2 - ((minX + maxX) / 2) * scale;
  const offsetY = height / 2 + ((minY + maxY) / 2) * scale + 20;
  const light = [-0.25, -0.4, 0.88];

  transformed.sort((a, b) => a.depth - b.depth);
  for (const item of transformed) {
    const n = normal(item.pts[0], item.pts[1], item.pts[2]);
    const dot = clamp(n[0] * light[0] + n[1] * light[1] + n[2] * light[2], -1, 1);
    const shade = clamp(0.72 + dot * 0.28, 0.48, 1.08);
    const color = materialColor(item.tri.material, item.center, shade, palette);
    const screen = item.pts.map((p) => [offsetX + p[0] * scale, offsetY - p[1] * scale, p[2]]);
    fillTriangleZ(rgba, zBuffer, width, height, screen[0], screen[1], screen[2], color);
  }

  const preview = repairPreviewEdgePixels(downsampleRgba(rgba, width, height, supersample), outputWidth, outputHeight);
  writePng(filePath, outputWidth, outputHeight, preview);
}

function writeTracePng(filePath, trace, color) {
  const scale = Math.max(1, Math.floor(900 / trace.width));
  const width = trace.width * scale;
  const height = trace.height * scale;
  const rgba = Buffer.alloc(width * height * 4);
  for (let i = 0; i < rgba.length; i += 4) {
    rgba[i] = 247;
    rgba[i + 1] = 247;
    rgba[i + 2] = 245;
    rgba[i + 3] = 255;
  }
  for (let y = 0; y < trace.height; y += 1) {
    for (let x = 0; x < trace.width; x += 1) {
      if (!trace.mask[y * trace.width + x]) continue;
      for (let yy = 0; yy < scale; yy += 1) {
        for (let xx = 0; xx < scale; xx += 1) {
          setPixel(rgba, width, height, x * scale + xx, y * scale + yy, color);
        }
      }
    }
  }
  writePng(filePath, width, height, rgba);
}

function main() {
  const args = parseArgs(process.argv);
  const referenceImage = args.reference_image ? path.resolve(String(args.reference_image)) : null;
  if (!referenceImage) {
    throw new Error("Missing --reference-image");
  }

  const outputDir = path.resolve(String(args.output_dir || "outputs"));
  ensureDir(outputDir);
  const image = decodePng(referenceImage);
  const style = { ...DEFAULT_STYLE };
  for (const key of Object.keys(style)) {
    if (args[key] !== undefined && args[key] !== true) style[key] = String(args[key]);
  }

  const frontCrop = parseCrop(args.front_crop, image, "210,20,1120,370");
  const sideCrop = parseCrop(args.side_crop, image, "340,392,1005,275");
  const frontGridWidth = safeInt(args.front_grid_width, 760);
  const sideGridWidth = safeInt(args.side_grid_width, 670);
  const frontRefineScale = clamp(safeInt(args.front_refine_scale, 3), 1, 3);
  const sideRefineScale = clamp(safeInt(args.side_refine_scale, 1), 1, 3);
  const smoothFrontSideWalls = args.front_smooth_sidewalls === undefined
    ? true
    : String(args.front_smooth_sidewalls).toLowerCase() !== "false";
  const decorativeFrontRivets = String(args.front_rivets || "").toLowerCase() === "true";
  const previewSupersample = clamp(safeInt(args.preview_supersample, 3), 1, 4);
  const frontWidthMm = safeFloat(args.front_width_mm, 140);
  const frontDepthMm = safeFloat(args.front_depth_mm, 4.6);
  const armLengthMm = safeFloat(args.arm_length_mm, 138);
  const armThicknessMm = safeFloat(args.arm_thickness_mm, 3.7);

  const frontTraceRaw = buildMaskFromCrop(image, frontCrop, {
    gridWidth: frontGridWidth,
    threshold: safeFloat(args.front_threshold, 30),
    luminanceMax: safeFloat(args.front_luminance_max, 248),
    saturationMin: safeFloat(args.front_saturation_min, 0.018),
    samples: 5,
    minHits: 8,
  });
  let frontTrace = finalizeTrace(frontTraceRaw, {
    minPixels: 30,
    gapRepairIterations: 1,
    smoothIterations: 2,
    keepLargestOnly: false,
    padding: 2,
  });
  frontTrace = refineTraceResolution(frontTrace, {
    scale: frontRefineScale,
    minPixels: 30,
    smoothIterations: 1,
    gapRepairIterations: 1,
    keepLargestOnly: false,
    padding: 2,
  });

  const sideTraceRaw = buildMaskFromCrop(image, sideCrop, {
    gridWidth: sideGridWidth,
    threshold: safeFloat(args.side_threshold, 32),
    luminanceMax: safeFloat(args.side_luminance_max, 248),
    saturationMin: safeFloat(args.side_saturation_min, 0.018),
    samples: 5,
    minHits: 12,
  });
  let sideTrace = finalizeTrace(sideTraceRaw, {
    minPixels: 80,
    gapRepairIterations: 1,
    smoothIterations: 1,
    keepLargestOnly: true,
    padding: 2,
  });
  sideTrace = refineTraceResolution(sideTrace, {
    scale: sideRefineScale,
    minPixels: 80,
    smoothIterations: 1,
    gapRepairIterations: 1,
    keepLargestOnly: true,
    padding: 2,
  });

  const frameFront = new Mesh("frame_front");
  const frontProfile = addRasterExtrusionXY(frameFront, frontTrace, frontWidthMm, frontDepthMm, "acetate", {
    smoothSideWalls: smoothFrontSideWalls,
    smoothIterations: safeInt(args.front_contour_smooth_iterations, 4),
    minSegmentGrid: safeFloat(args.front_contour_min_segment_px, 2.4),
    minAreaPx: safeFloat(args.front_contour_min_area_px, 18),
    coverWidthMm: args.front_contour_cover_mm === undefined ? undefined : safeFloat(args.front_contour_cover_mm, 0),
    coverZOffsetMm: safeFloat(args.front_contour_cover_z_offset_mm, 0.035),
    capInsetPx: args.front_cap_inset_px === undefined ? undefined : safeInt(args.front_cap_inset_px, 0),
  });
  if (decorativeFrontRivets) {
    addFrontRivets(frameFront, frameFront.bounds(), frontDepthMm);
  }

  const frontBounds = frameFront.bounds();
  const hingeX = frontBounds.max[0] - 3.2;
  const yOffset = safeFloat(args.arm_y_offset_mm, -5.0);
  const zStart = -frontDepthMm / 2 + 1.35;

  const rightArm = new Mesh("right_arm");
  const rightArmProfile = addRasterExtrusionYZ(rightArm, sideTrace, {
    targetLengthMm: armLengthMm,
    thicknessMm: armThicknessMm,
    xCenter: hingeX + armThicknessMm / 2,
    side: 1,
    zStart,
    yOffset,
    material: "acetate",
  });
  const leftArm = mirrorMeshX(rightArm, "left_arm");
  const hingeProfile = {
    method: "arm_depth_overlap_without_extra_blocks",
    right_contact_x_mm: hingeX,
    left_contact_x_mm: -hingeX,
    y_offset_mm: yOffset,
    lowered_from_previous_mm: roundValue(-1.8 - yOffset, 3),
    z_start_mm: zStart,
    front_back_z_mm: -frontDepthMm / 2,
    overlap_mm: zStart - -frontDepthMm / 2,
  };

  const engravingMesh = new Mesh("engraving");
  const engravingOptions = {
    text: style.arm_text,
    side: 1,
    xSurface: hingeX + armThicknessMm + 0.04,
    startZ: -16.5,
    baseY: 5.25,
    heightMm: 5.2,
    maxLengthMm: 64,
    reliefMm: 1.1,
    material: "engraving",
  };
  const engravingProfile = addNaelEmboss(rightArm, engravingOptions);
  addNaelEmboss(engravingMesh, engravingOptions);

  const fullFrame = cloneMesh(frameFront, "full_frame");
  fullFrame.merge(leftArm);
  fullFrame.merge(rightArm);

  const paths = {
    frame_front: path.join(outputDir, "frame_front.stl"),
    left_arm: path.join(outputDir, "left_arm.stl"),
    right_arm: path.join(outputDir, "right_arm.stl"),
    full_frame: path.join(outputDir, "full_frame.stl"),
    engraving: path.join(outputDir, "engraving.stl"),
    metadata: path.join(outputDir, "frame_metadata.json"),
    front_trace_svg: path.join(outputDir, "frameana_image2stl_front_trace.svg"),
    side_trace_svg: path.join(outputDir, "frameana_image2stl_side_trace.svg"),
    front_trace_png: path.join(outputDir, "frameana_image2stl_front_trace.png"),
    side_trace_png: path.join(outputDir, "frameana_image2stl_side_trace.png"),
    preview_png: path.join(outputDir, "frameana_image2stl_3d_preview.png"),
  };
  const frameColor = normalizeColorToken(style.frame_color, "#1F2D57");
  const engravingColor = normalizeColorToken(style.arm_text_color, "#C9A14A");

  writeBinaryStl(frameFront, paths.frame_front);
  writeBinaryStl(leftArm, paths.left_arm);
  writeBinaryStl(rightArm, paths.right_arm);
  writeBinaryStl(fullFrame, paths.full_frame);
  if (engravingMesh.triangles.length > 0) {
    writeBinaryStl(engravingMesh, paths.engraving);
  }
  writeTraceSvg(paths.front_trace_svg, frontTrace, frameColor.css);
  writeTraceSvg(paths.side_trace_svg, sideTrace, frameColor.css);
  writeTracePng(paths.front_trace_png, frontTrace, frameColor.rgba);
  writeTracePng(paths.side_trace_png, sideTrace, frameColor.rgba);
  renderMeshPreview(fullFrame, paths.preview_png, style, { supersample: previewSupersample });

  const outputInfo = {
    frame_front: { path: path.resolve(paths.frame_front), bytes: fs.statSync(paths.frame_front).size, triangles: frameFront.triangles.length, bounds_mm: roundValue(frameFront.bounds()) },
    left_arm: { path: path.resolve(paths.left_arm), bytes: fs.statSync(paths.left_arm).size, triangles: leftArm.triangles.length, bounds_mm: roundValue(leftArm.bounds()) },
    right_arm: { path: path.resolve(paths.right_arm), bytes: fs.statSync(paths.right_arm).size, triangles: rightArm.triangles.length, bounds_mm: roundValue(rightArm.bounds()) },
    full_frame: { path: path.resolve(paths.full_frame), bytes: fs.statSync(paths.full_frame).size, triangles: fullFrame.triangles.length, bounds_mm: roundValue(fullFrame.bounds()) },
    front_trace_svg: { path: path.resolve(paths.front_trace_svg), bytes: fs.statSync(paths.front_trace_svg).size },
    side_trace_svg: { path: path.resolve(paths.side_trace_svg), bytes: fs.statSync(paths.side_trace_svg).size },
    front_trace_png: { path: path.resolve(paths.front_trace_png), bytes: fs.statSync(paths.front_trace_png).size },
    side_trace_png: { path: path.resolve(paths.side_trace_png), bytes: fs.statSync(paths.side_trace_png).size },
    preview_png: { path: path.resolve(paths.preview_png), bytes: fs.statSync(paths.preview_png).size },
  };
  if (engravingMesh.triangles.length > 0) {
    outputInfo.engraving = {
      path: path.resolve(paths.engraving),
      bytes: fs.statSync(paths.engraving).size,
      triangles: engravingMesh.triangles.length,
      bounds_mm: roundValue(engravingMesh.bounds()),
    };
  }

  const metadata = {
    stage: "FRAMEANA Stage 2C-4/2C-5 - 2D reference image to STL",
    generated_at: new Date().toISOString(),
    generator: {
      file: path.resolve(__filename),
      runtime: process.version,
      dependencies: "none",
      units: "millimeters",
      stl_format: "binary",
      geometry_source: "accepted_ai_cad_reference_2d_silhouette_extrusion",
      uses_ai_image_generation_during_stl_step: false,
      pixel_edge_repair: {
        front_refine_scale: frontRefineScale,
        side_refine_scale: sideRefineScale,
        front_smooth_sidewalls: smoothFrontSideWalls,
        decorative_front_rivets: decorativeFrontRivets,
        preview_supersample: previewSupersample,
        preview_edge_cleanup: true,
        gap_repair: "fills one-pixel horizontal, vertical, and diagonal breaks before STL extrusion",
      },
    },
    source_inputs: {
      reference_image: path.resolve(referenceImage),
      image_size_px: { width: image.width, height: image.height },
      front_crop_px: frontCrop,
      side_crop_px: sideCrop,
    },
    style_options: style,
    appearance: {
      frame_color: style.frame_color,
      frame_color_css: frameColor.css,
      engraving_color: style.arm_text_color,
      engraving_color_css: engravingColor.css,
    },
    geometry_profile: {
      principle: "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      front: { ...frontProfile, trace_info: roundValue(traceSummary(frontTrace)) },
      side_arm: {
        ...rightArmProfile,
        trace_info: roundValue(traceSummary(sideTrace)),
        hinge_connection: roundValue(hingeProfile),
        text_geometry: {
          side_emboss: engravingProfile || {
            text: style.arm_text,
            surface: "outside_right_arm",
            start_z_mm: -16.5,
            base_y_mm: 5.25,
            height_mm: 5.2,
            relief_mm: 1.1,
          },
        },
      },
      limitations: [
        "STL stores geometry only; selected colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace.",
      ],
    },
    frontend_assets: {
      reference_2d: path.resolve(referenceImage),
      preview_png: path.resolve(paths.preview_png),
      front_trace_png: path.resolve(paths.front_trace_png),
      side_trace_png: path.resolve(paths.side_trace_png),
    },
    frontend_manifest: {
      reference_2d: path.basename(referenceImage),
      preview_png: path.basename(paths.preview_png),
      traces: {
        front_png: path.basename(paths.front_trace_png),
        side_png: path.basename(paths.side_trace_png),
        front_svg: path.basename(paths.front_trace_svg),
        side_svg: path.basename(paths.side_trace_svg),
      },
      stl: {
        frame_front: path.basename(paths.frame_front),
        left_arm: path.basename(paths.left_arm),
        right_arm: path.basename(paths.right_arm),
        full_frame: path.basename(paths.full_frame),
        engraving: engravingMesh.triangles.length > 0 ? path.basename(paths.engraving) : null,
      },
      metadata: path.basename(paths.metadata),
    },
    outputs: outputInfo,
  };

  fs.writeFileSync(paths.metadata, `${JSON.stringify(metadata, null, 2)}\n`, "utf8");

  const reportPath = path.join(outputDir, "frameana_image2stl_result.md");
  const report = [
    "# FRAMEANA Image2STL Result",
    "",
    `Source 2D reference: ${path.resolve(referenceImage)}`,
    `Preview PNG: ${path.resolve(paths.preview_png)}`,
    "",
    "Generated:",
    `- ${path.resolve(paths.frame_front)}`,
    `- ${path.resolve(paths.left_arm)}`,
    `- ${path.resolve(paths.right_arm)}`,
    `- ${path.resolve(paths.full_frame)}`,
    engravingMesh.triangles.length > 0 ? `- ${path.resolve(paths.engraving)}` : null,
    `- ${path.resolve(paths.metadata)}`,
    "",
    "Notes:",
    "- The front STL is traced from the accepted 2D front view, then extruded.",
    "- The arm STL is traced from the accepted 2D side view and overlaps the front frame slightly at the hinge instead of using extra hinge blocks.",
    "- Nael is raised geometry directly on the right arm, not only color metadata.",
    "- Color/material remain metadata because STL itself has no material channel.",
    "",
  ].filter(Boolean).join("\n");
  fs.writeFileSync(reportPath, report, "utf8");

  console.log(JSON.stringify({ ok: true, outputs: outputInfo, report: path.resolve(reportPath) }, null, 2));
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error && error.stack ? error.stack : String(error));
    process.exit(1);
  }
}
