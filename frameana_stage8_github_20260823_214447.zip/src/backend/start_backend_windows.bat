@echo off
setlocal
cd /d "%~dp0"

set "PORT=8080"
set "HOST=127.0.0.1"
set "FRAMEANA_GENERATOR_MODE=cli"
set "FRAMEANA_GENERATOR_PATH=%~dp0frameana_image2stl_generator.js"
if not defined FRAMEANA_SEGMIND_LIVE set "FRAMEANA_SEGMIND_LIVE=auto"
if not defined FRAMEANA_SEGMIND_FRAME_PREVIEW set "FRAMEANA_SEGMIND_FRAME_PREVIEW=auto"
if not defined FRAMEANA_SEGMIND_SCRIPT_PATH if exist "%~dp0..\chatgpt_segmind_tryon.py" set "FRAMEANA_SEGMIND_SCRIPT_PATH=%~dp0..\chatgpt_segmind_tryon.py"
if not defined FRAMEANA_SEGMIND_API_KEY_FILE if exist "%~dp0..\segmind_api_key.txt" set "FRAMEANA_SEGMIND_API_KEY_FILE=%~dp0..\segmind_api_key.txt"
if not defined FRAMEANA_PYTHON_EXE if exist "%~dp0..\venv\Scripts\python.exe" set "FRAMEANA_PYTHON_EXE=%~dp0..\venv\Scripts\python.exe"
if not defined FRAMEANA_FRONT_CROP set "FRAMEANA_FRONT_CROP=55,105,1145,500"
if not defined FRAMEANA_SIDE_CROP set "FRAMEANA_SIDE_CROP=230,735,955,365"
if not defined FRAMEANA_REFERENCE_IMAGE_PATH if exist "%~dp0references\frame_reference_2d.png" set "FRAMEANA_REFERENCE_IMAGE_PATH=%~dp0references\frame_reference_2d.png"
if not defined FRAMEANA_REFERENCE_IMAGE_PATH if exist "%~dp0..\parts.png" set "FRAMEANA_REFERENCE_IMAGE_PATH=%~dp0..\parts.png"
if not defined FRAMEANA_AI_TRYON_IMAGE_PATH if exist "%~dp0references\frame_tryon.png" set "FRAMEANA_AI_TRYON_IMAGE_PATH=%~dp0references\frame_tryon.png"
if not defined FRAMEANA_TRYON_API_URL set "FRAMEANA_TRYON_API_URL=http://127.0.0.1:8000/generate-tryon"

if not exist "%FRAMEANA_GENERATOR_PATH%" (
  echo [ERROR] Generator not found:
  echo %FRAMEANA_GENERATOR_PATH%
  echo Run install_to_frameana.bat again or copy frameana_image2stl_generator.js into this backend folder.
  pause
  exit /b 1
)

if not exist "%FRAMEANA_REFERENCE_IMAGE_PATH%" (
  echo [WARN] FRAMEANA_REFERENCE_IMAGE_PATH was not found.
  echo The backend will try automatic reference lookup.
)

if not exist node_modules (
  echo Installing backend packages...
  call npm install
  if errorlevel 1 exit /b 1
)

node frameana_backend_server.js
endlocal
