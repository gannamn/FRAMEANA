"use strict";

const crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");

const ORDER_STATUS = Object.freeze({
  NEW: 1,
  SUBMITTED: 2,
  RECEIVED: 3,
  FINISHED: 4,
  DELIVERED: 5,
  CLIENT_FEEDBACK: 6,
});

const ORDER_STATUS_LABELS = Object.freeze({
  [ORDER_STATUS.NEW]: "جديد",
  [ORDER_STATUS.SUBMITTED]: "تم الإرسال",
  [ORDER_STATUS.RECEIVED]: "استلمته FRAMEANA",
  [ORDER_STATUS.FINISHED]: "منتهي",
  [ORDER_STATUS.DELIVERED]: "تم التسليم",
  [ORDER_STATUS.CLIENT_FEEDBACK]: "ملاحظات العميل",
});

const CLIENT_CREATE_STATUSES = new Set([ORDER_STATUS.NEW, ORDER_STATUS.SUBMITTED]);
const ADMIN_STATUSES = new Set([
  ORDER_STATUS.SUBMITTED,
  ORDER_STATUS.RECEIVED,
  ORDER_STATUS.FINISHED,
  ORDER_STATUS.DELIVERED,
]);

function nowIso() {
  return new Date().toISOString();
}

function createHttpError(status, message) {
  const error = new Error(message);
  error.httpStatus = status;
  return error;
}

function safeText(value, fallback = "", maxLength = 500) {
  if (typeof value !== "string") return fallback;
  return value.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, maxLength);
}

function normalizeEmail(value) {
  return safeText(value, "", 254).toLowerCase();
}

function toNumberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function firstValue(...values) {
  return values.find((value) => value !== undefined && value !== null && value !== "");
}

function jsonText(value) {
  return JSON.stringify(value || {}, null, 2);
}

function base64urlJson(value) {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function signJwt(payload, secret, expiresInSeconds = 7 * 24 * 60 * 60) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "HS256", typ: "JWT" };
  const body = {
    ...payload,
    iat: now,
    exp: now + expiresInSeconds,
  };
  const unsignedToken = `${base64urlJson(header)}.${base64urlJson(body)}`;
  const signature = crypto.createHmac("sha256", secret).update(unsignedToken).digest("base64url");
  return `${unsignedToken}.${signature}`;
}

function verifyJwt(token, secret) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) throw createHttpError(401, "رمز الدخول غير صالح.");

  const [header, payload, signature] = parts;
  const unsignedToken = `${header}.${payload}`;
  const expected = crypto.createHmac("sha256", secret).update(unsignedToken).digest("base64url");
  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (
    signatureBuffer.length !== expectedBuffer.length ||
    !crypto.timingSafeEqual(signatureBuffer, expectedBuffer)
  ) {
    throw createHttpError(401, "رمز الدخول غير صالح.");
  }

  let decoded;
  try {
    decoded = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
  } catch {
    throw createHttpError(401, "رمز الدخول غير صالح.");
  }

  if (!decoded.exp || decoded.exp < Math.floor(Date.now() / 1000)) {
    throw createHttpError(401, "انتهت صلاحية جلسة الدخول.");
  }

  return decoded;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("base64url");
  const hash = crypto.scryptSync(password, salt, 64).toString("base64url");
  return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, storedHash) {
  const parts = String(storedHash || "").split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;

  const [, salt, expectedHash] = parts;
  const actual = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHash, "base64url");
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    created_at: row.created_at,
    is_active: Boolean(row.is_active),
    is_admin: Boolean(row.is_admin),
  };
}

function orderNumber(orderId) {
  return `FR-${String(orderId).padStart(5, "0")}`;
}

function serializeOrder(row) {
  if (!row) return null;

  let metadata = {};
  try {
    metadata = row.metadata_json ? JSON.parse(row.metadata_json) : {};
  } catch {
    metadata = {};
  }

  return {
    id: row.id,
    order_number: row.order_number,
    user_id: row.user_id,
    status: row.status,
    status_label: ORDER_STATUS_LABELS[row.status] || "Unknown",
    created_at: row.created_at,
    updated_at: row.updated_at,
    submitted_at: row.submitted_at,
    frame_style: row.frame_style,
    frame_color: row.frame_color,
    material: row.material,
    engraving_text: row.engraving_text,
    engraving_color: row.engraving_color,
    face_width: row.face_width,
    eye_distance: row.eye_distance,
    nose_width: row.nose_width,
    head_angle: row.head_angle,
    tryon_image: row.tryon_image,
    frame_front_image: row.frame_front_image,
    frame_side_image: row.frame_side_image,
    frame_front_stl: row.frame_front_stl,
    left_arm_stl: row.left_arm_stl,
    right_arm_stl: row.right_arm_stl,
    full_frame_stl: row.full_frame_stl,
    feedback_text: row.feedback_text,
    job_id: row.job_id,
    metadata,
  };
}

function extractOrderDesign(designPayload) {
  const design = designPayload && typeof designPayload === "object" ? designPayload : {};
  const workflowResult = design.workflow_result || design.workflowResult || {};
  const outputs = workflowResult.outputs || design.outputs || {};
  const metadata = workflowResult.metadata || design.metadata || {};
  const config = design.config || {};
  const customization = metadata.customization || {};
  const dimensions =
    metadata.dimensions || metadata.measurements || metadata.frame_dimensions || metadata.geometry || {};

  return {
    jobId: safeText(workflowResult.job_id || design.job_id || metadata.job_id, "", 120),
    frameStyle: safeText(firstValue(metadata.style, customization.style, config.model), "", 80),
    material: safeText(firstValue(metadata.material, customization.material, config.material), "", 80),
    frameColor: safeText(firstValue(metadata.frame_color, metadata.color, customization.frame_color, config.frameColor), "", 40),
    engravingText: safeText(
      firstValue(metadata.engraving_text, metadata.engraving?.text, customization.engraving, config.engraving),
      "",
      120
    ),
    engravingColor: safeText(
      firstValue(metadata.engraving_color, metadata.engraving?.color, customization.engraving_color, config.engravingColor),
      "",
      40
    ),
    faceWidth: toNumberOrNull(firstValue(metadata.face_width, dimensions.face_width, dimensions.face_width_mm)),
    eyeDistance: toNumberOrNull(firstValue(metadata.eye_distance, dimensions.eye_distance, dimensions.eye_distance_mm)),
    noseWidth: toNumberOrNull(firstValue(metadata.nose_width, dimensions.nose_width, dimensions.nose_width_mm)),
    headAngle: toNumberOrNull(firstValue(metadata.head_angle, dimensions.head_angle, dimensions.head_angle_degrees)),
    tryonImage: safeText(firstValue(design.customer_preview, outputs.customer_tryon, outputs.tryon_preview), "", 1000),
    frameFrontImage: safeText(firstValue(design.frame_preview, outputs.frame_preview, outputs.frame_orthographic), "", 1000),
    frameSideImage: safeText(firstValue(outputs.frame_orthographic, outputs.frame_3d_preview), "", 1000),
    frameFrontStl: safeText(outputs.frame_front, "", 1000),
    leftArmStl: safeText(outputs.left_arm, "", 1000),
    rightArmStl: safeText(outputs.right_arm, "", 1000),
    fullFrameStl: safeText(outputs.full_frame, "", 1000),
    metadataJson: jsonText({
      config,
      metadata,
      outputs,
      job_id: workflowResult.job_id || design.job_id || metadata.job_id || null,
    }),
  };
}

function createStage8Store({ dbPath, jwtSecret }) {
  const db = new DatabaseSync(dbPath);
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      is_admin INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE,
      user_id INTEGER NOT NULL,
      status INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      submitted_at TEXT,
      frame_style TEXT,
      frame_color TEXT,
      material TEXT,
      engraving_text TEXT,
      engraving_color TEXT,
      face_width REAL,
      eye_distance REAL,
      nose_width REAL,
      head_angle REAL,
      tryon_image TEXT,
      frame_front_image TEXT,
      frame_side_image TEXT,
      frame_front_stl TEXT,
      left_arm_stl TEXT,
      right_arm_stl TEXT,
      full_frame_stl TEXT,
      metadata_json TEXT,
      feedback_text TEXT,
      job_id TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS order_status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      status INTEGER NOT NULL,
      changed_by_user_id INTEGER,
      actor_type TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (changed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_orders_user_status ON orders(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_order_status_history_order ON order_status_history(order_id, created_at);
  `);

  const statements = {
    insertUser: db.prepare(`
      INSERT INTO users (name, email, password_hash, created_at, is_active, is_admin)
      VALUES (?, ?, ?, ?, 1, 0)
    `),
    getUserByEmail: db.prepare("SELECT * FROM users WHERE email = ?"),
    getUserById: db.prepare("SELECT * FROM users WHERE id = ?"),
    countNewOrders: db.prepare("SELECT COUNT(*) AS count FROM orders WHERE user_id = ? AND status = ?"),
    insertOrder: db.prepare(`
      INSERT INTO orders (
        user_id, status, created_at, updated_at, submitted_at,
        frame_style, frame_color, material, engraving_text, engraving_color,
        face_width, eye_distance, nose_width, head_angle,
        tryon_image, frame_front_image, frame_side_image,
        frame_front_stl, left_arm_stl, right_arm_stl, full_frame_stl,
        metadata_json, job_id
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `),
    setOrderNumber: db.prepare("UPDATE orders SET order_number = ? WHERE id = ?"),
    insertHistory: db.prepare(`
      INSERT INTO order_status_history (order_id, status, changed_by_user_id, actor_type, note, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `),
    listOrdersForUser: db.prepare(`
      SELECT * FROM orders
      WHERE user_id = ?
      ORDER BY datetime(created_at) DESC, id DESC
    `),
    listAdminOrders: db.prepare(`
      SELECT orders.*, users.name AS user_name, users.email AS user_email
      FROM orders
      JOIN users ON users.id = orders.user_id
      ORDER BY datetime(orders.created_at) DESC, orders.id DESC
    `),
    getOrderForUser: db.prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?"),
    getOrderById: db.prepare("SELECT * FROM orders WHERE id = ?"),
    updateOrderStatus: db.prepare(`
      UPDATE orders
      SET status = ?, updated_at = ?, submitted_at = COALESCE(submitted_at, ?)
      WHERE id = ?
    `),
    updateFeedback: db.prepare(`
      UPDATE orders
      SET status = ?, feedback_text = ?, updated_at = ?
      WHERE id = ?
    `),
    deleteOrder: db.prepare("DELETE FROM orders WHERE id = ?"),
    listHistory: db.prepare(`
      SELECT order_status_history.*, users.name AS changed_by_name
      FROM order_status_history
      LEFT JOIN users ON users.id = order_status_history.changed_by_user_id
      WHERE order_id = ?
      ORDER BY datetime(order_status_history.created_at) ASC, order_status_history.id ASC
    `),
  };

  function issueToken(user) {
    return signJwt({ sub: user.id, email: user.email }, jwtSecret);
  }

  function registerUser(payload) {
    const name = safeText(payload?.name, "", 120);
    const email = normalizeEmail(payload?.email);
    const password = typeof payload?.password === "string" ? payload.password : "";

    if (!name) throw createHttpError(400, "الاسم مطلوب.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw createHttpError(400, "البريد الإلكتروني غير صالح.");
    if (password.length < 6) throw createHttpError(400, "كلمة المرور يجب أن تكون 6 أحرف على الأقل.");

    let result;
    try {
      result = statements.insertUser.run(name, email, hashPassword(password), nowIso());
    } catch (error) {
      if (String(error.message || "").toLowerCase().includes("unique")) {
        throw createHttpError(409, "هذا البريد الإلكتروني مسجل مسبقًا.");
      }
      throw error;
    }

    const user = publicUser(statements.getUserById.get(result.lastInsertRowid));
    return { user, token: issueToken(user) };
  }

  function loginUser(payload) {
    const email = normalizeEmail(payload?.email);
    const password = typeof payload?.password === "string" ? payload.password : "";
    const row = statements.getUserByEmail.get(email);

    if (!row || !row.is_active || !verifyPassword(password, row.password_hash)) {
      throw createHttpError(401, "البريد الإلكتروني أو كلمة المرور غير صحيحة.");
    }

    const user = publicUser(row);
    return { user, token: issueToken(user) };
  }

  function getUserByToken(token) {
    const decoded = verifyJwt(token, jwtSecret);
    const userId = Number(decoded.sub);
    if (!Number.isInteger(userId)) throw createHttpError(401, "رمز الدخول غير صالح.");

    const row = statements.getUserById.get(userId);
    if (!row || !row.is_active) throw createHttpError(401, "الحساب غير نشط أو لم يعد موجودًا.");
    return publicUser(row);
  }

  function addHistory({ orderId, status, userId = null, actorType, note = "" }) {
    statements.insertHistory.run(orderId, status, userId, actorType, safeText(note, "", 300), nowIso());
  }

  function createOrder({ userId, status, design }) {
    const requestedStatus = Number(status || ORDER_STATUS.NEW);
    if (!CLIENT_CREATE_STATUSES.has(requestedStatus)) {
      throw createHttpError(400, "يمكن إنشاء طلبات العميل فقط بحالة جديد أو تم الإرسال.");
    }

    if (requestedStatus === ORDER_STATUS.NEW) {
      const existingNewCount = Number(statements.countNewOrders.get(userId, ORDER_STATUS.NEW)?.count || 0);
      if (existingNewCount >= 5) {
        throw createHttpError(
          409,
          "لديك بالفعل 5 تصاميم محفوظة. أرسل أو احذف أحد الطلبات الجديدة قبل حفظ تصميم آخر."
        );
      }
    }

    const orderData = extractOrderDesign(design);
    const createdAt = nowIso();
    const submittedAt = requestedStatus === ORDER_STATUS.SUBMITTED ? createdAt : null;
    const result = statements.insertOrder.run(
      userId,
      requestedStatus,
      createdAt,
      createdAt,
      submittedAt,
      orderData.frameStyle,
      orderData.frameColor,
      orderData.material,
      orderData.engravingText,
      orderData.engravingColor,
      orderData.faceWidth,
      orderData.eyeDistance,
      orderData.noseWidth,
      orderData.headAngle,
      orderData.tryonImage,
      orderData.frameFrontImage,
      orderData.frameSideImage,
      orderData.frameFrontStl,
      orderData.leftArmStl,
      orderData.rightArmStl,
      orderData.fullFrameStl,
      orderData.metadataJson,
      orderData.jobId
    );

    const orderId = result.lastInsertRowid;
    statements.setOrderNumber.run(orderNumber(orderId), orderId);
    addHistory({
      orderId,
      status: requestedStatus,
      userId,
      actorType: "client",
      note: requestedStatus === ORDER_STATUS.SUBMITTED ? "تم الإنشاء والإرسال" : "تم الحفظ كتصميم جديد",
    });

    return serializeOrder(statements.getOrderById.get(orderId));
  }

  function listOrders(userId) {
    return statements.listOrdersForUser.all(userId).map(serializeOrder);
  }

  function getOrder(userId, orderId) {
    const row = statements.getOrderForUser.get(orderId, userId);
    if (!row) throw createHttpError(404, "الطلب غير موجود.");
    return {
      ...serializeOrder(row),
      status_history: statements.listHistory.all(row.id),
    };
  }

  function submitOrder(userId, orderId) {
    const row = statements.getOrderForUser.get(orderId, userId);
    if (!row) throw createHttpError(404, "الطلب غير موجود.");
    if (row.status !== ORDER_STATUS.NEW) {
      throw createHttpError(409, "يمكن إرسال الطلبات الجديدة فقط.");
    }

    const updatedAt = nowIso();
    statements.updateOrderStatus.run(ORDER_STATUS.SUBMITTED, updatedAt, updatedAt, row.id);
    addHistory({ orderId: row.id, status: ORDER_STATUS.SUBMITTED, userId, actorType: "client", note: "تم الإرسال" });
    return getOrder(userId, row.id);
  }

  function deleteOrder(userId, orderId) {
    const row = statements.getOrderForUser.get(orderId, userId);
    if (!row) throw createHttpError(404, "الطلب غير موجود.");
    if (row.status !== ORDER_STATUS.NEW) {
      throw createHttpError(409, "يمكن حذف الطلبات الجديدة فقط.");
    }

    statements.deleteOrder.run(row.id);
    return { deleted: true, order_id: row.id, order_number: row.order_number };
  }

  function addFeedback(userId, orderId, feedback) {
    const row = statements.getOrderForUser.get(orderId, userId);
    if (!row) throw createHttpError(404, "الطلب غير موجود.");
    if (row.status !== ORDER_STATUS.DELIVERED) {
      throw createHttpError(409, "يمكن إضافة الملاحظات بعد التسليم فقط.");
    }

    const feedbackText = safeText(feedback, "", 2000);
    if (!feedbackText) throw createHttpError(400, "نص الملاحظات مطلوب.");

    const updatedAt = nowIso();
    statements.updateFeedback.run(ORDER_STATUS.CLIENT_FEEDBACK, feedbackText, updatedAt, row.id);
    addHistory({
      orderId: row.id,
      status: ORDER_STATUS.CLIENT_FEEDBACK,
      userId,
      actorType: "client",
      note: "ملاحظات العميل",
    });
    return getOrder(userId, row.id);
  }

  function listAdminOrders() {
    return statements.listAdminOrders.all().map((row) => ({
      ...serializeOrder(row),
      user_name: row.user_name,
      user_email: row.user_email,
    }));
  }

  function updateAdminStatus(orderId, status, adminUserId = null) {
    const requestedStatus = Number(status);
    if (!ADMIN_STATUSES.has(requestedStatus)) {
      throw createHttpError(400, "حالة الإدارة يجب أن تكون تم الإرسال، استلمته FRAMEANA، منتهي، أو تم التسليم.");
    }

    const row = statements.getOrderById.get(orderId);
    if (!row) throw createHttpError(404, "الطلب غير موجود.");
    if (row.status === ORDER_STATUS.NEW) {
      throw createHttpError(409, "يجب أن يرسل العميل الطلب الجديد قبل معالجة الإدارة.");
    }
    if (row.status === ORDER_STATUS.CLIENT_FEEDBACK) {
      throw createHttpError(409, "لا يمكن للإدارة تغيير طلبات ملاحظات العميل.");
    }

    const updatedAt = nowIso();
    statements.updateOrderStatus.run(requestedStatus, updatedAt, updatedAt, row.id);
    addHistory({
      orderId: row.id,
      status: requestedStatus,
      userId: adminUserId,
      actorType: "admin",
      note: "تحديث حالة FRAMEANA",
    });

    return serializeOrder(statements.getOrderById.get(row.id));
  }

  return {
    dbPath,
    registerUser,
    loginUser,
    getUserByToken,
    createOrder,
    listOrders,
    getOrder,
    submitOrder,
    deleteOrder,
    addFeedback,
    listAdminOrders,
    updateAdminStatus,
  };
}

module.exports = {
  ORDER_STATUS,
  ORDER_STATUS_LABELS,
  createHttpError,
  createStage8Store,
};
