"use strict";

const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const { pathToFileURL } = require("url");

const REQUIRED_OUTPUTS = [
  "frame_metadata.json",
  "frame_front.stl",
  "left_arm.stl",
  "right_arm.stl",
  "full_frame.stl",
];

const FRAME_PREVIEW_CANDIDATES = [
  "frame_preview.png",
  "frame_preview.jpg",
  "preview.png",
  "product_preview.png",
  "frameana_image2stl_3d_preview.png",
];
const DEFAULT_STAGE_2C4_FRONT_CROP = "55,105,1145,500";
const DEFAULT_STAGE_2C4_SIDE_CROP = "230,735,955,365";

function fileExists(filePath) {
  try {
    return fs.statSync(filePath).isFile();
  } catch {
    return false;
  }
}

function firstExistingPath(paths) {
  return paths.find((candidate) => candidate && fileExists(candidate)) || null;
}

function styleEnvName(style) {
  return `FRAMEANA_REFERENCE_IMAGE_${String(style || "classic")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "_")}`;
}

function resolveReferenceImagePath(job) {
  const backendDir = path.dirname(job.generatorPath);
  const srcDir = path.resolve(backendDir, "..");
  const style = job.style || "classic";
  const styleSpecificEnv = process.env[styleEnvName(style)];

  const candidates = [
    job.referenceImagePath,
    styleSpecificEnv,
    path.join(backendDir, "references", `${style}.png`),
    path.join(backendDir, "references", "frame_reference_2d.png"),
    process.env.FRAMEANA_REFERENCE_IMAGE_PATH,
    path.join(backendDir, "references", "parts.png"),
    path.join(srcDir, "assets", `frame_reference_${style}.png`),
    path.join(srcDir, "assets", "frame_reference_2d.png"),
    path.join(srcDir, "assets", "frame_reference.png"),
    path.join(srcDir, "parts.png"),
    path.join(srcDir, "CHATGPT.png"),
    path.join(srcDir, "CHATGPT - Copy.png"),
  ];

  const referenceImagePath = firstExistingPath(candidates.map((candidate) => {
    if (!candidate) return null;
    return path.resolve(String(candidate));
  }));

  if (!referenceImagePath) {
    throw new Error(
      `No frame reference PNG was found. Set ${styleEnvName(style)} or FRAMEANA_REFERENCE_IMAGE_PATH to a 2D frame reference image.`
    );
  }

  return referenceImagePath;
}

function runCommand(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: { ...process.env, ...(options.env || {}) },
      shell: false,
      windowsHide: true,
    });

    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk) => {
      stdout += chunk.toString();
    });

    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });

    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve({ stdout, stderr, code });
        return;
      }

      const error = new Error(
        `Generator exited with code ${code}.\n${stderr || stdout || "No generator output."}`
      );
      error.code = code;
      error.stdout = stdout;
      error.stderr = stderr;
      reject(error);
    });
  });
}

function buildStandardCliArgs(job) {
  const referenceImagePath = resolveReferenceImagePath(job);
  const frontCrop = job.frontCrop || process.env.FRAMEANA_FRONT_CROP || DEFAULT_STAGE_2C4_FRONT_CROP;
  const sideCrop = job.sideCrop || process.env.FRAMEANA_SIDE_CROP || DEFAULT_STAGE_2C4_SIDE_CROP;

  return [
    job.generatorPath,
    "--reference-image",
    referenceImagePath,
    "--customer-image",
    job.inputImagePath,
    "--output-dir",
    job.outputDir,
    "--front-crop",
    frontCrop,
    "--side-crop",
    sideCrop,
    "--config",
    job.configPath,
    "--style",
    job.style,
    "--frame-shape",
    job.style,
    "--material",
    job.material,
    "--frame-color",
    job.frameColor,
    "--arm-text",
    job.engraving,
    "--engraving",
    job.engraving,
    "--arm-text-color",
    job.engravingColor,
    "--engraving-color",
    job.engravingColor,
  ];
}

async function runAsModule(job) {
  const moduleUrl = `${pathToFileURL(job.generatorPath).href}?stage2c6=${Date.now()}`;
  const imported = await import(moduleUrl);
  const generate =
    imported.generateFrameFromImage ||
    imported.generateFrame ||
    imported.generate ||
    imported.default;

  if (typeof generate !== "function") {
    throw new Error(
      "Module mode requires the generator to export generateFrameFromImage(), generateFrame(), generate(), or default function."
    );
  }

  await generate({
    inputImagePath: job.inputImagePath,
    referenceImagePath: resolveReferenceImagePath(job),
    outputDir: job.outputDir,
    configPath: job.configPath,
    style: job.style,
    material: job.material,
    frameColor: job.frameColor,
    engraving: job.engraving,
    engravingColor: job.engravingColor,
  });
}

async function runAsCli(job) {
  const args = buildStandardCliArgs(job);
  return runCommand(process.execPath, args, {
    cwd: path.dirname(job.generatorPath),
    env: {
      FRAMEANA_INPUT_IMAGE: job.inputImagePath,
      FRAMEANA_REFERENCE_IMAGE: resolveReferenceImagePath(job),
      FRAMEANA_OUTPUT_DIR: job.outputDir,
      FRAMEANA_CONFIG_PATH: job.configPath,
      FRAMEANA_FRONT_CROP: job.frontCrop || process.env.FRAMEANA_FRONT_CROP || DEFAULT_STAGE_2C4_FRONT_CROP,
      FRAMEANA_SIDE_CROP: job.sideCrop || process.env.FRAMEANA_SIDE_CROP || DEFAULT_STAGE_2C4_SIDE_CROP,
      FRAMEANA_STYLE: job.style,
      FRAMEANA_MATERIAL: job.material,
      FRAMEANA_FRAME_COLOR: job.frameColor,
      FRAMEANA_ENGRAVING: job.engraving,
      FRAMEANA_ENGRAVING_COLOR: job.engravingColor,
    },
  });
}

function copyIfMissing(sourcePath, destinationPath) {
  if (!sourcePath || fileExists(destinationPath)) return;
  fs.copyFileSync(sourcePath, destinationPath);
}

function normalizeOutputAliases(outputDir) {
  const framePreview = firstExistingPath(
    FRAME_PREVIEW_CANDIDATES.map((name) => path.join(outputDir, name))
  );

  if (framePreview && path.extname(framePreview).toLowerCase() === ".png") {
    copyIfMissing(framePreview, path.join(outputDir, "frame_preview.png"));
  }
}

function verifyRequiredOutputs(outputDir) {
  const missing = REQUIRED_OUTPUTS.filter((name) => !fileExists(path.join(outputDir, name)));
  if (missing.length > 0) {
    throw new Error(
      `The generator finished, but these required files were not found in ${outputDir}: ${missing.join(
        ", "
      )}`
    );
  }
}

/**
 * Central adapter for frameana_image2stl_generator.js.
 *
 * Supported modes:
 * - cli (default): invokes the generator with standardized --input/--output-dir arguments.
 * - module: imports the generator and calls an exported generation function.
 *
 * Set FRAMEANA_GENERATOR_MODE=module only if the generator exports a callable function.
 */
async function runFrameGenerator(job) {
  if (!fileExists(job.generatorPath)) {
    throw new Error(`Generator file not found: ${job.generatorPath}`);
  }

  fs.mkdirSync(job.outputDir, { recursive: true });

  const mode = (process.env.FRAMEANA_GENERATOR_MODE || "cli").toLowerCase();
  if (mode === "module") {
    await runAsModule(job);
  } else {
    await runAsCli(job);
  }

  normalizeOutputAliases(job.outputDir);
  verifyRequiredOutputs(job.outputDir);
}

module.exports = {
  REQUIRED_OUTPUTS,
  resolveReferenceImagePath,
  runFrameGenerator,
  verifyRequiredOutputs,
};
