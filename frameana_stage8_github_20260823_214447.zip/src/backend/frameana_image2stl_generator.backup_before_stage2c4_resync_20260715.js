#!/usr/bin/env node
"use strict";

/*
FRAMEANA Stage 2C-4/2C-5 - 2D reference image to STL

This generator treats the accepted 2D CAD reference image as the geometry source:
- top/front view -> frame_front.stl
- middle side view -> temple arms
- metadata keeps color/material/frontend provenance because STL is geometry only

No npm dependencies.
*/

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const DEFAULT_STYLE = {
  frame_color: "tortoise",
  material: "acetate",
  frame_shape: "round",
  arm_text: "Nael",
  arm_text_color: "gold",
  text_mode: "emboss",
};

const STYLE_ALIASES = {
  style: "frame_shape",
  engraving: "arm_text",
  engraving_text: "arm_text",
  engraving_color: "arm_text_color",
};

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith("--")) continue;
    const key = token.slice(2).replace(/-/g, "_");
    const next = argv[i + 1];
    if (next === undefined || next.startsWith("--")) {
      args[key] = true;
    } else {
      args[key] = next;
      i += 1;
    }
  }
  return args;
}

function safeFloat(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function safeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n) : fallback;
}

function clamp(value, minValue, maxValue) {
  return Math.max(minValue, Math.min(maxValue, value));
}

function roundValue(value, digits = 4) {
  if (typeof value === "number") return Number(value.toFixed(digits));
  if (Array.isArray(value)) return value.map((item) => roundValue(item, digits));
  if (value && typeof value === "object") {
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = roundValue(item, digits);
    return out;
  }
  return value;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function readJsonIfExists(filePath) {
  if (!filePath) return {};
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return {};
  }
}

function normalizeStyleOptions(args) {
  const config = readJsonIfExists(args.config ? path.resolve(String(args.config)) : null);
  const style = { ...DEFAULT_STYLE };

  for (const [source, target] of Object.entries(STYLE_ALIASES)) {
    const value = config[source];
    if (value !== undefined && value !== null && value !== "") style[target] = String(value);
  }

  for (const key of Object.keys(style)) {
    const value = config[key];
    if (value !== undefined && value !== null && value !== "") style[key] = String(value);
  }

  for (const [source, target] of Object.entries(STYLE_ALIASES)) {
    const value = args[source];
    if (value !== undefined && value !== true) style[target] = String(value);
  }

  for (const key of Object.keys(style)) {
    if (args[key] !== undefined && args[key] !== true) style[key] = String(args[key]);
  }

  return style;
}

function fmt(n) {
  return Number.isFinite(n) ? n.toFixed(6).replace(/\.?0+$/, "") : "0";
}

function parseCrop(text, image, fallback) {
  const source = text || fallback;
  const parts = String(source)
    .split(",")
    .map((part) => safeInt(part.trim(), 0));
  if (parts.length !== 4) {
    throw new Error(`Invalid crop "${source}". Expected x,y,width,height.`);
  }
  const x = clamp(parts[0], 0, image.width - 1);
  const y = clamp(parts[1], 0, image.height - 1);
  return {
    x,
    y,
    width: clamp(parts[2], 1, image.width - x),
    height: clamp(parts[3], 1, image.height - y),
  };
}

function paethPredictor(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  return pb <= pc ? b : c;
}

function decodePng(filePath) {
  const buffer = fs.readFileSync(filePath);
  if (buffer.length < 8 || buffer.toString("ascii", 1, 4) !== "PNG") {
    throw new Error(`Not a PNG file: ${filePath}`);
  }

  let offset = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idatParts = [];

  while (offset < buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.toString("ascii", offset + 4, offset + 8);
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    const data = buffer.subarray(dataStart, dataEnd);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") {
      idatParts.push(data);
    } else if (type === "IEND") {
      break;
    }
    offset = dataEnd + 4;
  }

  if (bitDepth !== 8) throw new Error(`Unsupported PNG bit depth ${bitDepth}; expected 8-bit PNG.`);
  const channelsByColorType = { 0: 1, 2: 3, 4: 2, 6: 4 };
  const channels = channelsByColorType[colorType];
  if (!channels) throw new Error(`Unsupported PNG color type ${colorType}; use RGB/RGBA PNG.`);

  const raw = zlib.inflateSync(Buffer.concat(idatParts));
  const rgba = Buffer.alloc(width * height * 4);
  const stride = width * channels;
  let rawOffset = 0;
  let prev = Buffer.alloc(stride);

  for (let y = 0; y < height; y += 1) {
    const filter = raw[rawOffset];
    rawOffset += 1;
    const row = Buffer.from(raw.subarray(rawOffset, rawOffset + stride));
    rawOffset += stride;
    for (let x = 0; x < stride; x += 1) {
      const left = x >= channels ? row[x - channels] : 0;
      const up = prev[x] || 0;
      const upLeft = x >= channels ? prev[x - channels] || 0 : 0;
      if (filter === 1) row[x] = (row[x] + left) & 255;
      else if (filter === 2) row[x] = (row[x] + up) & 255;
      else if (filter === 3) row[x] = (row[x] + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) row[x] = (row[x] + paethPredictor(left, up, upLeft)) & 255;
      else if (filter !== 0) throw new Error(`Unsupported PNG filter ${filter}`);
    }
    for (let x = 0; x < width; x += 1) {
      const src = x * channels;
      const dst = (y * width + x) * 4;
      if (colorType === 0) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src];
        rgba[dst + 2] = row[src];
        rgba[dst + 3] = 255;
      } else if (colorType === 2) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src + 1];
        rgba[dst + 2] = row[src + 2];
        rgba[dst + 3] = 255;
      } else if (colorType === 4) {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src];
        rgba[dst + 2] = row[src];
        rgba[dst + 3] = row[src + 1];
      } else {
        rgba[dst] = row[src];
        rgba[dst + 1] = row[src + 1];
        rgba[dst + 2] = row[src + 2];
        rgba[dst + 3] = row[src + 3];
      }
    }
    prev = row;
  }

  return { width, height, rgba };
}

function pixelAt(image, x, y) {
  const px = clamp(Math.round(x), 0, image.width - 1);
  const py = clamp(Math.round(y), 0, image.height - 1);
  const i = (py * image.width + px) * 4;
  return [image.rgba[i], image.rgba[i + 1], image.rgba[i + 2], image.rgba[i + 3]];
}

function colorStats(pixel) {
  const [r, g, b, a] = pixel;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  const sat = max === 0 ? 0 : (max - min) / max;
  return { r, g, b, a, lum, sat };
}

function estimateBackground(image, crop) {
  const points = [];
  const step = 16;
  for (let x = crop.x; x < crop.x + crop.width; x += step) {
    points.push([x, crop.y + 2], [x, crop.y + crop.height - 3]);
  }
  for (let y = crop.y; y < crop.y + crop.height; y += step) {
    points.push([crop.x + 2, y], [crop.x + crop.width - 3, y]);
  }
  const light = points
    .map(([x, y]) => pixelAt(image, x, y))
    .sort((a, b) => colorStats(b).lum - colorStats(a).lum)
    .slice(0, Math.max(4, Math.floor(points.length * 0.35)));
  const bg = [0, 0, 0, 0];
  for (const p of light) {
    for (let i = 0; i < 4; i += 1) bg[i] += p[i] / light.length;
  }
  return bg;
}

function isForegroundPixel(pixel, background, options) {
  const p = colorStats(pixel);
  const bg = colorStats(background);
  const dr = p.r - bg.r;
  const dg = p.g - bg.g;
  const db = p.b - bg.b;
  const d = Math.sqrt(dr * dr + dg * dg + db * db);
  const isWarmAcetate = p.r > p.b + 14 && p.g > p.b + 4 && p.sat > 0.07 && p.lum < 238;
  const isDark = p.lum < options.luminanceMax;
  return p.a > 18 && d >= options.threshold && (isDark || isWarmAcetate || p.sat >= options.saturationMin);
}

function buildMaskFromCrop(image, crop, options) {
  const width = Math.max(80, Math.round(options.gridWidth));
  const height = Math.max(24, Math.round((crop.height / crop.width) * width));
  const background = estimateBackground(image, crop);
  const mask = new Uint8Array(width * height);
  const samples = options.samples || 3;
  const minHits = options.minHits || Math.ceil((samples * samples) * 0.3);
  let hitsTotal = 0;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      let hits = 0;
      for (let sy = 0; sy < samples; sy += 1) {
        for (let sx = 0; sx < samples; sx += 1) {
          const px = crop.x + ((x + (sx + 0.5) / samples) / width) * crop.width;
          const py = crop.y + ((y + (sy + 0.5) / samples) / height) * crop.height;
          if (isForegroundPixel(pixelAt(image, px, py), background, options)) hits += 1;
        }
      }
      if (hits >= minHits) {
        mask[y * width + x] = 1;
        hitsTotal += 1;
      }
    }
  }

  return { mask, width, height, crop, background_rgba: roundValue(background, 2), foreground_pixels_raw: hitsTotal };
}

function countNeighbors(mask, width, height, x, y) {
  let count = 0;
  for (let dy = -1; dy <= 1; dy += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
      if (mask[ny * width + nx]) count += 1;
    }
  }
  return count;
}

function majoritySmooth(mask, width, height) {
  const out = new Uint8Array(mask.length);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const index = y * width + x;
      const count = countNeighbors(mask, width, height, x, y);
      if (mask[index]) out[index] = count >= 3 ? 1 : 0;
      else out[index] = count >= 6 ? 1 : 0;
    }
  }
  return out;
}

function componentFilter(mask, width, height, options) {
  const visited = new Uint8Array(mask.length);
  const components = [];
  const stack = [];

  for (let start = 0; start < mask.length; start += 1) {
    if (!mask[start] || visited[start]) continue;
    const component = [];
    stack.push(start);
    visited[start] = 1;
    while (stack.length) {
      const index = stack.pop();
      component.push(index);
      const x = index % width;
      const y = Math.floor(index / width);
      const neighbors = [
        [x - 1, y],
        [x + 1, y],
        [x, y - 1],
        [x, y + 1],
        [x - 1, y - 1],
        [x + 1, y - 1],
        [x - 1, y + 1],
        [x + 1, y + 1],
      ];
      for (const [nx, ny] of neighbors) {
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        const next = ny * width + nx;
        if (mask[next] && !visited[next]) {
          visited[next] = 1;
          stack.push(next);
        }
      }
    }
    components.push(component);
  }

  components.sort((a, b) => b.length - a.length);
  const out = new Uint8Array(mask.length);
  let kept = 0;
  const minPixels = options.minPixels || 20;
  for (let i = 0; i < components.length; i += 1) {
    const component = components[i];
    if (options.keepLargestOnly && i > 0) continue;
    if (component.length < minPixels) continue;
    kept += 1;
    for (const index of component) out[index] = 1;
  }
  return { mask: out, components_total: components.length, components_kept: kept, largest_component_pixels: components[0] ? components[0].length : 0 };
}

function maskBounds(mask, width, height) {
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  let count = 0;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      count += 1;
      minX = Math.min(minX, x);
      minY = Math.min(minY, y);
      maxX = Math.max(maxX, x);
      maxY = Math.max(maxY, y);
    }
  }
  if (!count) return null;
  return { minX, minY, maxX, maxY, width: maxX - minX + 1, height: maxY - minY + 1, pixels: count };
}

function trimMask(mask, width, height, padding = 2) {
  const bounds = maskBounds(mask, width, height);
  if (!bounds) throw new Error("No foreground pixels found after cleanup.");
  const minX = Math.max(0, bounds.minX - padding);
  const minY = Math.max(0, bounds.minY - padding);
  const maxX = Math.min(width - 1, bounds.maxX + padding);
  const maxY = Math.min(height - 1, bounds.maxY + padding);
  const outWidth = maxX - minX + 1;
  const outHeight = maxY - minY + 1;
  const out = new Uint8Array(outWidth * outHeight);
  for (let y = 0; y < outHeight; y += 1) {
    for (let x = 0; x < outWidth; x += 1) {
      out[y * outWidth + x] = mask[(minY + y) * width + (minX + x)];
    }
  }
  return { mask: out, width: outWidth, height: outHeight, bounds_px: { min_x: minX, min_y: minY, max_x: maxX, max_y: maxY } };
}

function finalizeTrace(rawTrace, options) {
  let mask = rawTrace.mask;
  for (let i = 0; i < (options.smoothIterations || 1); i += 1) {
    mask = majoritySmooth(mask, rawTrace.width, rawTrace.height);
  }
  const filtered = componentFilter(mask, rawTrace.width, rawTrace.height, {
    minPixels: options.minPixels,
    keepLargestOnly: options.keepLargestOnly,
  });
  const trimmed = trimMask(filtered.mask, rawTrace.width, rawTrace.height, options.padding || 2);
  const bounds = maskBounds(trimmed.mask, trimmed.width, trimmed.height);
  return {
    ...trimmed,
    crop: rawTrace.crop,
    source_grid_px: { width: rawTrace.width, height: rawTrace.height },
    background_rgba: rawTrace.background_rgba,
    foreground_pixels_raw: rawTrace.foreground_pixels_raw,
    foreground_pixels_final: bounds ? bounds.pixels : 0,
    components_total: filtered.components_total,
    components_kept: filtered.components_kept,
    largest_component_pixels: filtered.largest_component_pixels,
  };
}

function traceSummary(trace) {
  return {
    crop_px: trace.crop,
    source_grid_px: trace.source_grid_px,
    trace_grid_px: { width: trace.width, height: trace.height },
    bounds_px: trace.bounds_px,
    background_rgba: trace.background_rgba,
    foreground_pixels_raw: trace.foreground_pixels_raw,
    foreground_pixels_final: trace.foreground_pixels_final,
    components_total: trace.components_total,
    components_kept: trace.components_kept,
    largest_component_pixels: trace.largest_component_pixels,
  };
}

class Mesh {
  constructor(name) {
    this.name = name;
    this.triangles = [];
  }
  addTriangle(a, b, c, material = "acetate") {
    this.triangles.push({ a, b, c, material });
  }
  addQuad(a, b, c, d, material = "acetate") {
    this.addTriangle(a, b, c, material);
    this.addTriangle(a, c, d, material);
  }
  merge(other) {
    this.triangles.push(...other.triangles);
  }
  bounds() {
    const min = [Infinity, Infinity, Infinity];
    const max = [-Infinity, -Infinity, -Infinity];
    for (const tri of this.triangles) {
      for (const p of [tri.a, tri.b, tri.c]) {
        for (let i = 0; i < 3; i += 1) {
          min[i] = Math.min(min[i], p[i]);
          max[i] = Math.max(max[i], p[i]);
        }
      }
    }
    return { min, max, size: [max[0] - min[0], max[1] - min[1], max[2] - min[2]] };
  }
}

function normal(a, b, c) {
  const ux = b[0] - a[0];
  const uy = b[1] - a[1];
  const uz = b[2] - a[2];
  const vx = c[0] - a[0];
  const vy = c[1] - a[1];
  const vz = c[2] - a[2];
  const nx = uy * vz - uz * vy;
  const ny = uz * vx - ux * vz;
  const nz = ux * vy - uy * vx;
  const len = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
  return [nx / len, ny / len, nz / len];
}

function writeAsciiStl(mesh, filePath) {
  const lines = [`solid ${mesh.name}`];
  for (const tri of mesh.triangles) {
    const n = normal(tri.a, tri.b, tri.c);
    lines.push(`  facet normal ${fmt(n[0])} ${fmt(n[1])} ${fmt(n[2])}`);
    lines.push("    outer loop");
    for (const p of [tri.a, tri.b, tri.c]) lines.push(`      vertex ${fmt(p[0])} ${fmt(p[1])} ${fmt(p[2])}`);
    lines.push("    endloop");
    lines.push("  endfacet");
  }
  lines.push(`endsolid ${mesh.name}`);
  fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeBinaryStl(mesh, filePath) {
  const header = Buffer.alloc(80, 0);
  header.write(`FRAMEANA ${mesh.name}`.slice(0, 79), 0, "ascii");
  const count = Buffer.alloc(4);
  count.writeUInt32LE(mesh.triangles.length, 0);
  const body = Buffer.alloc(mesh.triangles.length * 50);
  let offset = 0;
  for (const tri of mesh.triangles) {
    const n = normal(tri.a, tri.b, tri.c);
    for (const value of [...n, ...tri.a, ...tri.b, ...tri.c]) {
      body.writeFloatLE(Number.isFinite(value) ? value : 0, offset);
      offset += 4;
    }
    body.writeUInt16LE(0, offset);
    offset += 2;
  }
  fs.writeFileSync(filePath, Buffer.concat([header, count, body]));
}

function at(mask, width, height, x, y) {
  return x >= 0 && y >= 0 && x < width && y < height && mask[y * width + x];
}

function addRasterExtrusionXY(mesh, trace, targetWidthMm, depthMm, material) {
  const { mask, width, height } = trace;
  const cell = targetWidthMm / width;
  const zFront = depthMm / 2;
  const zBack = -depthMm / 2;

  for (let y = 0; y < height; y += 1) {
    let start = -1;
    for (let x = 0; x <= width; x += 1) {
      const on = x < width && mask[y * width + x];
      if (on && start < 0) {
        start = x;
      } else if (!on && start >= 0) {
        const x0 = (start - width / 2) * cell;
        const x1 = (x - width / 2) * cell;
        const yTop = (height / 2 - y) * cell;
        const yBottom = yTop - cell;
        mesh.addQuad([x0, yBottom, zFront], [x1, yBottom, zFront], [x1, yTop, zFront], [x0, yTop, zFront], material);
        mesh.addQuad([x0, yBottom, zBack], [x0, yTop, zBack], [x1, yTop, zBack], [x1, yBottom, zBack], material);
        start = -1;
      }
    }
  }

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      const x0 = (x - width / 2) * cell;
      const x1 = x0 + cell;
      const yTop = (height / 2 - y) * cell;
      const yBottom = yTop - cell;
      if (!at(mask, width, height, x - 1, y)) {
        mesh.addQuad([x0, yBottom, zBack], [x0, yBottom, zFront], [x0, yTop, zFront], [x0, yTop, zBack], material);
      }
      if (!at(mask, width, height, x + 1, y)) {
        mesh.addQuad([x1, yBottom, zBack], [x1, yTop, zBack], [x1, yTop, zFront], [x1, yBottom, zFront], material);
      }
      if (!at(mask, width, height, x, y - 1)) {
        mesh.addQuad([x0, yTop, zBack], [x0, yTop, zFront], [x1, yTop, zFront], [x1, yTop, zBack], material);
      }
      if (!at(mask, width, height, x, y + 1)) {
        mesh.addQuad([x0, yBottom, zBack], [x1, yBottom, zBack], [x1, yBottom, zFront], [x0, yBottom, zFront], material);
      }
    }
  }

  return { cell_mm: cell, target_width_mm: targetWidthMm, target_height_mm: height * cell, depth_mm: depthMm };
}

function addRasterExtrusionYZ(mesh, trace, options) {
  const { mask, width, height } = trace;
  const cell = options.targetLengthMm / width;
  const xCenter = options.xCenter;
  const side = options.side;
  const thickness = options.thicknessMm;
  const xOuter = xCenter + side * thickness / 2;
  const xInner = xCenter - side * thickness / 2;
  const zStart = options.zStart;
  const yOffset = options.yOffset || 0;
  const material = options.material || "acetate";

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (!mask[y * width + x]) continue;
      const z0 = zStart - x * cell;
      const z1 = z0 - cell;
      const yTop = yOffset + (height / 2 - y) * cell;
      const yBottom = yTop - cell;

      mesh.addQuad([xOuter, yBottom, z1], [xOuter, yBottom, z0], [xOuter, yTop, z0], [xOuter, yTop, z1], material);
      mesh.addQuad([xInner, yBottom, z1], [xInner, yTop, z1], [xInner, yTop, z0], [xInner, yBottom, z0], material);

      if (!at(mask, width, height, x - 1, y)) {
        mesh.addQuad([xInner, yBottom, z0], [xInner, yTop, z0], [xOuter, yTop, z0], [xOuter, yBottom, z0], material);
      }
      if (!at(mask, width, height, x + 1, y)) {
        mesh.addQuad([xInner, yBottom, z1], [xOuter, yBottom, z1], [xOuter, yTop, z1], [xInner, yTop, z1], material);
      }
      if (!at(mask, width, height, x, y - 1)) {
        mesh.addQuad([xInner, yTop, z1], [xOuter, yTop, z1], [xOuter, yTop, z0], [xInner, yTop, z0], material);
      }
      if (!at(mask, width, height, x, y + 1)) {
        mesh.addQuad([xInner, yBottom, z1], [xInner, yBottom, z0], [xOuter, yBottom, z0], [xOuter, yBottom, z1], material);
      }
    }
  }

  return {
    cell_mm: cell,
    target_length_mm: options.targetLengthMm,
    target_height_mm: height * cell,
    thickness_mm: thickness,
    x_center_mm: xCenter,
    y_offset_mm: yOffset,
    z_start_mm: zStart,
    side,
  };
}

function addCylinderZ(mesh, cx, cy, cz, radius, depth, segments, material) {
  const z0 = cz - depth / 2;
  const z1 = cz + depth / 2;
  const top = [cx, cy, z1];
  const bottom = [cx, cy, z0];
  for (let i = 0; i < segments; i += 1) {
    const t0 = Math.PI * 2 * i / segments;
    const t1 = Math.PI * 2 * (i + 1) / segments;
    const p0b = [cx + Math.cos(t0) * radius, cy + Math.sin(t0) * radius, z0];
    const p1b = [cx + Math.cos(t1) * radius, cy + Math.sin(t1) * radius, z0];
    const p0t = [p0b[0], p0b[1], z1];
    const p1t = [p1b[0], p1b[1], z1];
    mesh.addTriangle(top, p0t, p1t, material);
    mesh.addTriangle(bottom, p1b, p0b, material);
    mesh.addQuad(p0b, p1b, p1t, p0t, material);
  }
}

function addBox(mesh, cx, cy, cz, sx, sy, sz, material = "acetate") {
  const x0 = cx - sx / 2;
  const x1 = cx + sx / 2;
  const y0 = cy - sy / 2;
  const y1 = cy + sy / 2;
  const z0 = cz - sz / 2;
  const z1 = cz + sz / 2;
  const p000 = [x0, y0, z0];
  const p100 = [x1, y0, z0];
  const p110 = [x1, y1, z0];
  const p010 = [x0, y1, z0];
  const p001 = [x0, y0, z1];
  const p101 = [x1, y0, z1];
  const p111 = [x1, y1, z1];
  const p011 = [x0, y1, z1];
  mesh.addQuad(p001, p101, p111, p011, material);
  mesh.addQuad(p000, p010, p110, p100, material);
  mesh.addQuad(p000, p001, p011, p010, material);
  mesh.addQuad(p100, p110, p111, p101, material);
  mesh.addQuad(p010, p011, p111, p110, material);
  mesh.addQuad(p000, p100, p101, p001, material);
}

function polygonArea(points) {
  let area = 0;
  for (let i = 0; i < points.length; i += 1) {
    const j = (i + 1) % points.length;
    area += points[i][0] * points[j][1] - points[j][0] * points[i][1];
  }
  return area / 2;
}

function addExtrudedPolygonXY(mesh, points, depth, zCenter, material = "acetate") {
  const pts = polygonArea(points) >= 0 ? points : points.slice().reverse();
  const zFront = zCenter + depth / 2;
  const zBack = zCenter - depth / 2;
  const center = pts.reduce((acc, p) => [acc[0] + p[0] / pts.length, acc[1] + p[1] / pts.length], [0, 0]);
  const cf = [center[0], center[1], zFront];
  const cb = [center[0], center[1], zBack];
  for (let i = 0; i < pts.length; i += 1) {
    const j = (i + 1) % pts.length;
    const p0f = [pts[i][0], pts[i][1], zFront];
    const p1f = [pts[j][0], pts[j][1], zFront];
    const p0b = [pts[i][0], pts[i][1], zBack];
    const p1b = [pts[j][0], pts[j][1], zBack];
    mesh.addTriangle(cf, p0f, p1f, material);
    mesh.addTriangle(cb, p1b, p0b, material);
    mesh.addQuad(p0b, p1b, p1f, p0f, material);
  }
}

function addFrontRivets(mesh, frontBounds, depthMm) {
  const radius = 1.15;
  const y = frontBounds.min[1] + frontBounds.size[1] * 0.67;
  const z = depthMm / 2 + 0.24;
  const leftBase = frontBounds.min[0] + frontBounds.size[0] * 0.058;
  const rightBase = frontBounds.max[0] - frontBounds.size[0] * 0.058;
  for (const x of [leftBase, leftBase + 3.0, rightBase - 3.0, rightBase]) {
    addCylinderZ(mesh, x, y, z, radius, 0.48, 30, "gold");
  }
}

function addNoseBridgeCompletion(mesh, frontDepthMm) {
  const depth = frontDepthMm * 0.72;
  const zCenter = 0.16;
  const bridge = [
    [-9.6, 2.25],
    [-7.4, 4.65],
    [-2.8, 5.05],
    [2.8, 5.05],
    [7.4, 4.65],
    [9.6, 2.25],
    [8.25, 1.35],
    [3.9, 2.05],
    [0, 2.15],
    [-3.9, 2.05],
    [-8.25, 1.35],
  ];
  addExtrudedPolygonXY(mesh, bridge, depth, zCenter, "acetate");

  const sideTab = [
    [-12.35, -0.45],
    [-10.95, 0.1],
    [-10.95, 5.55],
    [-12.35, 4.85],
  ];
  addExtrudedPolygonXY(mesh, sideTab, depth * 0.96, zCenter, "acetate");
  addExtrudedPolygonXY(
    mesh,
    sideTab.map(([x, y]) => [-x, y]),
    depth * 0.96,
    zCenter,
    "acetate",
  );

  return {
    method: "front_bridge_completion_from_2d_reference",
    depth_mm: depth,
    z_center_mm: zCenter,
    bridge_width_mm: 19.2,
    bridge_height_mm: 5.5,
  };
}

function addArmHingeConnector(mesh, side, frontBounds, frontDepthMm, armThicknessMm) {
  const xOuter = side > 0 ? frontBounds.max[0] - 1.0 : frontBounds.min[0] + 1.0;
  const yCenter = frontBounds.min[1] + frontBounds.size[1] * 0.61;
  const zCenter = -frontDepthMm / 2 - 1.45;
  const hinge = {
    x_center_mm: xOuter,
    y_center_mm: yCenter,
    z_center_mm: zCenter,
    size_mm: {
      x: armThicknessMm + 1.5,
      y: 10.2,
      z: frontDepthMm + 0.9,
    },
  };

  addBox(mesh, xOuter, yCenter, zCenter, hinge.size_mm.x, hinge.size_mm.y, hinge.size_mm.z, "acetate");
  return hinge;
}

function addStrokeOnXSurface(mesh, xSurface, side, p0, p1, width, relief, material) {
  const dz = p1[0] - p0[0];
  const dy = p1[1] - p0[1];
  const len = Math.sqrt(dz * dz + dy * dy) || 1;
  const nz = (-dy / len) * width / 2;
  const ny = (dz / len) * width / 2;
  const yz = [
    [p0[0] + nz, p0[1] + ny],
    [p1[0] + nz, p1[1] + ny],
    [p1[0] - nz, p1[1] - ny],
    [p0[0] - nz, p0[1] - ny],
  ];
  const x0 = xSurface;
  const x1 = xSurface + side * relief;
  const a0 = [x0, yz[0][1], yz[0][0]];
  const b0 = [x0, yz[1][1], yz[1][0]];
  const c0 = [x0, yz[2][1], yz[2][0]];
  const d0 = [x0, yz[3][1], yz[3][0]];
  const a1 = [x1, yz[0][1], yz[0][0]];
  const b1 = [x1, yz[1][1], yz[1][0]];
  const c1 = [x1, yz[2][1], yz[2][0]];
  const d1 = [x1, yz[3][1], yz[3][0]];
  mesh.addQuad(a1, b1, c1, d1, material);
  mesh.addQuad(a0, d0, c0, b0, material);
  mesh.addQuad(a0, a1, d1, d0, material);
  mesh.addQuad(b0, c0, c1, b1, material);
  mesh.addQuad(a0, b0, b1, a1, material);
  mesh.addQuad(d0, d1, c1, c0, material);
}

function addStrokeOnYSurface(mesh, ySurface, p0, p1, width, relief, material) {
  const dz = p1[0] - p0[0];
  const dx = p1[1] - p0[1];
  const len = Math.sqrt(dz * dz + dx * dx) || 1;
  const nz = (-dx / len) * width / 2;
  const nx = (dz / len) * width / 2;
  const zx = [
    [p0[0] + nz, p0[1] + nx],
    [p1[0] + nz, p1[1] + nx],
    [p1[0] - nz, p1[1] - nx],
    [p0[0] - nz, p0[1] - nx],
  ];
  const y0 = ySurface - 0.08;
  const y1 = ySurface + relief;
  const a0 = [zx[0][1], y0, zx[0][0]];
  const b0 = [zx[1][1], y0, zx[1][0]];
  const c0 = [zx[2][1], y0, zx[2][0]];
  const d0 = [zx[3][1], y0, zx[3][0]];
  const a1 = [zx[0][1], y1, zx[0][0]];
  const b1 = [zx[1][1], y1, zx[1][0]];
  const c1 = [zx[2][1], y1, zx[2][0]];
  const d1 = [zx[3][1], y1, zx[3][0]];
  mesh.addQuad(a1, b1, c1, d1, material);
  mesh.addQuad(a0, d0, c0, b0, material);
  mesh.addQuad(a0, a1, d1, d0, material);
  mesh.addQuad(b0, c0, c1, b1, material);
  mesh.addQuad(a0, b0, b1, a1, material);
  mesh.addQuad(d0, d1, c1, c0, material);
}

function addNaelEmboss(mesh, options) {
  const text = options.text || "Nael";
  if (!text || String(text).toLowerCase() === "none") return;
  const side = options.side;
  const xSurface = options.xSurface;
  const startZ = options.startZ;
  const baseY = options.baseY;
  const h = options.heightMm;
  const w = h * 0.62;
  const strokeWidth = Math.max(0.36, h * 0.085);
  const relief = options.reliefMm || 0.46;
  const strokes = [
    [0, 0, 0, 1],
    [0, 1, 0.78, 0],
    [0.78, 0, 0.78, 1],
    [1.18, 0.08, 1.74, 0.08],
    [1.74, 0.08, 1.74, 0.68],
    [1.18, 0.68, 1.74, 0.68],
    [1.18, 0.08, 1.18, 0.42],
    [1.18, 0.42, 1.74, 0.42],
    [2.09, 0.08, 2.66, 0.08],
    [2.66, 0.08, 2.66, 0.68],
    [2.09, 0.68, 2.66, 0.68],
    [2.09, 0.42, 2.66, 0.42],
    [3.02, 0, 3.02, 1],
    [3.02, 0, 3.30, 0],
  ];
  for (const st of strokes) {
    const p0 = [startZ - st[0] * w, baseY + st[1] * h];
    const p1 = [startZ - st[2] * w, baseY + st[3] * h];
    addStrokeOnXSurface(mesh, xSurface, side, p0, p1, strokeWidth, relief, "gold");
  }
}

function naelStrokePlan() {
  return [
    [0, 0, 0, 1],
    [0, 1, 0.78, 0],
    [0.78, 0, 0.78, 1],
    [1.18, 0.08, 1.74, 0.08],
    [1.74, 0.08, 1.74, 0.68],
    [1.18, 0.68, 1.74, 0.68],
    [1.18, 0.08, 1.18, 0.42],
    [1.18, 0.42, 1.74, 0.42],
    [2.09, 0.08, 2.66, 0.08],
    [2.66, 0.08, 2.66, 0.68],
    [2.09, 0.68, 2.66, 0.68],
    [2.09, 0.42, 2.66, 0.42],
    [3.02, 0, 3.02, 1],
    [3.02, 0, 3.30, 0],
  ];
}

function addNaelTopEmboss(mesh, options) {
  const text = options.text || "Nael";
  if (!text || String(text).toLowerCase() === "none") return null;
  const side = options.side;
  const topY = options.topY;
  const startZ = options.startZ;
  const baseX = options.baseX;
  const h = options.heightMm;
  const w = h * 0.62;
  const strokeWidth = Math.max(0.42, h * 0.12);
  const relief = options.reliefMm || 0.8;
  const strokes = naelStrokePlan();
  for (const st of strokes) {
    const p0 = [startZ - st[0] * w, baseX + side * st[1] * h];
    const p1 = [startZ - st[2] * w, baseX + side * st[3] * h];
    addStrokeOnYSurface(mesh, topY, p0, p1, strokeWidth, relief, "gold");
  }
  return {
    text,
    surface: "top_of_right_arm",
    start_z_mm: startZ,
    base_x_mm: baseX,
    top_y_mm: topY,
    height_mm: h,
    relief_mm: relief,
  };
}

function cloneMesh(mesh, name) {
  const out = new Mesh(name || mesh.name);
  for (const tri of mesh.triangles) {
    out.addTriangle([...tri.a], [...tri.b], [...tri.c], tri.material);
  }
  return out;
}

function mirrorMeshX(mesh, name) {
  const out = new Mesh(name);
  for (const tri of mesh.triangles) {
    out.addTriangle([-tri.a[0], tri.a[1], tri.a[2]], [-tri.c[0], tri.c[1], tri.c[2]], [-tri.b[0], tri.b[1], tri.b[2]], tri.material);
  }
  return out;
}

function writeTraceSvg(filePath, trace, color) {
  const rects = [];
  for (let y = 0; y < trace.height; y += 1) {
    let start = -1;
    for (let x = 0; x <= trace.width; x += 1) {
      const on = x < trace.width && trace.mask[y * trace.width + x];
      if (on && start < 0) start = x;
      else if (!on && start >= 0) {
        rects.push(`<rect x="${start}" y="${y}" width="${x - start}" height="1"/>`);
        start = -1;
      }
    }
  }
  const svg = [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${trace.width} ${trace.height}" width="${trace.width * 2}" height="${trace.height * 2}">`,
    `<rect width="100%" height="100%" fill="#f7f7f5"/>`,
    `<g fill="${color}">`,
    rects.join("\n"),
    `</g>`,
    `</svg>`,
  ].join("\n");
  fs.writeFileSync(filePath, `${svg}\n`, "utf8");
}

function makeCrcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
}

const CRC_TABLE = makeCrcTable();

function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBuffer = Buffer.from(type, "ascii");
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), 0);
  return Buffer.concat([length, typeBuffer, data, crc]);
}

function writePng(filePath, width, height, rgba) {
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) {
    const rowStart = y * (width * 4 + 1);
    raw[rowStart] = 0;
    rgba.copy(raw, rowStart + 1, y * width * 4, (y + 1) * width * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const signature = Buffer.from("89504e470d0a1a0a", "hex");
  fs.writeFileSync(filePath, Buffer.concat([signature, pngChunk("IHDR", ihdr), pngChunk("IDAT", zlib.deflateSync(raw)), pngChunk("IEND", Buffer.alloc(0))]));
}

function setPixel(buffer, width, height, x, y, color) {
  const px = Math.round(x);
  const py = Math.round(y);
  if (px < 0 || py < 0 || px >= width || py >= height) return;
  const i = (py * width + px) * 4;
  buffer[i] = color[0];
  buffer[i + 1] = color[1];
  buffer[i + 2] = color[2];
  buffer[i + 3] = color[3] === undefined ? 255 : color[3];
}

function fillTriangle(buffer, width, height, p0, p1, p2, color) {
  const minX = clamp(Math.floor(Math.min(p0[0], p1[0], p2[0])), 0, width - 1);
  const maxX = clamp(Math.ceil(Math.max(p0[0], p1[0], p2[0])), 0, width - 1);
  const minY = clamp(Math.floor(Math.min(p0[1], p1[1], p2[1])), 0, height - 1);
  const maxY = clamp(Math.ceil(Math.max(p0[1], p1[1], p2[1])), 0, height - 1);
  const area = (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1]);
  if (Math.abs(area) < 0.001) return;
  for (let y = minY; y <= maxY; y += 1) {
    for (let x = minX; x <= maxX; x += 1) {
      const w0 = (p1[0] - p0[0]) * (y - p0[1]) - (p1[1] - p0[1]) * (x - p0[0]);
      const w1 = (p2[0] - p1[0]) * (y - p1[1]) - (p2[1] - p1[1]) * (x - p1[0]);
      const w2 = (p0[0] - p2[0]) * (y - p2[1]) - (p0[1] - p2[1]) * (x - p2[0]);
      if ((area > 0 && w0 >= 0 && w1 >= 0 && w2 >= 0) || (area < 0 && w0 <= 0 && w1 <= 0 && w2 <= 0)) {
        setPixel(buffer, width, height, x, y, color);
      }
    }
  }
}

function transformPoint(p, rotation) {
  const cy = Math.cos(rotation.y);
  const sy = Math.sin(rotation.y);
  const cx = Math.cos(rotation.x);
  const sx = Math.sin(rotation.x);
  const x1 = p[0] * cy + p[2] * sy;
  const z1 = -p[0] * sy + p[2] * cy;
  const y2 = p[1] * cx - z1 * sx;
  const z2 = p[1] * sx + z1 * cx;
  return [x1, y2, z2];
}

function parsePreviewColor(value, fallback) {
  const named = {
    black: [22, 24, 26],
    navy: [31, 45, 87],
    blue: [42, 86, 158],
    brown: [92, 54, 30],
    tortoise: null,
    gold: [220, 174, 85],
    silver: [190, 190, 184],
    clear: [226, 231, 232],
    transparent: [226, 231, 232],
  };
  const text = String(value || "").trim().toLowerCase();
  if (Object.prototype.hasOwnProperty.call(named, text)) return named[text];

  const match = /^#?([0-9a-f]{6})$/i.exec(text);
  if (!match) return fallback;
  const hex = match[1];
  return [
    parseInt(hex.slice(0, 2), 16),
    parseInt(hex.slice(2, 4), 16),
    parseInt(hex.slice(4, 6), 16),
  ];
}

function shadeRgb(rgb, shade) {
  return [
    clamp(Math.round(rgb[0] * shade), 0, 255),
    clamp(Math.round(rgb[1] * shade), 0, 255),
    clamp(Math.round(rgb[2] * shade), 0, 255),
    255,
  ];
}

function materialColor(material, center, shade, style = DEFAULT_STYLE) {
  if (material === "gold") {
    return shadeRgb(parsePreviewColor(style.arm_text_color, [220, 174, 85]) || [220, 174, 85], shade);
  }

  const frameRgb = parsePreviewColor(style.frame_color, null);
  if (frameRgb) {
    return shadeRgb(frameRgb, shade);
  }

  const n =
    Math.sin(center[0] * 0.29 + center[2] * 0.11) +
    Math.sin(center[0] * 0.07 - center[1] * 0.33 + 1.7) +
    Math.sin(center[2] * 0.19 + 2.2);
  const warm = n > 0.65;
  const base = warm ? [112, 52, 18] : [45, 28, 20];
  const flicker = warm ? 1.08 : 0.9;
  return [
    clamp(Math.round(base[0] * shade * flicker), 0, 255),
    clamp(Math.round(base[1] * shade * flicker), 0, 255),
    clamp(Math.round(base[2] * shade * flicker), 0, 255),
    255,
  ];
}

function renderMeshPreview(mesh, filePath, style = DEFAULT_STYLE) {
  const width = 1500;
  const height = 900;
  const rgba = Buffer.alloc(width * height * 4);
  for (let i = 0; i < rgba.length; i += 4) {
    rgba[i] = 246;
    rgba[i + 1] = 246;
    rgba[i + 2] = 244;
    rgba[i + 3] = 255;
  }
  const rotation = { x: (-14 * Math.PI) / 180, y: (-28 * Math.PI) / 180 };
  const transformed = [];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const tri of mesh.triangles) {
    const pts = [tri.a, tri.b, tri.c].map((p) => transformPoint(p, rotation));
    for (const p of pts) {
      minX = Math.min(minX, p[0]);
      minY = Math.min(minY, p[1]);
      maxX = Math.max(maxX, p[0]);
      maxY = Math.max(maxY, p[1]);
    }
    const center = [
      (tri.a[0] + tri.b[0] + tri.c[0]) / 3,
      (tri.a[1] + tri.b[1] + tri.c[1]) / 3,
      (tri.a[2] + tri.b[2] + tri.c[2]) / 3,
    ];
    transformed.push({ tri, pts, center, depth: (pts[0][2] + pts[1][2] + pts[2][2]) / 3 });
  }

  const scale = Math.min((width * 0.82) / (maxX - minX || 1), (height * 0.78) / (maxY - minY || 1));
  const offsetX = width / 2 - ((minX + maxX) / 2) * scale;
  const offsetY = height / 2 + ((minY + maxY) / 2) * scale + 20;
  const light = [-0.25, -0.4, 0.88];

  transformed.sort((a, b) => a.depth - b.depth);
  for (const item of transformed) {
    const n = normal(item.pts[0], item.pts[1], item.pts[2]);
    const dot = clamp(n[0] * light[0] + n[1] * light[1] + n[2] * light[2], -1, 1);
    const shade = clamp(0.72 + dot * 0.28, 0.48, 1.08);
    const color = materialColor(item.tri.material, item.center, shade, style);
    const screen = item.pts.map((p) => [offsetX + p[0] * scale, offsetY - p[1] * scale]);
    fillTriangle(rgba, width, height, screen[0], screen[1], screen[2], color);
  }

  writePng(filePath, width, height, rgba);
}

function writeTracePng(filePath, trace, color) {
  const scale = Math.max(1, Math.floor(900 / trace.width));
  const width = trace.width * scale;
  const height = trace.height * scale;
  const rgba = Buffer.alloc(width * height * 4);
  for (let i = 0; i < rgba.length; i += 4) {
    rgba[i] = 247;
    rgba[i + 1] = 247;
    rgba[i + 2] = 245;
    rgba[i + 3] = 255;
  }
  for (let y = 0; y < trace.height; y += 1) {
    for (let x = 0; x < trace.width; x += 1) {
      if (!trace.mask[y * trace.width + x]) continue;
      for (let yy = 0; yy < scale; yy += 1) {
        for (let xx = 0; xx < scale; xx += 1) {
          setPixel(rgba, width, height, x * scale + xx, y * scale + yy, color);
        }
      }
    }
  }
  writePng(filePath, width, height, rgba);
}

function main() {
  const args = parseArgs(process.argv);
  const referenceImage = args.reference_image ? path.resolve(String(args.reference_image)) : null;
  if (!referenceImage) {
    throw new Error("Missing --reference-image");
  }

  const outputDir = path.resolve(String(args.output_dir || "outputs"));
  ensureDir(outputDir);
  const image = decodePng(referenceImage);
  const style = normalizeStyleOptions(args);

  const frontCrop = parseCrop(args.front_crop, image, "210,20,1120,370");
  const sideCrop = parseCrop(args.side_crop, image, "340,392,1005,275");
  const frontGridWidth = safeInt(args.front_grid_width, 760);
  const sideGridWidth = safeInt(args.side_grid_width, 670);
  const frontWidthMm = safeFloat(args.front_width_mm, 140);
  const frontDepthMm = safeFloat(args.front_depth_mm, 4.6);
  const armLengthMm = safeFloat(args.arm_length_mm, 138);
  const armThicknessMm = safeFloat(args.arm_thickness_mm, 3.7);

  const frontTraceRaw = buildMaskFromCrop(image, frontCrop, {
    gridWidth: frontGridWidth,
    threshold: safeFloat(args.front_threshold, 30),
    luminanceMax: safeFloat(args.front_luminance_max, 248),
    saturationMin: safeFloat(args.front_saturation_min, 0.018),
    samples: 3,
    minHits: 2,
  });
  const frontTrace = finalizeTrace(frontTraceRaw, { minPixels: 30, smoothIterations: 1, keepLargestOnly: false, padding: 2 });

  const sideTraceRaw = buildMaskFromCrop(image, sideCrop, {
    gridWidth: sideGridWidth,
    threshold: safeFloat(args.side_threshold, 32),
    luminanceMax: safeFloat(args.side_luminance_max, 248),
    saturationMin: safeFloat(args.side_saturation_min, 0.018),
    samples: 3,
    minHits: 3,
  });
  const sideTrace = finalizeTrace(sideTraceRaw, { minPixels: 80, smoothIterations: 1, keepLargestOnly: true, padding: 2 });

  const frameFront = new Mesh("frame_front");
  const frontProfile = addRasterExtrusionXY(frameFront, frontTrace, frontWidthMm, frontDepthMm, style.material);
  addFrontRivets(frameFront, frameFront.bounds(), frontDepthMm);

  const frontBounds = frameFront.bounds();
  const hingeX = frontBounds.max[0] - 3.2;
  const yOffset = safeFloat(args.arm_y_offset_mm, -5.0);
  const zStart = -frontDepthMm / 2 + 1.35;

  const rightArm = new Mesh("right_arm");
  const rightArmProfile = addRasterExtrusionYZ(rightArm, sideTrace, {
    targetLengthMm: armLengthMm,
    thicknessMm: armThicknessMm,
    xCenter: hingeX + armThicknessMm / 2,
    side: 1,
    zStart,
    yOffset,
    material: style.material,
  });
  const leftArm = mirrorMeshX(rightArm, "left_arm");
  const hingeProfile = {
    method: "arm_depth_overlap_without_extra_blocks",
    right_contact_x_mm: hingeX,
    left_contact_x_mm: -hingeX,
    y_offset_mm: yOffset,
    lowered_from_previous_mm: roundValue(-1.8 - yOffset, 3),
    z_start_mm: zStart,
    front_back_z_mm: -frontDepthMm / 2,
    overlap_mm: zStart - -frontDepthMm / 2,
  };

  addNaelEmboss(rightArm, {
    text: style.arm_text,
    side: 1,
    xSurface: hingeX + armThicknessMm + 0.04,
    startZ: -16.5,
    baseY: 5.25,
    heightMm: 5.2,
    reliefMm: 1.1,
  });

  const fullFrame = cloneMesh(frameFront, "full_frame");
  fullFrame.merge(leftArm);
  fullFrame.merge(rightArm);

  const paths = {
    frame_front: path.join(outputDir, "frame_front.stl"),
    left_arm: path.join(outputDir, "left_arm.stl"),
    right_arm: path.join(outputDir, "right_arm.stl"),
    full_frame: path.join(outputDir, "full_frame.stl"),
    metadata: path.join(outputDir, "frame_metadata.json"),
    front_trace_svg: path.join(outputDir, "frameana_image2stl_front_trace.svg"),
    side_trace_svg: path.join(outputDir, "frameana_image2stl_side_trace.svg"),
    front_trace_png: path.join(outputDir, "frameana_image2stl_front_trace.png"),
    side_trace_png: path.join(outputDir, "frameana_image2stl_side_trace.png"),
    preview_png: path.join(outputDir, "frameana_image2stl_3d_preview.png"),
  };

  writeBinaryStl(frameFront, paths.frame_front);
  writeBinaryStl(leftArm, paths.left_arm);
  writeBinaryStl(rightArm, paths.right_arm);
  writeBinaryStl(fullFrame, paths.full_frame);
  writeTraceSvg(paths.front_trace_svg, frontTrace, "#5a2b13");
  writeTraceSvg(paths.side_trace_svg, sideTrace, "#5a2b13");
  writeTracePng(paths.front_trace_png, frontTrace, [82, 40, 19, 255]);
  writeTracePng(paths.side_trace_png, sideTrace, [82, 40, 19, 255]);
  renderMeshPreview(fullFrame, paths.preview_png, style);

  const outputInfo = {
    frame_front: { path: path.resolve(paths.frame_front), bytes: fs.statSync(paths.frame_front).size, triangles: frameFront.triangles.length, bounds_mm: roundValue(frameFront.bounds()) },
    left_arm: { path: path.resolve(paths.left_arm), bytes: fs.statSync(paths.left_arm).size, triangles: leftArm.triangles.length, bounds_mm: roundValue(leftArm.bounds()) },
    right_arm: { path: path.resolve(paths.right_arm), bytes: fs.statSync(paths.right_arm).size, triangles: rightArm.triangles.length, bounds_mm: roundValue(rightArm.bounds()) },
    full_frame: { path: path.resolve(paths.full_frame), bytes: fs.statSync(paths.full_frame).size, triangles: fullFrame.triangles.length, bounds_mm: roundValue(fullFrame.bounds()) },
    front_trace_svg: { path: path.resolve(paths.front_trace_svg), bytes: fs.statSync(paths.front_trace_svg).size },
    side_trace_svg: { path: path.resolve(paths.side_trace_svg), bytes: fs.statSync(paths.side_trace_svg).size },
    front_trace_png: { path: path.resolve(paths.front_trace_png), bytes: fs.statSync(paths.front_trace_png).size },
    side_trace_png: { path: path.resolve(paths.side_trace_png), bytes: fs.statSync(paths.side_trace_png).size },
    preview_png: { path: path.resolve(paths.preview_png), bytes: fs.statSync(paths.preview_png).size },
  };

  const metadata = {
    stage: "FRAMEANA Stage 2C-4/2C-5 - 2D reference image to STL",
    style: style.frame_shape,
    material: style.material,
    frame_color: style.frame_color,
    engraving_text: style.arm_text,
    engraving_color: style.arm_text_color,
    generated_at: new Date().toISOString(),
    generator: {
      file: path.resolve(__filename),
      runtime: process.version,
      dependencies: "none",
      units: "millimeters",
      stl_format: "binary",
      geometry_source: "accepted_ai_cad_reference_2d_silhouette_extrusion",
      uses_ai_image_generation_during_stl_step: false,
    },
    source_inputs: {
      reference_image: path.resolve(referenceImage),
      image_size_px: { width: image.width, height: image.height },
      front_crop_px: frontCrop,
      side_crop_px: sideCrop,
    },
    style_options: style,
    geometry_profile: {
      principle: "Use the approved 2D frame image as source-of-truth, threshold the clean orthographic views, then extrude silhouettes into STL solids.",
      front: { ...frontProfile, trace_info: roundValue(traceSummary(frontTrace)) },
      side_arm: {
        ...rightArmProfile,
        trace_info: roundValue(traceSummary(sideTrace)),
        hinge_connection: roundValue(hingeProfile),
        text_geometry: {
          side_emboss: {
            text: style.arm_text,
            surface: "outside_right_arm",
            start_z_mm: -16.5,
            base_y_mm: 5.25,
            height_mm: 5.2,
            relief_mm: 1.1,
          },
        },
      },
      limitations: [
        "STL stores geometry only; tortoise/gold colors are saved in metadata and preview PNG.",
        "The front outline follows the 2D reference. Lens bevels and optical grooves can be refined later from the same trace.",
      ],
    },
    frontend_assets: {
      reference_2d: path.resolve(referenceImage),
      preview_png: path.resolve(paths.preview_png),
      front_trace_png: path.resolve(paths.front_trace_png),
      side_trace_png: path.resolve(paths.side_trace_png),
    },
    frontend_manifest: {
      reference_2d: path.basename(referenceImage),
      preview_png: path.basename(paths.preview_png),
      traces: {
        front_png: path.basename(paths.front_trace_png),
        side_png: path.basename(paths.side_trace_png),
        front_svg: path.basename(paths.front_trace_svg),
        side_svg: path.basename(paths.side_trace_svg),
      },
      stl: {
        frame_front: path.basename(paths.frame_front),
        left_arm: path.basename(paths.left_arm),
        right_arm: path.basename(paths.right_arm),
        full_frame: path.basename(paths.full_frame),
      },
      metadata: path.basename(paths.metadata),
    },
    outputs: outputInfo,
  };

  fs.writeFileSync(paths.metadata, `${JSON.stringify(metadata, null, 2)}\n`, "utf8");

  const reportPath = path.join(outputDir, "frameana_image2stl_result.md");
  const report = [
    "# FRAMEANA Image2STL Result",
    "",
    `Source 2D reference: ${path.resolve(referenceImage)}`,
    `Preview PNG: ${path.resolve(paths.preview_png)}`,
    "",
    "Generated:",
    `- ${path.resolve(paths.frame_front)}`,
    `- ${path.resolve(paths.left_arm)}`,
    `- ${path.resolve(paths.right_arm)}`,
    `- ${path.resolve(paths.full_frame)}`,
    `- ${path.resolve(paths.metadata)}`,
    "",
    "Notes:",
    "- The front STL is traced from the accepted 2D front view, then extruded.",
    "- The arm STL is traced from the accepted 2D side view and overlaps the front frame slightly at the hinge instead of using extra hinge blocks.",
    "- Nael is raised geometry directly on the right arm, not only color metadata.",
    "- Color/material remain metadata because STL itself has no material channel.",
    "",
  ].join("\n");
  fs.writeFileSync(reportPath, report, "utf8");

  console.log(JSON.stringify({ ok: true, outputs: outputInfo, report: path.resolve(reportPath) }, null, 2));
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error && error.stack ? error.stack : String(error));
    process.exit(1);
  }
}
