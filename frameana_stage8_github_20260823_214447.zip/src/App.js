import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Upload,
  Glasses,
  Palette,
  Sparkles,
  Check,
  Plus,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Loader2,
  Image as ImageIcon,
  Box,
  Download,
  ShieldCheck,
  SlidersVertical,
  Monitor,
  Smartphone,
  ChevronLeft,
  ChevronDown,
  Info,
  X,
  Maximize2,
  User,
  LogIn,
  LogOut,
  ListOrdered,
  Save,
  Send,
  Trash2,
  Eye,
  MessageSquare,
  Mail,
  LockKeyhole,
  Globe,
  Home,
} from "lucide-react";
import * as THREE from "three";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import logo from "./logo.png";
import "./App.css";

const API_BASE_URL = (
  process.env.REACT_APP_API_URL ||
  window.localStorage.getItem("FRAMEANA_API_URL") ||
  "http://localhost:8080"
).replace(/\/$/, "");

const LANGUAGE_STORAGE_KEY = "FRAMEANA_LANGUAGE";
const DEFAULT_LANGUAGE = "ar";
const LANGUAGE_OPTIONS = [
  { id: "en", label: "EN", name: "English" },
  { id: "ar", label: "AR", name: "العربية" },
];

const STEPS = [
  { id: 1, labelAr: "رفع الصورة", labelEn: "Upload Photo", shortLabelAr: "الصورة", shortLabelEn: "Photo", icon: Upload },
  { id: 2, labelAr: "اختيار الموديل", labelEn: "Choose Model", shortLabelAr: "الموديل", shortLabelEn: "Model", icon: Glasses },
  { id: 3, labelAr: "التخصيص", labelEn: "Customize", shortLabelAr: "التخصيص", shortLabelEn: "Customize", icon: Palette },
  { id: 4, labelAr: "النتيجة", labelEn: "Result", shortLabelAr: "النتيجة", shortLabelEn: "Result", icon: Sparkles },
];

const MODELS = [
  {
    id: "classic",
    backendStyle: "classic",
    nameAr: "كلاسيكي",
    nameEn: "Classic",
    descAr: "متوازن وعملي للاستخدام اليومي.",
    descEn: "Balanced and practical for everyday wear.",
    tagAr: "الأكثر طلبًا",
    tagEn: "Most Requested",
  },
  {
    id: "round",
    backendStyle: "round",
    nameAr: "دائري",
    nameEn: "Round",
    descAr: "شخصية واضحة بتفاصيل ناعمة.",
    descEn: "A distinct look with softer details.",
    tagAr: "تصميم خالد",
    tagEn: "Timeless",
  },
  {
    id: "sport",
    backendStyle: "sport",
    nameAr: "رياضي",
    nameEn: "Sport",
    descAr: "مظهر ديناميكي وثبات أعلى.",
    descEn: "A dynamic profile with extra stability.",
    tagAr: "أداء عملي",
    tagEn: "Performance",
  },
];

const MATERIALS = [
  { id: "acetate", nameAr: "أسيتات", nameEn: "Acetate", descAr: "مظهر فاخر ومناسب للإنتاج.", descEn: "Premium finish suitable for production." },
  { id: "nylon", nameAr: "نايلون", nameEn: "Nylon", descAr: "خفيف ومرن للاستخدام اليومي.", descEn: "Lightweight and flexible for everyday use." },
  { id: "pla", nameAr: "PLA نموذج أولي", nameEn: "PLA Prototype", descAr: "مناسب للنماذج الأولية.", descEn: "Best for early prototypes." },
];

const FRAME_COLORS = [
  { value: "#1F2D57", nameAr: "كحلي FRAMEANA", nameEn: "FRAMEANA Navy" },
  { value: "#161616", nameAr: "أسود ليلي", nameEn: "Night Black" },
  { value: "#6B3F2A", nameAr: "هافانا دافئ", nameEn: "Warm Havana" },
  { value: "#D8C7A6", nameAr: "رملي ناعم", nameEn: "Soft Sand" },
];

const ORDER_STATUS = {
  NEW: 1,
  SUBMITTED: 2,
  RECEIVED: 3,
  FINISHED: 4,
  DELIVERED: 5,
  CLIENT_FEEDBACK: 6,
};

const ORDER_STATUS_META = {
  [ORDER_STATUS.NEW]: { labelAr: "جديد", labelEn: "New", tone: "new" },
  [ORDER_STATUS.SUBMITTED]: { labelAr: "تم الإرسال", labelEn: "Submitted", tone: "submitted" },
  [ORDER_STATUS.RECEIVED]: { labelAr: "استلمته FRAMEANA", labelEn: "Received by FRAMEANA", tone: "received" },
  [ORDER_STATUS.FINISHED]: { labelAr: "منتهي", labelEn: "Finished", tone: "finished" },
  [ORDER_STATUS.DELIVERED]: { labelAr: "تم التسليم", labelEn: "Delivered", tone: "delivered" },
  [ORDER_STATUS.CLIENT_FEEDBACK]: { labelAr: "ملاحظات العميل", labelEn: "Client Feedback", tone: "feedback" },
};

const UI_TEXT = {
  ar: {
    deviceSwitchLabel: "اختيار عرض الواجهة",
    languageSwitchLabel: "اختيار لغة الواجهة",
    laptop: "لابتوب",
    mobile: "موبايل",
    home: "الرئيسية",
    homeToNewDesign: "العودة إلى تصميم إطار جديد",
    designer: "التصميم",
    myOrders: "طلباتي",
    logout: "خروج",
    logoutLabel: "تسجيل الخروج",
    heroBadge: "تصميم نظارة مخصّصة بالذكاء الاصطناعي",
    heroTitleLead: "من صورة الوجه إلى",
    heroTitleHighlight: "إطار يناسب العميل",
    heroCopy: "ارفع الصورة، اختر التصميم، خصّص التفاصيل، ثم اعرض النتيجة وملفات STL في مكان واحد.",
    designerPageTitle: "تصميم إطار جديد",
    designerPageCopy: "ارفع صورة الوجه، اختر الموديل، ثم خصّص المادة واللون والنقش.",
    chooseCustomerImage: "اختيار صورة العميل",
    uploadNewImage: "رفع صورة جديدة",
    footerBrand: "FRAMEANA — نصنع مستقبل النظارات",
    close: "إغلاق",
    closeImage: "إغلاق الصورة",
    designStages: "مراحل التصميم",
    authLoadingEyebrow: "حساب FRAMEANA",
    authVerifying: "جاري التحقق من الجلسة...",
    authBrand: "FRAMEANA",
    authStudioTitle: "FRAMEANA Studio",
    authStudioSubtitle: "تخصيص وتصنيع النظارات بالذكاء الاصطناعي",
    authHeroTitle: "نظارات دقيقة، مصممة على قياساتك.",
    authStatOneValue: "0.1 mm",
    authStatOneLabel: "دقة القياس",
    authStatTwoValue: "48 h",
    authStatTwoLabel: "إنتاج",
    authStatThreeValue: "12",
    authStatThreeLabel: "مواد",
    authEyebrow: "حساب عميل FRAMEANA",
    authRegisterTitle: "إنشاء حساب جديد",
    authLoginTitle: "تسجيل الدخول للمتابعة",
    authIntro: "يتم حفظ التصاميم كطلبات داخل حسابك الخاص، مع تخزين قاعدة البيانات والملفات على قرص D.",
    authModeLabel: "اختيار طريقة الدخول",
    login: "دخول",
    register: "تسجيل",
    name: "الاسم",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    forgotPassword: "نسيت كلمة المرور؟",
    signIn: "تسجيل الدخول",
    createAccount: "إنشاء الحساب",
    stepOne: "الخطوة الأولى",
    uploadTitle: "ابدأ بصورة واضحة للعميل",
    uploadCopy: "استخدم صورة أمامية بإضاءة جيدة ومن دون نظارة للحصول على قياسات ومعاينة أفضل.",
    uploadDropTitle: "اضغط هنا أو اسحب الصورة",
    uploadDropHint: "PNG, JPG أو WEBP — الحد الأقصى 10MB",
    chooseImage: "اختيار صورة",
    tipPrivacyTitle: "خصوصية",
    tipPrivacyText: "الصورة تُرسل فقط إلى خدمة FRAMEANA المحلية.",
    tipAlignmentTitle: "محاذاة أفضل",
    tipAlignmentText: "اجعل العينين والأنف ظاهرين بوضوح.",
    tipResultTitle: "نتيجة أجمل",
    tipResultText: "تجنّب الإضاءة القوية والظلال الحادة.",
    stepTwo: "الخطوة الثانية",
    stepTwoCopy: "ابدأ بالموديل الأقرب لذوق العميل، ويمكن تغيير اللون والمادة في الخطوة التالية.",
    customerImage: "صورة العميل",
    stepThree: "الخطوة الثالثة",
    customizeTitle: "خصّص الإطار",
    customizeCopy: "اختر المادة واللون والنقش. هذه القيم تُرسل كما هي إلى مولّد FRAMEANA.",
    designSettings: "إعدادات التصميم",
    designSettingsCopy: "اضبط الشكل، المادة، اللون، والنقش قبل توليد ملفات الإطار.",
    frameStyle: "شكل الإطار",
    material: "المادة",
    frameColor: "لون الإطار",
    engraving: "النقش",
    engravingColor: "لون النقش",
    engravingPlaceholder: "مثال: Nael H.Ghannam",
    characters: "حرف",
    livePreview: "معاينة مباشرة",
    designSummary: "ملخص التصميم",
    noEngraving: "بدون نقش",
    summaryNote: "سيتم إنشاء المعاينة وملفات STL من نفس الإعدادات.",
    generateDesign: "توليد التصميم",
    colorPickerTitle: "اختيار لون",
    colorCodeLabel: "كود اللون",
    continue: "متابعة",
    back: "رجوع",
    authFallbackError: "تعذر تسجيل الدخول.",
    loadOrdersError: "تعذر تحميل الطلبات.",
    openOrderError: "تعذر فتح الطلب.",
    saveOrderError: "تعذر حفظ الطلب.",
    submitOrderError: "تعذر إرسال الطلب.",
    deleteOrderError: "تعذر حذف الطلب.",
    feedbackError: "تعذر حفظ الملاحظات.",
    fileTypeError: "يرجى اختيار ملف صورة بصيغة PNG أو JPG أو WEBP.",
    fileSizeError: "حجم الصورة يجب ألا يتجاوز 10MB.",
    imageRequiredError: "ارفع صورة العميل أولًا.",
    generationFailedError: "فشل توليد التصميم.",
    serverConnectionError: "فشل الاتصال بالسيرفر. تأكد من تشغيل backend على المنفذ 8080.",
    alreadySaved: (number) => `تم حفظ هذا التصميم مسبقًا برقم ${number}.`,
    savedAndSubmitted: (number) => `تم الحفظ والإرسال برقم ${number}.`,
    savedOnly: (number) => `تم الحفظ برقم ${number}.`,
    submittedOrder: (number) => `تم إرسال ${number} إلى FRAMEANA.`,
    confirmDelete: (number) => `هل تريد حذف ${number}؟`,
    deletedOrder: (number) => `تم حذف ${number}.`,
    feedbackPrompt: (number) => `ملاحظات العميل على ${number}`,
    feedbackSaved: (number) => `تم حفظ الملاحظات للطلب ${number}.`,
    ordersEyebrow: "الحساب",
    ordersTitle: "طلباتي",
    ordersLimit: (count) => `الحد الأقصى 5 طلبات جديدة في كل مرة. الطلبات المرسلة لا تُحتسب. · جديد ${count}/5`,
    refresh: "تحديث",
    newDesign: "تصميم جديد",
    noOrdersTitle: "لا توجد طلبات بعد",
    noOrdersCopy: "أنشئ تصميمًا جديدًا ثم استخدم حفظ أو حفظ وإرسال.",
    orderTableLabel: "طلباتي",
    orderColumn: "رقم الطلب",
    frameColumn: "الإطار",
    materialColumn: "المادة",
    dateColumn: "تاريخ الإنشاء",
    statusColumn: "الحالة",
    actionsColumn: "الإجراءات",
    view: "عرض",
    submit: "إرسال",
    delete: "حذف",
    feedback: "ملاحظات",
    chooseOrderTitle: "اختر طلبًا",
    chooseOrderCopy: "افتح أي طلب لعرض بيانات التصميم، المعاينات، الملفات، وتاريخ الحالة.",
    orderDetails: "تفاصيل الطلب",
    fileFrameFront: "STL واجهة الإطار",
    fileLeftArm: "STL الذراع اليسار",
    fileRightArm: "STL الذراع اليمين",
    fileFullFrame: "STL الإطار الكامل",
    files: "الملفات",
    statusHistory: "تاريخ الحالة",
    submitOrder: "إرسال الطلب",
    deleteOrder: "حذف الطلب",
    deliveredClient: "تم تسليمه للعميل",
    submittedToFrameana: "تم إرساله إلى FRAMEANA",
    clientFeedback: "ملاحظات العميل",
    faceWidth: "عرض الوجه",
    eyeDistance: "المسافة بين العينين",
    noseWidth: "عرض الأنف",
    headAngle: "زاوية الرأس",
    processingEyebrow: "معالجة FRAMEANA",
    generatingTitle: "جاري إنشاء التصميم...",
    generatingCopy: "تحليل الصورة، تجهيز الإطار، إنشاء metadata وتصدير ملفات STL.",
    analyzingFace: "تحليل الوجه",
    generatingFrame: "توليد الإطار",
    exportingStl: "تصدير STL",
    resultErrorTitle: "لم يتم إنشاء النتيجة",
    backToEdit: "الرجوع للتعديل",
    designCreated: "تم إنشاء التصميم",
    resultStep: "النتيجة",
    resultNewOrders: "طلبات جديدة",
    resultHighRes: "دقة عالية",
    resultFilesLabel: "ملفات STL",
    resultTitle: "معاينة العميل وملفات التصنيع",
    resultDescription: (model, material, engraving) => `${model} · ${material} · نقش “${engraving}”`,
    model: "الموديل",
    stlViewer: "عارض STL",
    stlViewerHelp: "اسحب للدوران واستخدم عجلة الفأرة أو اللمس للتقريب",
    fullFrame: "الإطار الكامل",
    frameFront: "الواجهة الأمامية",
    leftArm: "الذراع اليسار",
    rightArm: "الذراع اليمين",
    download: (label) => `تنزيل ${label}`,
    editOptions: "تعديل الخيارات",
    save: "حفظ",
    saveAndSubmit: "حفظ وإرسال",
    previewCustomerTitle: "معاينة العميل",
    previewCustomerSubtitle: "الشكل النهائي على الوجه",
    previewCustomerFallback: "صورة المعاينة غير متوفرة",
    frameImageTitle: "صورة الإطار",
    frameImageSubtitle: "معاينة المنتج منفصلًا",
    frameImageFallback: "صورة الإطار غير متوفرة",
    viewFull: "عرض كامل",
    fullViewLabel: (title) => `عرض ${title} كاملة`,
    openFullLabel: (title) => `فتح ${title} بالحجم الكامل`,
    stlViewerError: "تعذر تحميل ملف STL داخل العارض. يمكنك تنزيل الملف وفتحه خارجيًا.",
    noStlFile: "لا يوجد ملف STL للعرض",
    viewerHint: "اسحب للدوران · قرّب بإصبعين",
    unknownStatus: "غير معروف",
  },
  en: {
    deviceSwitchLabel: "Choose interface preview",
    languageSwitchLabel: "Choose interface language",
    laptop: "Laptop",
    mobile: "Mobile",
    home: "Home",
    homeToNewDesign: "Back to New frame design",
    designer: "Designer",
    myOrders: "My Orders",
    logout: "Logout",
    logoutLabel: "Log out",
    heroBadge: "AI-powered custom eyewear design",
    heroTitleLead: "From face photo to",
    heroTitleHighlight: "a frame that fits",
    heroCopy: "Upload the photo, choose the design, customize the details, then review the result and STL files in one place.",
    designerPageTitle: "New frame design",
    designerPageCopy: "Upload the face photo, choose a model, then customize material, color, and engraving.",
    chooseCustomerImage: "Choose Customer Photo",
    uploadNewImage: "Upload New Photo",
    footerBrand: "FRAMEANA — building the future of eyewear",
    close: "Close",
    closeImage: "Close image",
    designStages: "Design stages",
    authLoadingEyebrow: "FRAMEANA Account",
    authVerifying: "Checking session...",
    authBrand: "FRAMEANA",
    authStudioTitle: "FRAMEANA Studio",
    authStudioSubtitle: "AI eyewear customization & manufacturing",
    authHeroTitle: "Precision eyewear, made to your measurements.",
    authStatOneValue: "0.1 mm",
    authStatOneLabel: "Tolerance",
    authStatTwoValue: "48 h",
    authStatTwoLabel: "Production",
    authStatThreeValue: "12",
    authStatThreeLabel: "Materials",
    authEyebrow: "FRAMEANA Client Account",
    authRegisterTitle: "Create a New Account",
    authLoginTitle: "Login to Continue",
    authIntro: "Designs are saved as orders in your private account, with the database and files stored on drive D.",
    authModeLabel: "Choose access mode",
    login: "Login",
    register: "Register",
    name: "Name",
    email: "Email",
    password: "Password",
    forgotPassword: "Forgot password?",
    signIn: "Sign in",
    createAccount: "Create Account",
    stepOne: "Step One",
    uploadTitle: "Start with a clear customer photo",
    uploadCopy: "Use a front-facing photo with good lighting and no glasses for better measurements and preview quality.",
    uploadDropTitle: "Click here or drop the image",
    uploadDropHint: "PNG, JPG, or WEBP — max 10MB",
    chooseImage: "Choose Image",
    tipPrivacyTitle: "Privacy",
    tipPrivacyText: "The photo is sent only to your local FRAMEANA service.",
    tipAlignmentTitle: "Better Alignment",
    tipAlignmentText: "Keep the eyes and nose clearly visible.",
    tipResultTitle: "Better Result",
    tipResultText: "Avoid harsh light and strong shadows.",
    stepTwo: "Step Two",
    stepTwoCopy: "Start with the model closest to the customer's taste. Color and material can be changed in the next step.",
    customerImage: "Customer Photo",
    stepThree: "Step Three",
    customizeTitle: "Customize the Frame",
    customizeCopy: "Choose material, color, and engraving. These values are sent directly to the FRAMEANA generator.",
    designSettings: "Design Settings",
    designSettingsCopy: "Adjust shape, material, color, and engraving before generating frame files.",
    frameStyle: "Frame Style",
    material: "Material",
    frameColor: "Frame Color",
    engraving: "Engraving",
    engravingColor: "Engraving Color",
    engravingPlaceholder: "Example: Nael H.Ghannam",
    characters: "chars",
    livePreview: "Live Preview",
    designSummary: "Design Summary",
    noEngraving: "No engraving",
    summaryNote: "Preview and STL files will be generated from the same settings.",
    generateDesign: "Generate Design",
    colorPickerTitle: "Choose color",
    colorCodeLabel: "Color code",
    continue: "Continue",
    back: "Back",
    authFallbackError: "Could not log in.",
    loadOrdersError: "Could not load orders.",
    openOrderError: "Could not open the order.",
    saveOrderError: "Could not save the order.",
    submitOrderError: "Could not submit the order.",
    deleteOrderError: "Could not delete the order.",
    feedbackError: "Could not save feedback.",
    fileTypeError: "Please choose a PNG, JPG, or WEBP image file.",
    fileSizeError: "Image size must not exceed 10MB.",
    imageRequiredError: "Upload the customer photo first.",
    generationFailedError: "Design generation failed.",
    serverConnectionError: "Could not connect to the server. Make sure the backend is running on port 8080.",
    alreadySaved: (number) => `This design is already saved as ${number}.`,
    savedAndSubmitted: (number) => `Saved and submitted as ${number}.`,
    savedOnly: (number) => `Saved as ${number}.`,
    submittedOrder: (number) => `${number} was submitted to FRAMEANA.`,
    confirmDelete: (number) => `Delete ${number}?`,
    deletedOrder: (number) => `${number} was deleted.`,
    feedbackPrompt: (number) => `Client feedback for ${number}`,
    feedbackSaved: (number) => `Feedback was saved for ${number}.`,
    ordersEyebrow: "Account",
    ordersTitle: "My Orders",
    ordersLimit: (count) => `Maximum 5 New orders at a time. Submitted orders no longer count. · New ${count}/5`,
    refresh: "Refresh",
    newDesign: "New Design",
    noOrdersTitle: "No Orders Yet",
    noOrdersCopy: "Create a new design, then use Save or Save & Submit.",
    orderTableLabel: "My Orders",
    orderColumn: "Order No.",
    frameColumn: "Frame",
    materialColumn: "Material",
    dateColumn: "Created",
    statusColumn: "Status",
    actionsColumn: "Actions",
    view: "View",
    submit: "Submit",
    delete: "Delete",
    feedback: "Feedback",
    chooseOrderTitle: "Choose an Order",
    chooseOrderCopy: "Open any order to review design data, previews, files, and status history.",
    orderDetails: "Order Details",
    fileFrameFront: "Frame Front STL",
    fileLeftArm: "Left Arm STL",
    fileRightArm: "Right Arm STL",
    fileFullFrame: "Full Frame STL",
    files: "Files",
    statusHistory: "Status History",
    submitOrder: "Submit Order",
    deleteOrder: "Delete Order",
    deliveredClient: "Delivered to client",
    submittedToFrameana: "Submitted to FRAMEANA",
    clientFeedback: "Client Feedback",
    faceWidth: "Face Width",
    eyeDistance: "Eye Distance",
    noseWidth: "Nose Width",
    headAngle: "Head Angle",
    processingEyebrow: "FRAMEANA Processing",
    generatingTitle: "Generating the design...",
    generatingCopy: "Analyzing the photo, preparing the frame, creating metadata, and exporting STL files.",
    analyzingFace: "Face analysis",
    generatingFrame: "Frame generation",
    exportingStl: "STL export",
    resultErrorTitle: "Result Was Not Created",
    backToEdit: "Back to Edit",
    designCreated: "Design Created",
    resultStep: "Result",
    resultNewOrders: "New orders",
    resultHighRes: "High res",
    resultFilesLabel: "STL files",
    resultTitle: "Customer Preview and Manufacturing Files",
    resultDescription: (model, material, engraving) => `${model} · ${material} · engraving “${engraving}”`,
    model: "Model",
    stlViewer: "STL Viewer",
    stlViewerHelp: "Drag to rotate, and use the mouse wheel or touch to zoom",
    fullFrame: "Full Frame",
    frameFront: "Front Face",
    leftArm: "Left Arm",
    rightArm: "Right Arm",
    download: (label) => `Download ${label}`,
    editOptions: "Edit Options",
    save: "Save",
    saveAndSubmit: "Save & Submit",
    previewCustomerTitle: "Customer Preview",
    previewCustomerSubtitle: "Final look on the face",
    previewCustomerFallback: "Preview image is unavailable",
    frameImageTitle: "Frame Image",
    frameImageSubtitle: "Standalone product preview",
    frameImageFallback: "Frame image is unavailable",
    viewFull: "Full View",
    fullViewLabel: (title) => `View full ${title}`,
    openFullLabel: (title) => `Open ${title} full size`,
    stlViewerError: "Could not load the STL inside the viewer. You can download it and open it externally.",
    noStlFile: "No STL file to preview",
    viewerHint: "Drag to rotate · pinch to zoom",
    unknownStatus: "Unknown",
  },
};

function absoluteUrl(path) {
  if (!path) return null;
  if (/^https?:\/\//i.test(path)) return path;
  return `${API_BASE_URL}${path.startsWith("/") ? "" : "/"}${path}`;
}

async function apiRequest(path, { method = "GET", token = "", body } = {}) {
  const headers = { Accept: "application/json" };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.message || payload.detail || `HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }

  return payload;
}

const API_ERROR_TRANSLATIONS = {
  en: {
    "رمز الدخول غير صالح.": "Invalid login token.",
    "انتهت صلاحية جلسة الدخول.": "The login session has expired.",
    "الاسم مطلوب.": "Name is required.",
    "البريد الإلكتروني غير صالح.": "Email address is invalid.",
    "كلمة المرور يجب أن تكون 6 أحرف على الأقل.": "Password must be at least 6 characters.",
    "البريد الإلكتروني أو كلمة المرور غير صحيحة.": "Email or password is incorrect.",
    "الحساب غير نشط أو لم يعد موجودًا.": "This account is inactive or no longer exists.",
    "يمكن إنشاء طلبات العميل فقط بحالة جديد أو تم الإرسال.": "Client orders can only be created as New or Submitted.",
    "لديك بالفعل 5 تصاميم محفوظة. أرسل أو احذف أحد الطلبات الجديدة قبل حفظ تصميم آخر.":
      "You already have 5 saved designs. Submit or delete one New order before saving another design.",
    "الطلب غير موجود.": "Order was not found.",
    "يمكن إرسال الطلبات الجديدة فقط.": "Only New orders can be submitted.",
    "يمكن حذف الطلبات الجديدة فقط.": "Only New orders can be deleted.",
    "يمكن إضافة الملاحظات بعد التسليم فقط.": "Feedback can be added only after delivery.",
    "نص الملاحظات مطلوب.": "Feedback text is required.",
    "الصورة مطلوبة.": "Image is required.",
    "حجم الصورة يتجاوز حد 10MB.": "Image size exceeds the 10MB limit.",
    "الطلب غير صالح.": "The request is invalid.",
    "نوع الصورة غير مدعوم. استخدم JPG أو PNG أو WEBP.": "Unsupported image type. Use JPG, PNG, or WEBP.",
    "حدث خطأ غير متوقع أثناء إنشاء التصميم.": "An unexpected error occurred while generating the design.",
  },
};

function getText(language) {
  return UI_TEXT[language] || UI_TEXT[DEFAULT_LANGUAGE];
}

function localizeField(item, field, language = DEFAULT_LANGUAGE) {
  if (!item) return "";
  const suffix = language === "en" ? "En" : "Ar";
  return item[`${field}${suffix}`] || item[field] || "";
}

function localizeApiError(error, fallback, language = DEFAULT_LANGUAGE) {
  const message = error?.message;
  if (!message) return fallback;
  if (language === "en") return API_ERROR_TRANSLATIONS.en[message] || message;
  return message;
}

function formatOrderDate(value, language = DEFAULT_LANGUAGE) {
  if (!value) return "-";
  try {
    return new Intl.DateTimeFormat(language === "en" ? "en" : "ar", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function orderStatusMeta(status, language = DEFAULT_LANGUAGE) {
  const meta = ORDER_STATUS_META[Number(status)];
  if (!meta) return { label: getText(language).unknownStatus, tone: "unknown" };
  return { label: localizeField(meta, "label", language), tone: meta.tone };
}

function modelName(modelId, language = DEFAULT_LANGUAGE) {
  const model = MODELS.find((item) => item.id === modelId);
  return localizeField(model, "name", language) || modelId;
}

function modelDescription(modelId, language = DEFAULT_LANGUAGE) {
  return localizeField(MODELS.find((model) => model.id === modelId), "desc", language);
}

function modelTag(modelId, language = DEFAULT_LANGUAGE) {
  return localizeField(MODELS.find((model) => model.id === modelId), "tag", language);
}

function getBackendStyle(modelId) {
  return MODELS.find((model) => model.id === modelId)?.backendStyle || "classic";
}

function materialName(materialId, language = DEFAULT_LANGUAGE) {
  const material = MATERIALS.find((item) => item.id === materialId);
  return localizeField(material, "name", language) || materialId;
}

function frameColorName(value, language = DEFAULT_LANGUAGE) {
  return localizeField(FRAME_COLORS.find((color) => color.value === value), "name", language) || value;
}

function pickCustomerPreview(data) {
  const outputs = data?.outputs || {};
  return (
    outputs.customer_tryon ||
    outputs.tryon_preview ||
    outputs.segmind_tryon ||
    outputs.tryon_realistic ||
    outputs.realistic_tryon ||
    outputs.technical_tryon ||
    data?.customer_tryon ||
    data?.result_image ||
    null
  );
}

function pickFramePreview(data) {
  const outputs = data?.outputs || {};
  return (
    outputs.frame_preview ||
    outputs.frame_only ||
    outputs.product_preview ||
    outputs.preview_image ||
    data?.frame_preview ||
    null
  );
}

async function hydrateMetadata(data) {
  if (data?.metadata && typeof data.metadata === "object") return data;

  const metadataPath = data?.outputs?.frame_metadata || data?.frame_metadata;
  if (!metadataPath) return data;

  try {
    const response = await fetch(absoluteUrl(metadataPath), { cache: "no-store" });
    if (!response.ok) return data;
    const metadata = await response.json();
    return { ...data, metadata };
  } catch (error) {
    console.warn("Could not read frame_metadata.json", error);
    return data;
  }
}


function getInitialDeviceMode() {
  if (typeof window === "undefined") return "laptop";

  const savedMode = window.localStorage.getItem("FRAMEANA_DEVICE_MODE");
  if (savedMode === "laptop" || savedMode === "mobile") {
    return savedMode;
  }

  return window.innerWidth <= 760 ? "mobile" : "laptop";
}

function getInitialLanguage() {
  if (typeof window === "undefined") return DEFAULT_LANGUAGE;

  const savedLanguage = window.localStorage.getItem(LANGUAGE_STORAGE_KEY);
  return savedLanguage === "ar" || savedLanguage === "en" ? savedLanguage : DEFAULT_LANGUAGE;
}

function LanguageSelect({ language, setLanguage, text }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const selectedLanguage = LANGUAGE_OPTIONS.find((option) => option.id === language) || LANGUAGE_OPTIONS[0];

  useEffect(() => {
    if (!open) return undefined;

    const closeOnOutsideClick = (event) => {
      if (!menuRef.current?.contains(event.target)) {
        setOpen(false);
      }
    };

    const closeOnEscape = (event) => {
      if (event.key === "Escape") {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", closeOnOutsideClick);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeOnOutsideClick);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [open]);

  return (
    <div className={`language-list-control ${open ? "language-list-open" : ""}`} ref={menuRef}>
      <button
        type="button"
        className="language-trigger"
        onClick={() => setOpen((current) => !current)}
        aria-label={text.languageSwitchLabel}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <Globe size={15} strokeWidth={2.25} className="language-globe" />
        <span>{selectedLanguage.label}</span>
        <ChevronDown size={15} className="language-chevron" aria-hidden="true" />
      </button>

      {open && (
        <div className="language-menu" role="listbox" aria-label={text.languageSwitchLabel}>
          {LANGUAGE_OPTIONS.map((option) => {
            const selected = option.id === language;
            return (
              <button
                key={option.id}
                type="button"
                className={`language-option ${selected ? "language-option-active" : ""}`}
                role="option"
                aria-selected={selected}
                onClick={() => {
                  setLanguage(option.id);
                  setOpen(false);
                }}
              >
                <span>{option.name}</span>
                {selected && <Check size={15} aria-hidden="true" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function App() {
  const [step, setStep] = useState(1);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [customerPreview, setCustomerPreview] = useState(null);
  const [framePreview, setFramePreview] = useState(null);
  const [workflowResult, setWorkflowResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [deviceMode, setDeviceMode] = useState(getInitialDeviceMode);
  const [language, setLanguage] = useState(getInitialLanguage);
  const [authToken, setAuthToken] = useState(() =>
    typeof window === "undefined" ? "" : window.localStorage.getItem("FRAMEANA_AUTH_TOKEN") || ""
  );
  const [currentUser, setCurrentUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(Boolean(authToken));
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [authError, setAuthError] = useState("");
  const [view, setView] = useState("designer");
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [orderActionLoading, setOrderActionLoading] = useState("");
  const [orderMessage, setOrderMessage] = useState(null);
  const [savedOrder, setSavedOrder] = useState(null);
  const text = useMemo(() => getText(language), [language]);
  const newOrderCount = useMemo(
    () => orders.filter((order) => Number(order.status) === ORDER_STATUS.NEW).length,
    [orders]
  );

  const [config, setConfig] = useState({
    model: "classic",
    material: "acetate",
    frameColor: "#1F2D57",
    engravingColor: "#C9A14A",
    engraving: "Nael",
  });

  const fileRef = useRef(null);

  const persistAuth = ({ token, user }) => {
    window.localStorage.setItem("FRAMEANA_AUTH_TOKEN", token);
    setAuthToken(token);
    setCurrentUser(user);
    setAuthError("");
    setView("designer");
  };

  const handleAuthSubmit = async ({ mode, name, email, password }) => {
    setAuthSubmitting(true);
    setAuthError("");

    try {
      const payload = await apiRequest(`/api/auth/${mode}`, {
        method: "POST",
        body: mode === "register" ? { name, email, password } : { email, password },
      });
      persistAuth(payload);
    } catch (error) {
      setAuthError(localizeApiError(error, text.authFallbackError, language));
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogout = () => {
    window.localStorage.removeItem("FRAMEANA_AUTH_TOKEN");
    setAuthToken("");
    setCurrentUser(null);
    setOrders([]);
    setSelectedOrder(null);
    setSavedOrder(null);
    setOrderMessage(null);
    setView("designer");
  };

  const loadOrders = useCallback(async () => {
    if (!authToken) return [];

    setOrdersLoading(true);
    try {
      const payload = await apiRequest("/api/orders", { token: authToken });
      const nextOrders = payload.orders || [];
      setOrders(nextOrders);
      return nextOrders;
    } catch (error) {
      setOrderMessage({ type: "error", text: localizeApiError(error, text.loadOrdersError, language) });
      return [];
    } finally {
      setOrdersLoading(false);
    }
  }, [authToken, language, text]);

  const handleSelectOrder = useCallback(
    async (order) => {
      if (!order?.id || !authToken) return;

      setOrderActionLoading(`view-${order.id}`);
      setOrderMessage(null);
      try {
        const payload = await apiRequest(`/api/orders/${order.id}`, { token: authToken });
        setSelectedOrder(payload.order);
      } catch (error) {
        setOrderMessage({ type: "error", text: localizeApiError(error, text.openOrderError, language) });
      } finally {
        setOrderActionLoading("");
      }
    },
    [authToken, language, text]
  );

  const handleCreateOrder = async (status) => {
    if (!workflowResult || !authToken || savedOrder) {
      if (savedOrder) {
        setOrderMessage({ type: "success", text: text.alreadySaved(savedOrder.order_number) });
      }
      return;
    }

    setOrderActionLoading(status === ORDER_STATUS.SUBMITTED ? "save-submit" : "save");
    setOrderMessage(null);

    try {
      const payload = await apiRequest("/api/orders", {
        method: "POST",
        token: authToken,
        body: {
          status,
          design: {
            config,
            workflow_result: workflowResult,
            customer_preview: customerPreview,
            frame_preview: framePreview,
          },
        },
      });
      setSavedOrder(payload.order);
      setOrders((previous) => [payload.order, ...previous.filter((order) => order.id !== payload.order.id)]);
      setOrderMessage({
        type: "success",
        text:
          status === ORDER_STATUS.SUBMITTED
            ? text.savedAndSubmitted(payload.order.order_number)
            : text.savedOnly(payload.order.order_number),
      });
    } catch (error) {
      setOrderMessage({ type: "error", text: localizeApiError(error, text.saveOrderError, language) });
    } finally {
      setOrderActionLoading("");
    }
  };

  const handleSubmitOrder = async (order) => {
    if (!order?.id || !authToken) return;

    setOrderActionLoading(`submit-${order.id}`);
    setOrderMessage(null);
    try {
      const payload = await apiRequest(`/api/orders/${order.id}/submit`, {
        method: "POST",
        token: authToken,
      });
      setSelectedOrder(payload.order);
      setOrders((previous) => previous.map((item) => (item.id === payload.order.id ? payload.order : item)));
      setOrderMessage({ type: "success", text: text.submittedOrder(payload.order.order_number) });
    } catch (error) {
      setOrderMessage({ type: "error", text: localizeApiError(error, text.submitOrderError, language) });
    } finally {
      setOrderActionLoading("");
    }
  };

  const handleDeleteOrder = async (order) => {
    if (!order?.id || !authToken) return;
    if (!window.confirm(text.confirmDelete(order.order_number))) return;

    setOrderActionLoading(`delete-${order.id}`);
    setOrderMessage(null);
    try {
      await apiRequest(`/api/orders/${order.id}`, {
        method: "DELETE",
        token: authToken,
      });
      setOrders((previous) => previous.filter((item) => item.id !== order.id));
      setSelectedOrder((current) => (current?.id === order.id ? null : current));
      setOrderMessage({ type: "success", text: text.deletedOrder(order.order_number) });
    } catch (error) {
      setOrderMessage({ type: "error", text: localizeApiError(error, text.deleteOrderError, language) });
    } finally {
      setOrderActionLoading("");
    }
  };

  const handleFeedbackOrder = async (order) => {
    if (!order?.id || !authToken) return;
    const feedback = window.prompt(text.feedbackPrompt(order.order_number));
    if (!feedback) return;

    setOrderActionLoading(`feedback-${order.id}`);
    setOrderMessage(null);
    try {
      const payload = await apiRequest(`/api/orders/${order.id}/feedback`, {
        method: "POST",
        token: authToken,
        body: { feedback },
      });
      setSelectedOrder(payload.order);
      setOrders((previous) => previous.map((item) => (item.id === payload.order.id ? payload.order : item)));
      setOrderMessage({ type: "success", text: text.feedbackSaved(payload.order.order_number) });
    } catch (error) {
      setOrderMessage({ type: "error", text: localizeApiError(error, text.feedbackError, language) });
    } finally {
      setOrderActionLoading("");
    }
  };

  useEffect(() => {
    let cancelled = false;

    if (!authToken) {
      setAuthLoading(false);
      setCurrentUser(null);
      return () => {
        cancelled = true;
      };
    }

    setAuthLoading(true);
    apiRequest("/api/auth/me", { token: authToken })
      .then((payload) => {
        if (!cancelled) setCurrentUser(payload.user);
      })
      .catch(() => {
        if (cancelled) return;
        window.localStorage.removeItem("FRAMEANA_AUTH_TOKEN");
        setAuthToken("");
        setCurrentUser(null);
      })
      .finally(() => {
        if (!cancelled) setAuthLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [authToken]);

  useEffect(() => {
    if (view === "orders" && currentUser) {
      loadOrders();
    }
  }, [currentUser, loadOrders, view]);

  useEffect(() => {
    window.localStorage.setItem("FRAMEANA_DEVICE_MODE", deviceMode);
  }, [deviceMode]);

  useEffect(() => {
    window.localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
  }, [language]);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const setSelectedFile = (selectedFile) => {
    if (!selectedFile) return;

    if (!selectedFile.type.startsWith("image/")) {
      setErrorMessage(text.fileTypeError);
      return;
    }

    if (selectedFile.size > 10 * 1024 * 1024) {
      setErrorMessage(text.fileSizeError);
      return;
    }

    if (preview) URL.revokeObjectURL(preview);
    const localPreview = URL.createObjectURL(selectedFile);

    setFile(selectedFile);
    setPreview(localPreview);
    setWorkflowResult(null);
    setCustomerPreview(null);
    setFramePreview(null);
    setSavedOrder(null);
    setOrderMessage(null);
    setErrorMessage("");
    setStep(2);
  };

  const handleFile = (event) => {
    setSelectedFile(event.target.files?.[0]);
  };

  const handleGenerate = async () => {
    if (!file) {
      setErrorMessage(text.imageRequiredError);
      setStep(1);
      return;
    }

    setStep(4);
    setIsLoading(true);
    setErrorMessage("");
    setWorkflowResult(null);
    setCustomerPreview(null);
    setFramePreview(null);
    setSavedOrder(null);
    setOrderMessage(null);

    const formData = new FormData();
    formData.append("image", file);
    formData.append("style", getBackendStyle(config.model));
    formData.append("material", config.material);
    formData.append("frame_color", config.frameColor);
    formData.append("engraving", config.engraving.trim());
    formData.append("engraving_color", config.engravingColor);

    try {
      const response = await fetch(`${API_BASE_URL}/api/frameana/generate`, {
        method: "POST",
        body: formData,
      });

      const payload = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(payload.message || payload.detail || `HTTP ${response.status}`);
      }

      if (payload.status !== "success") {
        throw new Error(payload.message || text.generationFailedError);
      }

      const data = await hydrateMetadata(payload);
      setWorkflowResult(data);
      setCustomerPreview(absoluteUrl(pickCustomerPreview(data)) || preview);
      setFramePreview(absoluteUrl(pickFramePreview(data)));
    } catch (error) {
      console.error("FRAMEANA generation error:", error);
      setErrorMessage(localizeApiError(error, text.serverConnectionError, language));
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    if (preview) URL.revokeObjectURL(preview);

    setFile(null);
    setPreview(null);
    setCustomerPreview(null);
    setFramePreview(null);
    setWorkflowResult(null);
    setErrorMessage("");
    setSavedOrder(null);
    setOrderMessage(null);
    setStep(1);
    setConfig({
      model: "classic",
      material: "acetate",
      frameColor: "#1F2D57",
      engravingColor: "#C9A14A",
      engraving: "Nael",
    });

    if (fileRef.current) fileRef.current.value = "";
  };

  const goHomeToDesigner = () => {
    setView("designer");
    setSelectedOrder(null);
    reset();
  };

  const goToStep = (targetStep) => {
    if (isLoading) return;
    if (targetStep < step) setStep(targetStep);
  };

  return (
    <div
      className={`app-root ${currentUser ? `device-mode-${deviceMode}` : "auth-device-full"} language-${language}`}
      dir={language === "ar" ? "rtl" : "ltr"}
      lang={language}
    >
      <div className="background-grid" aria-hidden="true" />

      <div className={`app-shell ${!currentUser ? "auth-shell" : ""}`}>
        {currentUser && (
          <header className="topbar">
            <div className="brand-lockup">
              <span className="app-brand-wordmark">FRAMEANA</span>
            </div>
            <span className="topbar-divider" aria-hidden="true" />

            <div className="topbar-controls">
              <nav className="account-nav">
                <button
                  type="button"
                  className="account-home-button"
                  onClick={goHomeToDesigner}
                  aria-label={text.homeToNewDesign}
                  title={text.homeToNewDesign}
                >
                  <Home size={16} />
                </button>
                <button
                  type="button"
                  className={view === "designer" ? "account-nav-active" : ""}
                  onClick={() => {
                    setView("designer");
                    setOrderMessage(null);
                  }}
                >
                  <Glasses size={16} />
                  {text.designer}
                </button>
                <button
                  type="button"
                  className={view === "orders" ? "account-nav-active" : ""}
                  onClick={() => {
                    setView("orders");
                    setOrderMessage(null);
                  }}
                >
                  <ListOrdered size={16} />
                  {text.myOrders}
                </button>
              </nav>

              <div className="topbar-actions">
                <div className="device-mode-switch" role="group" aria-label={text.deviceSwitchLabel}>
                  <button
                    type="button"
                    className={deviceMode === "laptop" ? "device-mode-active" : ""}
                    onClick={() => setDeviceMode("laptop")}
                    aria-pressed={deviceMode === "laptop"}
                  >
                    <Monitor size={17} />
                    <span>{text.laptop}</span>
                  </button>

                  <button
                    type="button"
                    className={deviceMode === "mobile" ? "device-mode-active" : ""}
                    onClick={() => setDeviceMode("mobile")}
                    aria-pressed={deviceMode === "mobile"}
                  >
                    <Smartphone size={17} />
                    <span>{text.mobile}</span>
                  </button>
                </div>

                <LanguageSelect language={language} setLanguage={setLanguage} text={text} />

                <span className="account-chip">
                  <User size={16} />
                  {currentUser.name}
                </span>

                <button type="button" className="account-logout-button" onClick={handleLogout} aria-label={text.logoutLabel}>
                  <LogOut size={16} />
                  {text.logout}
                </button>
              </div>
            </div>
          </header>
        )}

        {!currentUser ? (
          <main className="auth-screen">
            <LanguageSelect language={language} setLanguage={setLanguage} text={text} />
            <AuthGate
              loading={authLoading}
              submitting={authSubmitting}
              error={authError}
              text={text}
              onSubmit={handleAuthSubmit}
            />
          </main>
        ) : (
          <>
            {view === "designer" && step !== 4 && (
              <>
                <section className="designer-header">
                  <div>
                    <span className="eyebrow">{text.designer}</span>
                    <h1>{text.designerPageTitle}</h1>
                    <p>{text.designerPageCopy}</p>
                  </div>
                  <button
                    type="button"
                    className="btn btn-secondary designer-new-button"
                    onClick={reset}
                  >
                    <RotateCcw size={16} />
                    {text.newDesign}
                  </button>
                </section>

                <Stepper current={step} onStepClick={goToStep} language={language} text={text} />
              </>
            )}

            <main className={`workspace ${view === "orders" ? "workspace-orders" : step === 4 ? "workspace-result" : "workspace-designer"}`}>
              {view === "orders" ? (
                <MyOrders
                  orders={orders}
                  selectedOrder={selectedOrder}
                  loading={ordersLoading}
                  actionLoading={orderActionLoading}
                  message={orderMessage}
                  onRefresh={loadOrders}
                  onView={handleSelectOrder}
                  onSubmitOrder={handleSubmitOrder}
                  onDeleteOrder={handleDeleteOrder}
                  onFeedback={handleFeedbackOrder}
                  onDesign={goHomeToDesigner}
                  language={language}
                  text={text}
                />
              ) : step === 4 ? (
                <PreviewStep
                  customerPreview={customerPreview}
                  framePreview={framePreview}
                  workflowResult={workflowResult}
                  isLoading={isLoading}
                  errorMessage={errorMessage}
                  config={config}
                  newOrderCount={newOrderCount}
                  onReset={reset}
                  onBack={() => setStep(3)}
                  onSaveOrder={() => handleCreateOrder(ORDER_STATUS.NEW)}
                  onSaveSubmitOrder={() => handleCreateOrder(ORDER_STATUS.SUBMITTED)}
                  orderActionLoading={orderActionLoading}
                  orderMessage={orderMessage}
                  savedOrder={savedOrder}
                  onGoToOrders={() => setView("orders")}
                  language={language}
                  text={text}
                />
              ) : (
                <div className="designer-work-grid">
                  <section className="designer-work-panel">
                    {errorMessage && step !== 4 && (
                      <div className="inline-alert" role="alert">
                        <Info size={18} />
                        <span>{errorMessage}</span>
                        <button type="button" onClick={() => setErrorMessage("")} aria-label={text.close}>
                          <X size={17} />
                        </button>
                      </div>
                    )}

                    <div key={step} className="step-animation">
                      {step === 1 && (
                        <UploadStep
                          onClick={() => fileRef.current?.click()}
                          inputRef={fileRef}
                          onFile={handleFile}
                          onDropFile={setSelectedFile}
                          language={language}
                          text={text}
                        />
                      )}

                      {step === 2 && (
                        <ModelStep
                          preview={preview}
                          file={file}
                          config={config}
                          setConfig={setConfig}
                          onBack={() => setStep(1)}
                          onNext={() => setStep(3)}
                          language={language}
                          text={text}
                        />
                      )}

                      {step === 3 && (
                        <CustomStep
                          config={config}
                          setConfig={setConfig}
                          onBack={() => setStep(2)}
                          onNext={handleGenerate}
                          language={language}
                          text={text}
                        />
                      )}

                    </div>
                  </section>

                  <DesignerSummaryPanel preview={preview} config={config} language={language} text={text} />
                </div>
              )}
            </main>
          </>
        )}

        {currentUser && (
          <footer className="app-footer">
            <span>{text.footerBrand}</span>
          </footer>
        )}
      </div>
    </div>
  );
}

function Stepper({ current, onStepClick, language, text }) {
  return (
    <nav className="stepper" aria-label={text.designStages}>
      {STEPS.map((stepItem, index) => {
        const Icon = stepItem.icon;
        const isDone = current > stepItem.id;
        const isActive = current === stepItem.id;
        const isClickable = stepItem.id < current;
        const state = isActive ? "active" : isDone ? "done" : "todo";
        const label = localizeField(stepItem, "label", language);
        const shortLabel = localizeField(stepItem, "shortLabel", language);

        return (
          <React.Fragment key={stepItem.id}>
            <button
              type="button"
              className={`stepper-item stepper-${state}`}
              onClick={() => isClickable && onStepClick(stepItem.id)}
              disabled={!isClickable}
              aria-current={isActive ? "step" : undefined}
            >
              <span className="step-number">{isDone ? <Check size={17} /> : index + 1}</span>
              <span className="step-icon"><Icon size={18} /></span>
              <span className="step-copy">
                <strong>{label}</strong>
                <small>{shortLabel}</small>
              </span>
            </button>

            {index < STEPS.length - 1 && (
              <div className={`step-connector ${current > stepItem.id ? "connector-done" : ""}`} />
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}

function AuthGate({ loading, submitting, error, text, onSubmit }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const isRegister = mode === "register";

  const handleSubmit = (event) => {
    event.preventDefault();
    onSubmit({ mode, name, email, password });
  };

  if (loading) {
    return (
      <div className="loading-state auth-loading">
        <div className="loader-orbit">
          <Loader2 size={42} />
          <img src={logo} alt="FRAMEANA" className="loader-logo" />
        </div>
        <span className="eyebrow">{text.authLoadingEyebrow}</span>
        <h2>{text.authVerifying}</h2>
      </div>
    );
  }

  return (
    <section className="auth-gate">
      <div className="auth-intro">
        <div className="auth-wordmark">{text.authBrand}</div>
        <span className="auth-rule" />
        <h1>{text.authHeroTitle}</h1>
        <p>{text.authStudioSubtitle}</p>
        <div className="auth-visual" aria-hidden="true">
          <img src={logo} alt="" />
        </div>
        <div className="auth-stats">
          <span>
            <strong>{text.authStatOneValue}</strong>
            <small>{text.authStatOneLabel}</small>
          </span>
          <span>
            <strong>{text.authStatTwoValue}</strong>
            <small>{text.authStatTwoLabel}</small>
          </span>
          <span>
            <strong>{text.authStatThreeValue}</strong>
            <small>{text.authStatThreeLabel}</small>
          </span>
        </div>
      </div>

      <form className="auth-form" onSubmit={handleSubmit}>
        <div className="auth-form-brand">
          <h2>{text.authStudioTitle}</h2>
          <p>{text.authStudioSubtitle}</p>
        </div>

        <div className="auth-mode-toggle" role="group" aria-label={text.authModeLabel}>
          <button type="button" className={!isRegister ? "auth-mode-active" : ""} onClick={() => setMode("login")}>
            {text.login}
          </button>
          <button type="button" className={isRegister ? "auth-mode-active" : ""} onClick={() => setMode("register")}>
            {text.register}
          </button>
        </div>

        {isRegister && (
          <label className="auth-field">
            <span>{text.name}</span>
            <div className="auth-input-shell">
              <User size={17} />
              <input type="text" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required />
            </div>
          </label>
        )}

        <label className="auth-field">
          <span>{text.email}</span>
          <div className="auth-input-shell">
            <Mail size={17} />
            <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" required />
          </div>
        </label>

        <label className="auth-field">
          <span>{text.password}</span>
          <div className="auth-input-shell">
            <LockKeyhole size={17} />
            <input
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete={isRegister ? "new-password" : "current-password"}
              minLength={6}
              required
            />
          </div>
        </label>

        {!isRegister && (
          <button type="button" className="forgot-password-link">
            {text.forgotPassword}
          </button>
        )}

        {error && (
          <div className="inline-alert auth-alert" role="alert">
            <Info size={18} />
            <span>{error}</span>
          </div>
        )}

        <button type="submit" className="btn btn-primary auth-submit" disabled={submitting}>
          {submitting ? <Loader2 size={18} className="spin-icon" /> : <LogIn size={18} />}
          {isRegister ? text.createAccount : text.signIn}
        </button>
      </form>
    </section>
  );
}

function UploadStep({ onClick, inputRef, onFile, onDropFile, language, text }) {
  const [dragging, setDragging] = useState(false);

  const handleDrop = (event) => {
    event.preventDefault();
    setDragging(false);
    onDropFile(event.dataTransfer.files?.[0]);
  };

  return (
    <section className="step-section">
      <div className="section-intro">
        <span className="eyebrow">{text.stepOne}</span>
        <h2>{text.uploadTitle}</h2>
        <p>{text.uploadCopy}</p>
      </div>

      <button
        type="button"
        className={`upload-zone ${dragging ? "upload-zone-dragging" : ""}`}
        onClick={onClick}
        onDragEnter={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
      >
        <span className="upload-icon"><Upload size={34} /></span>
        <span className="upload-content">
          <strong>{text.uploadDropTitle}</strong>
          <small>{text.uploadDropHint}</small>
        </span>
        <span className="upload-action">
          {text.chooseImage} {language === "en" ? <ArrowRight size={17} /> : <ChevronLeft size={17} />}
        </span>
        <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={onFile} />
      </button>

      <div className="upload-tips">
        <Tip icon={ShieldCheck} title={text.tipPrivacyTitle} text={text.tipPrivacyText} />
        <Tip icon={Glasses} title={text.tipAlignmentTitle} text={text.tipAlignmentText} />
        <Tip icon={Sparkles} title={text.tipResultTitle} text={text.tipResultText} />
      </div>
    </section>
  );
}

function Tip({ icon: Icon, title, text }) {
  return (
    <div className="tip-card">
      <span><Icon size={19} /></span>
      <div>
        <strong>{title}</strong>
        <p>{text}</p>
      </div>
    </div>
  );
}

function ModelStep({ preview, file, config, setConfig, onBack, onNext, language, text }) {
  return (
    <section className="step-section">
      <div className="section-intro">
        <span className="eyebrow">{text.stepTwo}</span>
        <p>{text.stepTwoCopy}</p>
      </div>

      <div className="desktop-split">
        <aside className="customer-mini-card">
          <div className="customer-image-wrap">
            {preview ? <img src={preview} alt={text.customerImage} /> : <ImageIcon size={38} />}
          </div>
          <div>
            <span className="customer-file-icon"><ImageIcon size={17} /></span>
            <div className="customer-file-meta">
              <span>{text.customerImage}</span>
              <strong>{file?.name || text.customerImage}</strong>
            </div>
          </div>
        </aside>

        <div className="models-grid">
          {MODELS.map((model) => {
            const selected = config.model === model.id;
            return (
              <button
                type="button"
                key={model.id}
                onClick={() => setConfig({ ...config, model: model.id })}
                className={`model-card ${selected ? "model-selected" : ""}`}
              >
                <div className="model-top">
                  <span className="model-visual">
                    <FrameGlyph shape={model.id} color={config.frameColor} />
                  </span>
                  {selected && (
                    <span className="selection-mark">
                      <Check size={16} />
                    </span>
                  )}
                </div>
                <div className="model-copy">
                  <strong>{modelName(model.id, language)}</strong>
                  <p>{modelDescription(model.id, language)}</p>
                </div>
                <span className="model-tag">{modelTag(model.id, language)}</span>
              </button>
            );
          })}
        </div>
      </div>

      <NavButtons onBack={onBack} onNext={onNext} language={language} text={text} />
    </section>
  );
}

function CustomStep({ config, setConfig, onBack, onNext, language, text }) {
  return (
    <section className="step-section">
      <div className="section-intro">
        <span className="eyebrow">{text.stepThree}</span>
        <h2>{text.customizeTitle}</h2>
        <p>{text.customizeCopy}</p>
      </div>

      <div className="custom-layout">
        <div className="custom-form custom-form-lovable">
          <div className="custom-block">
            <CustomizeBlockTitle title={text.material} />
            <div className="material-segment" role="group" aria-label={text.material}>
              {MATERIALS.map((material) => (
                <button
                  type="button"
                  key={material.id}
                  className={config.material === material.id ? "material-segment-active" : ""}
                  onClick={() => setConfig({ ...config, material: material.id })}
                >
                  {materialName(material.id, language)}
                </button>
              ))}
            </div>
          </div>

          <div className="custom-block">
            <CustomizeBlockTitle title={text.frameColor} />
            <div className="color-swatch-row">
              {FRAME_COLORS.map((color) => (
                <ColorSwatch
                  key={color.value}
                  color={color.value}
                  label={frameColorName(color.value, language)}
                  active={config.frameColor.toUpperCase() === color.value}
                  onClick={() => setConfig({ ...config, frameColor: color.value })}
                />
              ))}
            </div>
          </div>

          <div className="custom-two-column">
            <div className="custom-block">
              <label className="compact-label" htmlFor="engraving-text">
                {text.engraving}
              </label>
              <input
                id="engraving-text"
                type="text"
                maxLength={12}
                value={config.engraving}
                onChange={(event) => setConfig({ ...config, engraving: event.target.value.toUpperCase() })}
                placeholder={text.engravingPlaceholder}
                className="compact-engraving-input"
              />
            </div>

            <div className="custom-block">
              <span className="compact-label">{text.engravingColor}</span>
              <div className="color-swatch-row">
                {FRAME_COLORS.map((color) => (
                  <ColorSwatch
                    key={color.value}
                    color={color.value}
                    label={frameColorName(color.value, language)}
                    active={config.engravingColor.toUpperCase() === color.value}
                    onClick={() => setConfig({ ...config, engravingColor: color.value })}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <NavButtons
        onBack={onBack}
        onNext={onNext}
        nextLabel={text.generateDesign}
        nextIcon={Sparkles}
        language={language}
        text={text}
      />
    </section>
  );
}

function CustomizeBlockTitle({ title, hint }) {
  return (
    <div className="custom-block-title">
      <h3>{title}</h3>
      {hint && <p>{hint}</p>}
    </div>
  );
}

function ColorSwatch({ color, label, active, onClick }) {
  return (
    <button
      type="button"
      className={`color-swatch-button ${active ? "color-swatch-active" : ""}`}
      style={{ backgroundColor: color }}
      onClick={onClick}
      title={label}
      aria-label={label}
      aria-pressed={active}
    />
  );
}

function DesignerSummaryPanel({ preview, config, language, text }) {
  return (
    <aside className="designer-side-panel">
      <p className="eyebrow">{text.livePreview}</p>

      <div className="designer-summary-visual">
        {preview && (
          <>
            <img src={preview} alt={text.customerImage} />
            <FrameGlyph shape={config.model} color={config.frameColor} large />
          </>
        )}
      </div>

      <dl className="designer-summary-list">
        <SummaryRow label={text.model} value={modelName(config.model, language)} />
        <SummaryRow label={text.material} value={materialName(config.material, language)} />
        <SummaryRow label={text.frameColor} value={config.frameColor.toUpperCase()} swatch={config.frameColor} />
        <SummaryRow label={text.engraving} value={config.engraving || text.noEngraving} />
        <SummaryRow label={text.engravingColor} value={config.engravingColor.toUpperCase()} swatch={config.engravingColor} />
      </dl>

      <div className="designer-summary-divider" />

      <p className="eyebrow">{language === "ar" ? "القياسات" : "Measurements"}</p>
      <dl className="designer-summary-list designer-measurements">
        <SummaryRow label={text.eyeDistance} value="63.4 mm" />
        <SummaryRow label={text.noseWidth} value="19 mm" />
        <SummaryRow label={text.faceWidth} value="140 mm" />
        <SummaryRow label={text.headAngle} value="0 deg" />
      </dl>
    </aside>
  );
}

function FrameGlyph({ shape = "classic", color = "#1F2D57", large = false }) {
  const width = large ? 150 : 108;
  const strokeProps = {
    fill: "none",
    stroke: color,
    strokeWidth: 3.4,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    vectorEffect: "non-scaling-stroke",
  };
  const lensProps = {
    ...strokeProps,
    fill: color,
    fillOpacity: 0.065,
  };

  return (
    <svg
      width={width}
      height={width * 0.36}
      viewBox="0 0 150 54"
      role="img"
      aria-label={shape}
      className="frame-glyph"
    >
      {shape === "round" ? (
        <>
          <circle cx="45" cy="28" r="21.5" {...lensProps} />
          <circle cx="105" cy="28" r="21.5" {...lensProps} />
          <path d="M66 26 Q75 19 84 26" {...strokeProps} />
          <path d="M23 25 L7 21 M127 25 L143 21" {...strokeProps} />
        </>
      ) : shape === "sport" ? (
        <>
          <path d="M19 17 C33 15 51 15 71 17 L65 40 C53 42 40 42 31 39 C24 36 21 27 19 17 Z" {...lensProps} />
          <path d="M131 17 C117 15 99 15 79 17 L85 40 C97 42 110 42 119 39 C126 36 129 27 131 17 Z" {...lensProps} />
          <path d="M71 17 Q75 25 79 17" {...strokeProps} />
          <path d="M20 21 L6 18 M130 21 L144 18" {...strokeProps} />
        </>
      ) : (
        <>
          <path d="M23 15 H63 Q70 15 71 22 L70 35 Q69 42 62 42 H30 Q23 42 22 35 L21 22 Q22 15 29 15 Z" {...lensProps} />
          <path d="M79 22 Q80 15 87 15 H127 Q128 15 129 22 L128 35 Q127 42 120 42 H88 Q81 42 80 35 Z" {...lensProps} />
          <path d="M71 27 H79" {...strokeProps} />
          <path d="M22 24 L7 20 M128 24 L143 20" {...strokeProps} />
        </>
      )}
    </svg>
  );
}

function SummaryRow({ label, value, swatch }) {
  return (
    <div className="summary-row">
      <span>{label}</span>
      <strong>
        {swatch && <i style={{ backgroundColor: swatch }} />}
        {value}
      </strong>
    </div>
  );
}

function StatusBadge({ status, language = DEFAULT_LANGUAGE }) {
  const meta = orderStatusMeta(status, language);
  return <span className={`status-badge status-${meta.tone}`}>{meta.label}</span>;
}

function MyOrders({
  orders,
  selectedOrder,
  loading,
  actionLoading,
  message,
  onView,
  onSubmitOrder,
  onDeleteOrder,
  onFeedback,
  onDesign,
  language,
  text,
}) {
  const newCount = orders.filter((order) => Number(order.status) === ORDER_STATUS.NEW).length;

  return (
    <section className="orders-page">
      <div className="orders-header">
        <div>
          <span className="eyebrow">{text.ordersEyebrow}</span>
          <h2>{text.ordersTitle}</h2>
          <p>{text.ordersLimit(newCount)}</p>
        </div>
        <div className="orders-header-actions">
          <button type="button" className="btn btn-primary compact-button" onClick={onDesign}>
            <Plus size={17} />
            {text.newDesign}
          </button>
        </div>
      </div>

      {message && (
        <div className={`order-message order-message-${message.type || "info"}`}>
          <Info size={18} />
          <span>{message.text}</span>
        </div>
      )}

      <div className="orders-table-panel">
        {orders.length === 0 && !loading ? (
          <div className="orders-empty">
            <ListOrdered size={36} />
            <strong>{text.noOrdersTitle}</strong>
            <span>{text.noOrdersCopy}</span>
          </div>
        ) : (
          <>
            <table className="orders-data-table" aria-label={text.orderTableLabel}>
              <thead>
                <tr>
                  <th>{text.orderColumn}</th>
                  <th>{text.model}</th>
                  <th>{text.engraving}</th>
                  <th>{text.dateColumn}</th>
                  <th>{text.statusColumn}</th>
                  <th>{text.actionsColumn}</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className={selectedOrder?.id === order.id ? "orders-row-active" : ""}>
                    <td className="orders-number">{order.order_number}</td>
                    <td>
                      <span className="orders-frame-cell">
                        <FrameGlyph shape={order.frame_style || "classic"} color={order.frame_color || "#1F2D57"} />
                        <span>{modelName(order.frame_style, language) || order.frame_style || "-"}</span>
                      </span>
                    </td>
                    <td className="orders-engraving">{order.engraving_text || text.noEngraving}</td>
                    <td>{formatOrderDate(order.created_at, language)}</td>
                    <td><StatusBadge status={order.status} language={language} /></td>
                    <td>
                      <OrderActionButtons
                        order={order}
                        actionLoading={actionLoading}
                        onView={onView}
                        onSubmitOrder={onSubmitOrder}
                        onDeleteOrder={onDeleteOrder}
                        onFeedback={onFeedback}
                        text={text}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <ul className="orders-card-list">
              {orders.map((order) => (
                <li key={order.id} className={`orders-card ${selectedOrder?.id === order.id ? "orders-card-active" : ""}`}>
                  <div className="orders-card-head">
                    <div>
                      <strong>{order.order_number}</strong>
                      <span>{modelName(order.frame_style, language) || order.frame_style || "-"} · {materialName(order.material, language) || order.material || "-"}</span>
                    </div>
                    <StatusBadge status={order.status} language={language} />
                  </div>
                  <div className="orders-card-meta">
                    <span>
                      <FrameGlyph shape={order.frame_style || "classic"} color={order.frame_color || "#1F2D57"} />
                      {formatOrderDate(order.created_at, language)}
                    </span>
                    <span className="orders-engraving">{order.engraving_text || text.noEngraving}</span>
                  </div>
                  <OrderActionButtons
                    order={order}
                    actionLoading={actionLoading}
                    onView={onView}
                    onSubmitOrder={onSubmitOrder}
                    onDeleteOrder={onDeleteOrder}
                    onFeedback={onFeedback}
                    text={text}
                  />
                </li>
              ))}
            </ul>
          </>
        )}
      </div>

      {selectedOrder && (
        <div className="orders-detail-drawer">
          <OrderDetails
            order={selectedOrder}
            actionLoading={actionLoading}
            onSubmitOrder={onSubmitOrder}
            onDeleteOrder={onDeleteOrder}
            onFeedback={onFeedback}
            language={language}
            text={text}
          />
        </div>
      )}
    </section>
  );
}

function OrderActionButtons({ order, actionLoading, onView, onSubmitOrder, onDeleteOrder, onFeedback, text }) {
  const isNew = Number(order.status) === ORDER_STATUS.NEW;
  const isDelivered = Number(order.status) === ORDER_STATUS.DELIVERED;

  return (
    <div className="order-actions">
      <button
        type="button"
        className="order-action-button order-action-view"
        onClick={() => onView(order)}
        disabled={actionLoading === `view-${order.id}`}
        title={text.view}
        aria-label={`${text.view} ${order.order_number}`}
      >
        {actionLoading === `view-${order.id}` ? <Loader2 size={15} className="spin-icon" /> : <Eye size={15} />}
        <span>{text.view}</span>
      </button>
      {isNew && (
        <>
          <button
            type="button"
            className="order-action-button order-action-submit"
            onClick={() => onSubmitOrder(order)}
            disabled={actionLoading === `submit-${order.id}`}
            title={text.submit}
            aria-label={`${text.submit} ${order.order_number}`}
          >
            {actionLoading === `submit-${order.id}` ? <Loader2 size={15} className="spin-icon" /> : <Send size={15} />}
            <span>{text.submit}</span>
          </button>
          <button
            type="button"
            className="order-action-icon order-action-danger"
            onClick={() => onDeleteOrder(order)}
            disabled={actionLoading === `delete-${order.id}`}
            title={text.delete}
            aria-label={`${text.delete} ${order.order_number}`}
          >
            {actionLoading === `delete-${order.id}` ? <Loader2 size={15} className="spin-icon" /> : <Trash2 size={15} />}
          </button>
        </>
      )}
      {isDelivered && (
        <button
          type="button"
          className="order-action-button order-action-feedback"
          onClick={() => onFeedback(order)}
          disabled={actionLoading === `feedback-${order.id}`}
          title={text.feedback}
          aria-label={`${text.feedback} ${order.order_number}`}
        >
          {actionLoading === `feedback-${order.id}` ? <Loader2 size={15} className="spin-icon" /> : <MessageSquare size={15} />}
          <span>{text.feedback}</span>
        </button>
      )}
    </div>
  );
}

function OrderDetails({ order, actionLoading, onSubmitOrder, onDeleteOrder, onFeedback, language, text }) {
  const [lightbox, setLightbox] = useState(null);

  if (!order) {
    return (
      <aside className="order-details-panel order-details-empty">
        <Eye size={34} />
        <strong>{text.chooseOrderTitle}</strong>
        <span>{text.chooseOrderCopy}</span>
      </aside>
    );
  }

  const isNew = Number(order.status) === ORDER_STATUS.NEW;
  const isDelivered = Number(order.status) === ORDER_STATUS.DELIVERED;
  const files = [
    { label: text.fileFrameFront, url: order.frame_front_stl },
    { label: text.fileLeftArm, url: order.left_arm_stl },
    { label: text.fileRightArm, url: order.right_arm_stl },
    { label: text.fileFullFrame, url: order.full_frame_stl },
  ].filter((fileItem) => fileItem.url);
  const tryonImageUrl = order.tryon_image ? absoluteUrl(order.tryon_image) : "";
  const tryonImageTitle = `${order.order_number} ${text.previewCustomerTitle}`;

  return (
    <aside className="order-details-panel">
      <div className="order-details-title">
        <div>
          <span className="eyebrow">{text.orderDetails}</span>
          <h3>{order.order_number}</h3>
        </div>
        <StatusBadge status={order.status} language={language} />
      </div>

      <div className="order-detail-preview">
        {tryonImageUrl ? (
          <>
            <button
              type="button"
              className="order-detail-preview-image"
              onClick={() => setLightbox({ title: tryonImageTitle, src: tryonImageUrl })}
              aria-label={text.openFullLabel(tryonImageTitle)}
            >
              <img src={tryonImageUrl} alt={`${order.order_number} try-on`} />
            </button>
            <button
              type="button"
              className="order-detail-expand-button"
              onClick={() => setLightbox({ title: tryonImageTitle, src: tryonImageUrl })}
              aria-label={text.openFullLabel(tryonImageTitle)}
              title={text.openFullLabel(tryonImageTitle)}
            >
              <Maximize2 size={16} />
            </button>
          </>
        ) : (
          <ImageIcon size={30} />
        )}
      </div>

      <div className="order-detail-grid">
        <OrderDetailItem label={text.frameStyle} value={modelName(order.frame_style, language) || order.frame_style} />
        <OrderDetailItem label={text.material} value={materialName(order.material, language) || order.material} />
        <OrderDetailItem label={text.frameColor} value={order.frame_color} swatch={order.frame_color} />
        <OrderDetailItem label={text.engraving} value={order.engraving_text || text.noEngraving} />
        <OrderDetailItem label={text.faceWidth} value={order.face_width} />
        <OrderDetailItem label={text.eyeDistance} value={order.eye_distance} />
        <OrderDetailItem label={text.noseWidth} value={order.nose_width} />
        <OrderDetailItem label={text.headAngle} value={order.head_angle} />
      </div>

      {files.length > 0 && (
        <div className="order-files">
          <strong>{text.files}</strong>
          {files.map((fileItem) => (
            <a key={fileItem.label} href={absoluteUrl(fileItem.url)} download>
              <Download size={16} />
              {fileItem.label}
            </a>
          ))}
        </div>
      )}

      {order.status_history?.length > 0 && (
        <div className="status-history">
          <strong>{text.statusHistory}</strong>
          {order.status_history.map((entry) => (
            <div key={entry.id}>
              <StatusBadge status={entry.status} language={language} />
              <span>{formatOrderDate(entry.created_at, language)}</span>
            </div>
          ))}
        </div>
      )}

      <div className="order-detail-actions">
        {isNew ? (
          <>
            <button type="button" className="btn btn-primary" onClick={() => onSubmitOrder(order)} disabled={actionLoading === `submit-${order.id}`}>
              {actionLoading === `submit-${order.id}` ? <Loader2 size={17} className="spin-icon" /> : <Send size={17} />}
              {text.submitOrder}
            </button>
            <button type="button" className="btn btn-secondary" onClick={() => onDeleteOrder(order)} disabled={actionLoading === `delete-${order.id}`}>
              {actionLoading === `delete-${order.id}` ? <Loader2 size={17} className="spin-icon" /> : <Trash2 size={17} />}
              {text.deleteOrder}
            </button>
          </>
        ) : (
          <div className="locked-status">
            <ShieldCheck size={17} />
            {isDelivered ? text.deliveredClient : text.submittedToFrameana}
          </div>
        )}

        {isDelivered && (
          <button type="button" className="btn btn-secondary" onClick={() => onFeedback(order)} disabled={actionLoading === `feedback-${order.id}`}>
            <MessageSquare size={17} />
            {text.clientFeedback}
          </button>
        )}
      </div>

      {lightbox && (
        <ImageLightbox
          title={lightbox.title}
          src={lightbox.src}
          text={text}
          onClose={() => setLightbox(null)}
        />
      )}
    </aside>
  );
}

function OrderDetailItem({ label, value, swatch }) {
  return (
    <div className="order-detail-item">
      <span>{label}</span>
      <strong>
        {swatch && <i style={{ backgroundColor: swatch }} />}
        {value || "-"}
      </strong>
    </div>
  );
}

function PreviewStep({
  customerPreview,
  framePreview,
  workflowResult,
  isLoading,
  errorMessage,
  config,
  newOrderCount,
  onReset,
  onBack,
  onSaveOrder,
  onSaveSubmitOrder,
  orderActionLoading,
  orderMessage,
  savedOrder,
  onGoToOrders,
  language,
  text,
}) {
  const outputs = useMemo(() => workflowResult?.outputs || {}, [workflowResult?.outputs]);
  const metadata = useMemo(() => workflowResult?.metadata || {}, [workflowResult?.metadata]);
  const [selectedStlKey, setSelectedStlKey] = useState("frame_front");
  const [lightbox, setLightbox] = useState(null);
  const [stlLightboxOpen, setStlLightboxOpen] = useState(false);

  const stlFiles = useMemo(
    () =>
      [
        { key: "full_frame", label: text.fullFrame },
        { key: "frame_front", label: text.frameFront },
        { key: "left_arm", label: text.leftArm },
        { key: "right_arm", label: text.rightArm },
      ].filter((item) => outputs[item.key]),
    [outputs, text]
  );

  const activeStlKey = outputs[selectedStlKey] ? selectedStlKey : stlFiles[0]?.key;
  const selectedStlUrl = absoluteUrl(outputs[activeStlKey]);
  const resolved = readMetadata(metadata, config, language);
  const selectedEngravingUrl =
    activeStlKey === "full_frame" || activeStlKey === "right_arm"
      ? absoluteUrl(outputs.engraving_stl || outputs.engraving)
      : null;
  const frameColorValue = resolved.frameColor || config.frameColor;
  const engravingColorValue = resolved.engravingColor || config.engravingColor;
  const resultTitle = `${modelName(config.model, language)} · ${resolved.material}`;

  useEffect(() => {
    if (!outputs[selectedStlKey] && stlFiles[0]?.key) {
      setSelectedStlKey(stlFiles[0].key);
    }
  }, [outputs, selectedStlKey, stlFiles]);

  if (isLoading) {
    return (
      <div className="loading-state">
        <div className="loader-orbit">
          <Loader2 size={42} />
          <img src={logo} alt="FRAMEANA" className="loader-logo" />
        </div>
        <span className="eyebrow">{text.processingEyebrow}</span>
        <h2>{text.generatingTitle}</h2>
        <p>{text.generatingCopy}</p>
        <div className="loading-steps">
          <span className="loading-step-active">{text.analyzingFace}</span>
          <span>{text.generatingFrame}</span>
          <span>{text.exportingStl}</span>
        </div>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="error-state">
        <span className="error-icon"><Info size={30} /></span>
        <h2>{text.resultErrorTitle}</h2>
        <p>{errorMessage}</p>
        <button type="button" onClick={onBack} className="btn btn-secondary">
          {language === "en" ? <ArrowLeft size={17} /> : <ArrowRight size={17} />}
          {text.backToEdit}
        </button>
      </div>
    );
  }

  if (!workflowResult) return null;

  return (
    <section className="result-page">
      <div className="result-hero">
        <div>
          <span className="eyebrow">{text.resultStep}</span>
          <h2>{resultTitle}</h2>
          <p>{text.resultDescription(modelName(config.model, language), resolved.material, resolved.engraving || text.noEngraving)}</p>
        </div>
        <p className="result-new-count">
          {text.resultNewOrders}: {newOrderCount}/5
        </p>
      </div>

      {orderMessage && (
        <div className={`order-message order-message-${orderMessage.type || "info"}`}>
          {orderMessage.type === "success" ? <Check size={18} /> : <Info size={18} />}
          <span>{orderMessage.text}</span>
          {savedOrder && (
            <button type="button" onClick={onGoToOrders}>
              <ListOrdered size={16} />
              {text.myOrders}
            </button>
          )}
        </div>
      )}

      <div className="result-media-grid">
        <ResultVisualCard
          title={text.previewCustomerTitle}
          meta={`2D · ${text.resultHighRes}`}
          image={customerPreview}
          fallback={text.previewCustomerFallback}
          text={text}
          onOpen={() =>
            customerPreview &&
            setLightbox({ title: text.previewCustomerTitle, src: customerPreview })
          }
        />
        <ResultVisualCard
          title={text.frameImageTitle}
          meta={frameColorValue}
          swatch={frameColorValue}
          image={framePreview}
          fallback={text.frameImageFallback}
          text={text}
          onOpen={() =>
            framePreview &&
            setLightbox({ title: text.frameImageTitle, src: framePreview })
          }
        />

        <section className="result-stl-card">
          <div className="result-stl-view">
            <StlViewer
              url={selectedStlUrl}
              color={frameColorValue}
              engravingUrl={selectedEngravingUrl}
              engravingColor={engravingColorValue}
              text={text}
            />
            <div className="result-stl-overlay">
              <span>{text.stlViewer}</span>
              <button
                type="button"
                onClick={() => setStlLightboxOpen(true)}
                aria-label={text.fullViewLabel(text.stlViewer)}
              >
                <Maximize2 size={15} />
              </button>
            </div>
          </div>

          <div className="result-stl-files">
            {stlFiles.length > 0 ? (
              stlFiles.map((item) => (
                <div
                  key={item.key}
                  className={`result-stl-file ${activeStlKey === item.key ? "result-stl-file-active" : ""}`}
                >
                  <button type="button" onClick={() => setSelectedStlKey(item.key)}>
                    <Box size={15} />
                    <span>{item.label}</span>
                    <small>STL</small>
                  </button>
                  <a
                    href={absoluteUrl(outputs[item.key])}
                    download
                    title={text.download(item.label)}
                    aria-label={text.download(item.label)}
                  >
                    <Download size={15} />
                  </a>
                </div>
              ))
            ) : (
              <div className="result-stl-empty">
                <Box size={18} />
                {text.noStlFile}
              </div>
            )}
          </div>
        </section>
      </div>

      <div className="result-lower-grid">
        <section className="result-summary-card">
          <p className="eyebrow">{text.designSummary}</p>
          <dl className="result-summary-list">
            <SummaryRow label={text.model} value={modelName(config.model, language)} />
            <SummaryRow label={text.material} value={resolved.material} />
            <SummaryRow label={text.frameColor} value={frameColorValue} swatch={frameColorValue} />
            <SummaryRow label={text.engraving} value={resolved.engraving || text.noEngraving} />
            <SummaryRow label={text.engravingColor} value={engravingColorValue} swatch={engravingColorValue} />
            <SummaryRow label={text.faceWidth} value={formatMeasurement(resolved.frontWidth)} />
            <SummaryRow label={text.noseWidth} value={formatMeasurement(resolved.bridgeWidth)} />
            <SummaryRow label={text.leftArm} value={formatMeasurement(resolved.templeLength)} />
          </dl>
        </section>

        <section className="result-command-card">
          <button
            type="button"
            onClick={onSaveOrder}
            className="btn btn-primary"
            disabled={Boolean(savedOrder) || Boolean(orderActionLoading)}
          >
            {orderActionLoading === "save" ? <Loader2 size={17} className="spin-icon" /> : <Save size={17} />}
            {text.save}
          </button>
          <button
            type="button"
            onClick={onSaveSubmitOrder}
            className="btn btn-accent"
            disabled={Boolean(savedOrder) || Boolean(orderActionLoading)}
          >
            {orderActionLoading === "save-submit" ? <Loader2 size={17} className="spin-icon" /> : <Send size={17} />}
            {text.saveAndSubmit}
          </button>
          <button type="button" onClick={onBack} className="btn btn-secondary">
            <SlidersVertical size={17} />
            {text.editOptions}
          </button>
          <button type="button" onClick={onReset} className="btn btn-ghost">
            <RotateCcw size={17} />
            {text.newDesign}
          </button>
        </section>
      </div>

      {lightbox && (
        <ImageLightbox
          title={lightbox.title}
          src={lightbox.src}
          text={text}
          onClose={() => setLightbox(null)}
        />
      )}

      {stlLightboxOpen && (
        <StlLightbox
          title={text.stlViewer}
          url={selectedStlUrl}
          color={frameColorValue}
          engravingUrl={selectedEngravingUrl}
          engravingColor={engravingColorValue}
          text={text}
          onClose={() => setStlLightboxOpen(false)}
        />
      )}
    </section>
  );
}

function ResultVisualCard({ title, meta, swatch, image, fallback, text, onOpen }) {
  return (
    <figure className="result-visual-card">
      <div className="result-visual-frame">
        {image ? (
          <>
            <button
              type="button"
              className="result-visual-image-button"
              onClick={onOpen}
              aria-label={text.openFullLabel(title)}
            >
              <img src={image} alt={title} />
            </button>
            <button
              type="button"
              className="result-visual-expand"
              onClick={onOpen}
              aria-label={text.fullViewLabel(title)}
            >
              <Maximize2 size={15} />
            </button>
          </>
        ) : (
          <div className="result-visual-empty">
            <ImageIcon size={34} />
            <span>{fallback}</span>
          </div>
        )}
      </div>
      <figcaption>
        <span>{title}</span>
        <small>
          {swatch && <i style={{ backgroundColor: swatch }} />}
          {meta}
        </small>
      </figcaption>
    </figure>
  );
}

function ImageLightbox({ title, src, text, onClose }) {
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };

    document.addEventListener("keydown", handleKeyDown);
    document.body.classList.add("lightbox-open");

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.classList.remove("lightbox-open");
    };
  }, [onClose]);

  return (
    <div className="image-lightbox" role="dialog" aria-modal="true" aria-label={title}>
      <button
        type="button"
        className="lightbox-backdrop"
        onClick={onClose}
        aria-label={text.closeImage}
      />

      <div className="lightbox-dialog">
        <div className="lightbox-header">
          <strong>{title}</strong>
          <button type="button" onClick={onClose} aria-label={text.close}>
            <X size={20} />
          </button>
        </div>

        <div className="lightbox-content">
          <img src={src} alt={title} />
        </div>
      </div>
    </div>
  );
}

function NavButtons({ onBack, onNext, nextLabel, nextIcon, language, text }) {
  const BackIcon = language === "en" ? ArrowLeft : ArrowRight;
  const NextIcon = nextIcon || (language === "en" ? ArrowRight : ArrowLeft);

  return (
    <div className="nav-buttons">
      <button type="button" onClick={onBack} className="btn btn-secondary">
        <BackIcon size={17} />
        {text.back}
      </button>
      <button type="button" onClick={onNext} className="btn btn-primary">
        {nextLabel || text.continue}
        <NextIcon size={17} />
      </button>
    </div>
  );
}

function StlLightbox({ title, url, color, engravingUrl, engravingColor, text, onClose }) {
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose();
    };

    document.addEventListener("keydown", handleKeyDown);
    document.body.classList.add("lightbox-open");

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.classList.remove("lightbox-open");
    };
  }, [onClose]);

  return (
    <div className="image-lightbox stl-lightbox" role="dialog" aria-modal="true" aria-label={title}>
      <button
        type="button"
        className="lightbox-backdrop"
        onClick={onClose}
        aria-label={text.closeImage}
      />

      <div className="lightbox-dialog stl-lightbox-dialog">
        <div className="lightbox-header">
          <strong>{title}</strong>
          <button type="button" onClick={onClose} aria-label={text.close}>
            <X size={20} />
          </button>
        </div>

        <div className="stl-lightbox-content">
          <StlViewer
            url={url}
            color={color}
            engravingUrl={engravingUrl}
            engravingColor={engravingColor}
            text={text}
          />
        </div>
      </div>
    </div>
  );
}

function StlViewer({ url, color, engravingUrl, engravingColor, text }) {
  const mountRef = useRef(null);
  const [viewerError, setViewerError] = useState("");

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount || !url) return undefined;

    setViewerError("");

    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#f5f0e5");

    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 5000);
    camera.position.set(0, 0, 180);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    if ("outputColorSpace" in renderer && THREE.SRGBColorSpace) {
      renderer.outputColorSpace = THREE.SRGBColorSpace;
    }
    mount.appendChild(renderer.domElement);

    const ambientLight = new THREE.HemisphereLight(0xffffff, 0x5a6478, 2.2);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 3);
    keyLight.position.set(90, 120, 160);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xc9a14a, 1.2);
    fillLight.position.set(-120, -20, 80);
    scene.add(fillLight);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.autoRotate = false;
    controls.autoRotateSpeed = 0;

    let frameId = 0;
    let disposed = false;
    const group = new THREE.Group();
    scene.add(group);

    const resize = () => {
      const width = Math.max(mount.clientWidth, 260);
      const height = Math.max(mount.clientHeight, 330);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
    };

    const fitCameraToObject = (object) => {
      const box = new THREE.Box3().setFromObject(object);
      const size = box.getSize(new THREE.Vector3());
      const center = box.getCenter(new THREE.Vector3());
      const maxDimension = Math.max(size.x, size.y, size.z, 1);

      object.position.sub(center);
      camera.position.set(0, 0, maxDimension * 1.9);
      camera.near = Math.max(maxDimension / 100, 0.01);
      camera.far = maxDimension * 100;
      camera.updateProjectionMatrix();
      controls.target.set(0, 0, 0);
      controls.update();
    };

    const loader = new STLLoader();
    const loadMesh = (source, material) =>
      new Promise((resolve, reject) => {
        loader.load(
          source,
          (geometry) => {
            geometry.computeVertexNormals();
            resolve(new THREE.Mesh(geometry, material));
          },
          undefined,
          reject
        );
      });

    const frameMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(color || "#1F2D57"),
      metalness: 0.08,
      roughness: 0.38,
      side: THREE.DoubleSide,
    });
    const engravingMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(engravingColor || "#C9A14A"),
      emissive: new THREE.Color(engravingColor || "#C9A14A").multiplyScalar(0.18),
      metalness: 0.22,
      roughness: 0.28,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4,
    });

    loadMesh(url, frameMaterial)
      .then(async (baseMesh) => {
        if (disposed) return;
        group.add(baseMesh);

        if (engravingUrl) {
          try {
            const engravingMesh = await loadMesh(engravingUrl, engravingMaterial);
            if (!disposed) group.add(engravingMesh);
          } catch (error) {
            console.warn("Engraving STL overlay warning:", error);
          }
        }

        if (!disposed) fitCameraToObject(group);
      })
      .catch((error) => {
        console.error("STL viewer error:", error);
        setViewerError(text.stlViewerError);
      });

    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();

    const animate = () => {
      controls.update();
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      observer.disconnect();
      controls.dispose();

      group.traverse((object) => {
        if (!object.isMesh) return;
        object.geometry.dispose();
        object.material.dispose();
      });
      scene.remove(group);

      renderer.dispose();
      if (renderer.domElement.parentNode === mount) {
        mount.removeChild(renderer.domElement);
      }
    };
  }, [url, color, engravingUrl, engravingColor, text]);

  if (!url) {
    return (
      <div className="stl-viewer stl-viewer-placeholder">
        <Box size={38} />
        <span>{text.noStlFile}</span>
      </div>
    );
  }

  return (
    <div className="stl-viewer" ref={mountRef}>
      {viewerError && <div className="stl-viewer-error">{viewerError}</div>}
      <div className="viewer-hint">{text.viewerHint}</div>
    </div>
  );
}

function readMetadata(metadata, config, language = DEFAULT_LANGUAGE) {
  const dimensions =
    metadata?.dimensions ||
    metadata?.measurements ||
    metadata?.frame_dimensions ||
    metadata?.geometry ||
    {};

  const customization = metadata?.customization || {};
  const engraving =
    metadata?.engraving && typeof metadata.engraving === "object"
      ? metadata.engraving
      : {};

  return {
    style: firstValue(metadata.style, customization.style, modelName(config.model, language)),
    material: firstValue(metadata.material, customization.material, materialName(config.material, language)),
    frameColor: firstValue(
      metadata.frame_color,
      metadata.color,
      customization.frame_color,
      config.frameColor
    ),
    engraving: firstValue(
      metadata.engraving_text,
      engraving.text,
      customization.engraving,
      config.engraving
    ),
    engravingColor: firstValue(
      metadata.engraving_color,
      engraving.color,
      customization.engraving_color,
      config.engravingColor
    ),
    frontWidth: firstValue(
      dimensions.total_front_width_mm,
      dimensions.front_width_mm,
      metadata.total_front_width_mm,
      metadata.front_width_mm
    ),
    lensWidth: firstValue(
      dimensions.lens_width_mm,
      dimensions.lens?.width_mm,
      metadata.lens_width_mm
    ),
    lensHeight: firstValue(
      dimensions.lens_height_mm,
      dimensions.lens?.height_mm,
      metadata.lens_height_mm
    ),
    bridgeWidth: firstValue(
      dimensions.bridge_width_mm,
      dimensions.bridge_mm,
      metadata.bridge_width_mm
    ),
    templeLength: firstValue(
      dimensions.temple_length_mm,
      dimensions.arm_length_mm,
      metadata.temple_length_mm
    ),
  };
}

function firstValue(...values) {
  return values.find((value) => value !== undefined && value !== null && value !== "");
}

function formatMeasurement(value) {
  if (value === undefined || value === null || value === "") return "-";
  if (typeof value === "number") return `${Number(value.toFixed(1))} mm`;
  const textValue = String(value);
  return /\bmm\b/i.test(textValue) ? textValue : `${textValue} mm`;
}

export default App;
