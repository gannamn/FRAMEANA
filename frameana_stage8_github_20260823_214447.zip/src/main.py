import os
import shutil
import uuid
from typing import Any, Dict

from fastapi import Body, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from face import FaceAnalysisError, analyze_face
from tryon import TryOnError, draw_tryon


# =========================================================
# FRAMEANA - STAGE 3B BACKEND
# 2D Try-On + complete CAD frame with arms
# Uses Stage 1 stable face analysis
# CAD import stays lazy so image endpoints can boot without CAD dependencies.
# =========================================================


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

app = FastAPI(
    title="FRAMEANA Stage 3B Complete Frame API",
    description=(
        "Analyze a face image, generate 2D try-on previews, and export a complete "
        "CAD eyeglass frame with hinge blocks, hinge pins, arms, and ear hooks."
    ),
    version="3.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/output", StaticFiles(directory=OUTPUT_DIR), name="output")


def _validate_image_file(file: UploadFile) -> str:
    filename = file.filename or ""
    _, extension = os.path.splitext(filename.lower())

    if extension not in ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_EXTENSIONS))
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type. Allowed image types: {allowed}",
        )

    return extension


def _save_upload(file: UploadFile, extension: str) -> str:
    image_id = str(uuid.uuid4())
    image_path = os.path.join(UPLOAD_DIR, f"{image_id}{extension}")

    with open(image_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return image_path


@app.get("/")
def health_check() -> Dict[str, str]:
    return {
        "status": "running",
        "message": "FRAMEANA Stage 3B Complete Frame API is running.",
    }


def _stage3b_response(stl_result: Dict[str, Any], output_filename: str) -> Dict[str, Any]:
    debug = stl_result.get("debug", {})

    left_rule_ok = debug.get("left_arm_start_x") == debug.get("left_hinge_axis_x")
    right_rule_ok = debug.get("right_arm_start_x") == debug.get("right_hinge_axis_x")

    return {
        "status": "success",
        "stage": "FRAMEANA_STAGE_3B_COMPLETE_FRAME_WITH_ARMS",
        "unit": "millimeters",
        "output_stl": f"/output/{output_filename}",
        "components": [
            "front_frame",
            "lens_openings",
            "bridge",
            "hinge_blocks",
            "hinge_pin_visuals",
            "left_arm",
            "right_arm",
            "simple_ear_hooks",
        ],
        "hinge_axis_rule": {
            "description": "Arms start from hinge_axis, not from the lens.",
            "verified": bool(left_rule_ok and right_rule_ok),
            "left_hinge_axis_x_mm": debug.get("left_hinge_axis_x"),
            "left_arm_start_x_mm": debug.get("left_arm_start_x"),
            "right_hinge_axis_x_mm": debug.get("right_hinge_axis_x"),
            "right_arm_start_x_mm": debug.get("right_arm_start_x"),
            "hinge_axis_y_mm": debug.get("hinge_axis_y"),
            "arm_start_y_mm": debug.get("arm_start_y"),
        },
        "dimensions": debug,
        "debug": debug,
    }


def _generate_stage3b_stl(measurements: Dict[str, Any]) -> Dict[str, Any]:
    try:
        from cad import generate_frame_stl_with_debug
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"CAD engine is not available: {str(error)}",
        ) from error

    output_filename = f"{uuid.uuid4()}_stage3b_complete_frame.stl"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    try:
        stl_result = generate_frame_stl_with_debug(
            measurements=measurements,
            output_path=output_path,
        )
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate Stage 3B STL: {str(error)}",
        ) from error

    return _stage3b_response(stl_result, output_filename)


@app.post("/generate-complete-frame")
async def generate_complete_frame_endpoint(
    payload: Dict[str, Any] = Body(...),
) -> Dict[str, Any]:
    """
    Stage 3B CAD endpoint.

    Accepts either direct measurements or {"measurements": {...}}.
    Measurements may be millimeters or Stage 1 pixels; cad.py normalizes them.
    """

    measurements = payload.get("measurements", payload)
    if not isinstance(measurements, dict):
        raise HTTPException(status_code=400, detail="measurements must be an object.")

    return _generate_stage3b_stl(measurements)


@app.post("/generate-complete-frame-from-face")
async def generate_complete_frame_from_face_endpoint(
    file: UploadFile = File(...),
) -> Dict[str, Any]:
    """
    Stage 3B CAD endpoint from an uploaded face image.

    The face is analyzed first, then the complete STL is generated from those
    measurements. Arms start from hinge_axis, not from the lens.
    """

    extension = _validate_image_file(file)
    image_path = ""

    try:
        image_path = _save_upload(file, extension)
        analysis_result = analyze_face(image_path)
        measurements = analysis_result["measurements"]

        response = _generate_stage3b_stl(measurements)
        response["source_measurements_unit"] = "pixels_converted_to_mm"
        response["face_measurements"] = measurements
        response["face_analysis_debug"] = analysis_result["debug"]
        return response

    except FaceAnalysisError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    finally:
        await file.close()
        if image_path and os.path.exists(image_path):
            os.remove(image_path)


@app.post("/analyze-face")
async def analyze_face_endpoint(file: UploadFile = File(...)) -> Dict[str, object]:
    """
    Keep Stage 1 endpoint available.

    Upload a face image and return stable facial measurements only.
    Measurements are in pixels.
    """
    extension = _validate_image_file(file)
    image_path = ""

    try:
        image_path = _save_upload(file, extension)
        result = analyze_face(image_path)
        measurements = result["measurements"]

        return {
            "status": "success",
            "unit": "pixels",
            "face_width": measurements["face_width"],
            "eye_distance": measurements["eye_distance"],
            "nose_width": measurements["nose_width"],
            "head_angle": measurements["head_angle"],
            "center_x": measurements["center_x"],
            "center_y": measurements["center_y"],
            "debug": result["debug"],
        }

    except FaceAnalysisError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected server error: {str(error)}",
        ) from error

    finally:
        await file.close()
        if image_path and os.path.exists(image_path):
            os.remove(image_path)


@app.post("/generate-tryon")
async def generate_tryon_endpoint(
    file: UploadFile = File(...),
    style: str = Form("classic"),
    selected_style: str = Form(""),
    frame_shape: str = Form(""),
    material: str = Form("acetate"),
    frame_color: str = Form("#1f2d57"),
    text: str = Form(""),
    engraving: str = Form(""),
    text_color: str = Form("#c9a14a"),
    engraving_color: str = Form("#c9a14a"),
) -> Dict[str, object]:
    """
    Stage 3B 2D try-on endpoint.

    Steps:
    1. Upload face image.
    2. Analyze face using Stage 1 MediaPipe logic.
    3. Draw a 2D frame with lens openings, bridge, hinge blocks, and visible arms.
    4. Return output image path and JSON debug.

    Measurements are in pixels.
    """
    extension = _validate_image_file(file)
    image_path = ""
    output_filename = f"{uuid.uuid4()}.jpg"
    output_path = os.path.join(OUTPUT_DIR, output_filename)
    output_url = f"/output/{output_filename}"

    try:
        image_path = _save_upload(file, extension)

        analysis_result = analyze_face(image_path)
        measurements = analysis_result["measurements"]
        chosen_style = (frame_shape or selected_style or style or "classic").strip().lower()
        style_options = {
            "style": chosen_style,
            "frame_shape": chosen_style,
            "material": material,
            "frame_color": frame_color,
            "engraving": engraving or text,
            "engraving_color": engraving_color or text_color,
        }

        tryon_result = draw_tryon(
            image_path=image_path,
            output_path=output_path,
            measurements=measurements,
            style_options=style_options,
        )

        return {
            "status": "success",
            "stage": "FRAMEANA_STAGE_3B_2D_TRYON_WITH_VISIBLE_ARMS",
            "unit": "pixels",
            "output_image": output_url,
            "style_options": style_options,
            "components": [
                "front_frame",
                "lens_openings",
                "bridge",
                "hinge_blocks",
                "left_arm",
                "right_arm",
            ],
            "hinge_axis_rule": {
                "description": "Arms start from hinge_axis, not from the lens.",
                "verified": bool(
                    tryon_result["debug"].get("arms_start_from_hinge_axis")
                ),
                "left_hinge_axis_x": tryon_result["debug"].get("left_hinge_axis_x"),
                "left_arm_start_x": tryon_result["debug"].get("left_arm_start_x"),
                "right_hinge_axis_x": tryon_result["debug"].get("right_hinge_axis_x"),
                "right_arm_start_x": tryon_result["debug"].get("right_arm_start_x"),
            },
            "face_width": measurements["face_width"],
            "eye_distance": measurements["eye_distance"],
            "nose_width": measurements["nose_width"],
            "head_angle": measurements["head_angle"],
            "center_x": measurements["center_x"],
            "center_y": measurements["center_y"],
            "frame_width": tryon_result["frame_width"],
            "lens_width": tryon_result["lens_width"],
            "lens_height": tryon_result["lens_height"],
            "bridge_width": tryon_result["bridge_width"],
            "debug": {
                "face_analysis": analysis_result["debug"],
                "tryon": tryon_result["debug"],
            },
        }

    except FaceAnalysisError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except TryOnError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected server error: {str(error)}",
        ) from error

    finally:
        await file.close()
        if image_path and os.path.exists(image_path):
            os.remove(image_path)
