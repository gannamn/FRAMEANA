# FRAMEANA Stage 2C-6 — Backend to Frontend Integration

This package preserves the existing React design and adds a unified pipeline for:

1. Uploading the customer image.
2. Selecting `classic`, `round`, or `sport`.
3. Selecting material, frame color, engraving text, and engraving color.
4. Generating the customer try-on preview and frame preview.
5. Reading and displaying `frame_metadata.json`.
6. Displaying and downloading:
   - `frame_front.stl`
   - `left_arm.stl`
   - `right_arm.stl`
   - `full_frame.stl`
7. Rendering STL files interactively inside the React application.

## Folder contents

```text
frontend/
  App.js
  App.css
  backup_before_stage_2c_6/
    App.js
    App.css
backend/
  frameana_backend_server.js
  frameana_generator_adapter.js
  package.json
  .env.example
README_STAGE_2C_6.md
```

## 1. Put the generator and reference image in place

Either copy `frameana_image2stl_generator.js` into the `backend` folder, or set the full path in your environment.

Windows CMD:

```bat
set FRAMEANA_GENERATOR_PATH=C:\Users\Dell\Documents\Codex\2026-07-11\frameana-stage-2c-4-parametric-frame\work\backup_before_revert_bad_bridge_arm_20260712_081220\frameana_image2stl_generator.js
```

PowerShell:

```powershell
$env:FRAMEANA_GENERATOR_PATH="C:\Users\Dell\Documents\Codex\2026-07-11\frameana-stage-2c-4-parametric-frame\work\backup_before_revert_bad_bridge_arm_20260712_081220\frameana_image2stl_generator.js"
```

The adapter expects the generator to create these exact files inside the supplied output folder:

```text
frame_metadata.json
frame_front.stl
left_arm.stl
right_arm.stl
full_frame.stl
```

Recommended optional preview names:

```text
customer_tryon.png
frame_preview.png
```

The Stage 2C-4/2C-5 generator uses a 2D CAD reference PNG, not the customer's face photo, as the geometry source. Stage 2C-6 now resolves that reference automatically, preferring:

```text
C:\Users\Dell\glasses-app\src\frameana\src\parts.png
```

To override it:

```bat
set FRAMEANA_REFERENCE_IMAGE_PATH=C:\path\to\frame_reference.png
```

## 2. Generator command contract

Default mode is `cli`. The backend invokes:

```text
node frameana_image2stl_generator.js \
  --reference-image <2d-frame-reference-png> \
  --customer-image <customer-image> \
  --output-dir <job-output-folder> \
  --config <generation_config.json> \
  --style classic|round|sport \
  --frame-shape classic|round|sport \
  --material acetate|nylon|pla \
  --frame-color #RRGGBB \
  --arm-text "Nael" \
  --arm-text-color #RRGGBB
```

It also sends the same values as environment variables beginning with `FRAMEANA_`.

When your generator exports a function instead of using CLI arguments, set:

```bat
set FRAMEANA_GENERATOR_MODE=module
```

Supported exported function names are:

```text
generateFrameFromImage
generateFrame
generate
default
```

## 3. Run the backend

```bat
cd backend
npm install
npm start
```

Health check:

```text
http://127.0.0.1:8080/api/health
```

## 4. Install the frontend STL dependency

Inside the existing React project:

```bat
npm install three lucide-react
```

Then replace the current `src/App.js` and `src/App.css` with the files under `frontend/`.

The original working versions are preserved under:

```text
frontend/backup_before_stage_2c_6/
```

Run React normally:

```bat
npm start
```

The frontend defaults to:

```text
http://127.0.0.1:8080
```

To override it:

```text
REACT_APP_API_URL=http://127.0.0.1:8080
```

## 5. Optional Python/Segmind try-on service

The STL generator remains the source of truth for geometry. The existing Python/Segmind service may be connected only for the customer preview:

```bat
set FRAMEANA_TRYON_API_URL=http://127.0.0.1:8000/generate-tryon
```

The backend sends the image plus style, material, colors, and engraving. If the try-on service returns an output image URL, the backend downloads it into the same job output folder as `customer_tryon.png`. If no try-on service is configured, the backend returns the uploaded customer image as a fallback link so the frontend always has a customer preview slot.

## Unified API response

The frontend expects this normalized shape:

```json
{
  "status": "success",
  "metadata": {},
  "outputs": {
    "customer_tryon": "/outputs/<job>/output/customer_tryon.png",
    "frame_preview": "/outputs/<job>/output/frame_preview.png",
    "frame_metadata": "/outputs/<job>/output/frame_metadata.json",
    "frame_front": "/outputs/<job>/output/frame_front.stl",
    "left_arm": "/outputs/<job>/output/left_arm.stl",
    "right_arm": "/outputs/<job>/output/right_arm.stl",
    "full_frame": "/outputs/<job>/output/full_frame.stl"
  }
}
```

## Important integration note

The Stage 2C-6 adapter bridges the older Stage 2C-4/2C-5 generator contract to the platform workflow. The customer image is kept for try-on preview, while the STL geometry is generated from the resolved 2D frame reference PNG.

## Automatic installation into the requested Windows path

After extracting the package, double-click:

```text
install_to_frameana.bat
```

It installs into:

```text
C:\Users\Dell\glasses-app\src\frameana\src
```

The installer:

- backs up the current `App.js` and `App.css`;
- copies the new frontend files;
- creates `src\backend` and copies all backend files;
- searches the primary and backup Codex locations for `frameana_image2stl_generator.js`;
- installs backend npm packages;
- installs `three` and `lucide-react` in the React project;
- creates `start_frameana_stage_2c_6.bat` to launch frontend and backend together.
