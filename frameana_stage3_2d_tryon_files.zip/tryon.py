import math
from typing import Dict, List, Sequence, Tuple

import cv2
import numpy as np


# =========================================================
# FRAMEANA - STAGE 3
# 2D Try-On front frame only
# No CAD, no STL, no temples
# =========================================================


Point = Tuple[float, float]

# Visual tuning for a realistic front frame similar to the CHATGPT reference.
# Rim thickness is dynamic, but these limits keep the output stable across images.
MIN_RIM_THICKNESS = 8.0
MAX_RIM_THICKNESS = 24.0
RIM_TO_EYE_RATIO = 0.035

FRAME_ALPHA = 0.94
LENS_TINT_ALPHA = 0.07
ANTIALIAS_SCALE = 3

# Small optical fit offsets. These do not change Stage 1 measurements.
FRAME_HORIZONTAL_OFFSET_RATIO = -0.035
FRAME_VERTICAL_OFFSET_RATIO = 0.035


class TryOnError(Exception):
    """Raised when 2D try-on image generation cannot be completed."""


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))


def _rotate_point(point: Point, angle_degrees: float) -> Point:
    """Rotate a local point using image coordinate direction."""
    angle = math.radians(angle_degrees)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    x, y = point

    return (
        x * cos_a - y * sin_a,
        x * sin_a + y * cos_a,
    )


def _local_to_image_points(
    local_points: Sequence[Point],
    origin: Point,
    angle_degrees: float,
    scale: int = 1,
) -> np.ndarray:
    """Convert local frame points to rotated image coordinates."""
    output_points: List[List[int]] = []

    for point in local_points:
        rotated_x, rotated_y = _rotate_point(point, angle_degrees)
        image_x = (origin[0] + rotated_x) * scale
        image_y = (origin[1] + rotated_y) * scale
        output_points.append([int(round(image_x)), int(round(image_y))])

    return np.array(output_points, dtype=np.int32)


def _catmull_rom_closed(points: Sequence[Point], samples_per_segment: int = 16) -> List[Point]:
    """
    Create a smooth closed contour through control points.

    This creates a continuous rounded lens/front contour without visible
    straight fragments or extra construction lines.
    """
    if len(points) < 4:
        raise TryOnError("A smooth closed contour requires at least 4 points.")

    smooth_points: List[Point] = []
    count = len(points)

    for index in range(count):
        p0 = points[(index - 1) % count]
        p1 = points[index]
        p2 = points[(index + 1) % count]
        p3 = points[(index + 2) % count]

        for step in range(samples_per_segment):
            t = step / samples_per_segment
            t2 = t * t
            t3 = t2 * t

            x = 0.5 * (
                (2.0 * p1[0])
                + (-p0[0] + p2[0]) * t
                + (2.0 * p0[0] - 5.0 * p1[0] + 4.0 * p2[0] - p3[0]) * t2
                + (-p0[0] + 3.0 * p1[0] - 3.0 * p2[0] + p3[0]) * t3
            )
            y = 0.5 * (
                (2.0 * p1[1])
                + (-p0[1] + p2[1]) * t
                + (2.0 * p0[1] - 5.0 * p1[1] + 4.0 * p2[1] - p3[1]) * t2
                + (-p0[1] + 3.0 * p1[1] - 3.0 * p2[1] + p3[1]) * t3
            )

            smooth_points.append((x, y))

    return smooth_points


def _calculate_frame_dimensions(measurements: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate Stage 3 front-frame dimensions in pixels.

    Important rule:
    bridge_width is the clear distance between the two inner lens cutouts.
    Lens centers are aligned to the eye centers by using:

        lens_width + bridge_width ~= eye_distance

    This produces a realistic eyeglass fit instead of lenses that are too far
    apart or too close together.
    """
    face_width = float(measurements["face_width"])
    eye_distance = float(measurements["eye_distance"])
    nose_width = float(measurements["nose_width"])

    if face_width <= 0 or eye_distance <= 0 or nose_width <= 0:
        raise TryOnError("Invalid face measurements for try-on generation.")

    rim_thickness = _clamp(
        value=eye_distance * RIM_TO_EYE_RATIO,
        minimum=MIN_RIM_THICKNESS,
        maximum=MAX_RIM_THICKNESS,
    )

    bridge_width = _clamp(
        value=nose_width,
        minimum=eye_distance * 0.28,
        maximum=eye_distance * 0.46,
    )

    target_lens_width = eye_distance - bridge_width

    lens_width = _clamp(
        value=target_lens_width,
        minimum=eye_distance * 0.54,
        maximum=eye_distance * 0.70,
    )

    # Rectangular optical shape similar to the reference image.
    lens_height = lens_width * 0.50

    frame_width = (2.0 * lens_width) + bridge_width + (2.0 * rim_thickness)

    # Keep the frame inside a natural face fit without breaking bridge_width.
    max_frame_width = face_width * 0.82
    if frame_width > max_frame_width:
        available_lens_width = (max_frame_width - bridge_width - (2.0 * rim_thickness)) / 2.0
        lens_width = _clamp(
            value=available_lens_width,
            minimum=eye_distance * 0.48,
            maximum=lens_width,
        )
        lens_height = lens_width * 0.50
        frame_width = (2.0 * lens_width) + bridge_width + (2.0 * rim_thickness)

    return {
        "rim_thickness": round(rim_thickness, 2),
        "frame_width": round(frame_width, 2),
        "lens_width": round(lens_width, 2),
        "lens_height": round(lens_height, 2),
        "bridge_width": round(bridge_width, 2),
    }


def create_realistic_lens_contour(
    center_x: float,
    center_y: float,
    width: float,
    height: float,
    mirror_x: bool = False,
) -> List[Point]:
    """
    Create a realistic rounded-rect lens contour.

    The shape is not a circle. It has:
    - flatter upper brow line
    - rounded outer corners
    - soft lower cheek curve
    - slightly narrower nasal side
    """
    x = center_x - (width / 2.0)
    y = center_y - (height / 2.0)
    w = width
    h = height

    ratios = [
        (0.05, 0.45),
        (0.06, 0.28),
        (0.13, 0.16),
        (0.25, 0.09),
        (0.43, 0.06),
        (0.66, 0.06),
        (0.83, 0.12),
        (0.93, 0.25),
        (0.96, 0.48),
        (0.93, 0.70),
        (0.82, 0.84),
        (0.62, 0.91),
        (0.38, 0.91),
        (0.18, 0.84),
        (0.08, 0.68),
    ]

    if mirror_x:
        ratios = [(1.0 - ratio_x, ratio_y) for ratio_x, ratio_y in reversed(ratios)]

    control_points = [(x + w * ratio_x, y + h * ratio_y) for ratio_x, ratio_y in ratios]

    return _catmull_rom_closed(control_points, samples_per_segment=18)


def create_outer_rim_contour(
    center_x: float,
    center_y: float,
    lens_width: float,
    lens_height: float,
    rim_thickness: float,
    mirror_x: bool = False,
) -> List[Point]:
    """
    Create the outer rim contour with a thicker brow.

    The outer contour is not only padding. Top, side, and bottom thickness are
    applied separately so the frame looks like real acetate/plastic eyewear.
    """
    side_rim = rim_thickness * 1.05
    top_rim = rim_thickness * 1.25
    bottom_rim = rim_thickness * 0.95

    outer_width = lens_width + (2.0 * side_rim)
    outer_height = lens_height + top_rim + bottom_rim

    # Because top and bottom rim sizes are different, move the outer center.
    outer_center_y = center_y + ((bottom_rim - top_rim) / 2.0)

    return create_realistic_lens_contour(
        center_x=center_x,
        center_y=outer_center_y,
        width=outer_width,
        height=outer_height,
        mirror_x=mirror_x,
    )


def create_bridge_contour(
    bridge_width: float,
    lens_height: float,
    rim_thickness: float,
) -> List[Point]:
    """
    Create a realistic front bridge between the two rims.

    bridge_width remains the clear distance between the two inner lenses.
    The bridge is drawn mainly inside that gap so it does not create extra
    lines inside the lens openings.
    """
    half_bridge = bridge_width / 2.0

    top_y = -lens_height * 0.43
    bottom_y = top_y + rim_thickness * 0.72
    center_dip_y = bottom_y + rim_thickness * 0.22

    control_points = [
        (-half_bridge, bottom_y),
        (-half_bridge * 0.80, top_y + rim_thickness * 0.15),
        (-half_bridge * 0.35, top_y),
        (0.0, top_y + rim_thickness * 0.06),
        (half_bridge * 0.35, top_y),
        (half_bridge * 0.80, top_y + rim_thickness * 0.15),
        (half_bridge, bottom_y),
        (half_bridge * 0.72, bottom_y + rim_thickness * 0.22),
        (half_bridge * 0.30, center_dip_y),
        (0.0, center_dip_y + rim_thickness * 0.05),
        (-half_bridge * 0.30, center_dip_y),
        (-half_bridge * 0.72, bottom_y + rim_thickness * 0.22),
    ]

    return _catmull_rom_closed(control_points, samples_per_segment=14)


def _create_masks(
    image_shape: Tuple[int, int, int],
    measurements: Dict[str, float],
    dimensions: Dict[str, float],
) -> Tuple[np.ndarray, np.ndarray, Dict[str, object]]:
    """Create anti-aliased masks for frame and subtle lens tint."""
    image_height, image_width = image_shape[:2]
    scale = ANTIALIAS_SCALE

    high_h = image_height * scale
    high_w = image_width * scale

    high_frame_mask = np.zeros((high_h, high_w), dtype=np.uint8)
    high_lens_mask = np.zeros((high_h, high_w), dtype=np.uint8)

    center_x = float(measurements["center_x"])
    center_y = float(measurements["center_y"])
    head_angle = float(measurements["head_angle"])
    eye_distance = float(measurements["eye_distance"])

    lens_width = float(dimensions["lens_width"])
    lens_height = float(dimensions["lens_height"])
    bridge_width = float(dimensions["bridge_width"])
    rim_thickness = float(dimensions["rim_thickness"])

    horizontal_offset = eye_distance * FRAME_HORIZONTAL_OFFSET_RATIO
    vertical_offset = lens_height * FRAME_VERTICAL_OFFSET_RATIO
    origin = (center_x + horizontal_offset, center_y + vertical_offset)

    # This makes the distance between the two inner lens cutouts exactly bridge_width.
    lens_center_offset = (lens_width + bridge_width) / 2.0
    left_lens_center_x = -lens_center_offset
    right_lens_center_x = lens_center_offset

    left_outer_local = create_outer_rim_contour(
        center_x=left_lens_center_x,
        center_y=0.0,
        lens_width=lens_width,
        lens_height=lens_height,
        rim_thickness=rim_thickness,
        mirror_x=True,
    )

    right_outer_local = create_outer_rim_contour(
        center_x=right_lens_center_x,
        center_y=0.0,
        lens_width=lens_width,
        lens_height=lens_height,
        rim_thickness=rim_thickness,
        mirror_x=False,
    )

    left_inner_local = create_realistic_lens_contour(
        center_x=left_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
        mirror_x=True,
    )

    right_inner_local = create_realistic_lens_contour(
        center_x=right_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
        mirror_x=False,
    )

    bridge_local = create_bridge_contour(
        bridge_width=bridge_width,
        lens_height=lens_height,
        rim_thickness=rim_thickness,
    )


    left_outer_points = _local_to_image_points(left_outer_local, origin, head_angle, scale)
    right_outer_points = _local_to_image_points(right_outer_local, origin, head_angle, scale)
    bridge_points = _local_to_image_points(bridge_local, origin, head_angle, scale)

    left_inner_points = _local_to_image_points(left_inner_local, origin, head_angle, scale)
    right_inner_points = _local_to_image_points(right_inner_local, origin, head_angle, scale)

    # Draw full front as filled solids.
    cv2.fillPoly(high_frame_mask, [left_outer_points], 255)
    cv2.fillPoly(high_frame_mask, [right_outer_points], 255)
    cv2.fillPoly(high_frame_mask, [bridge_points], 255)
    # Cut lens openings. This removes any accidental bridge/edge overlap inside lenses.
    cv2.fillPoly(high_frame_mask, [left_inner_points], 0)
    cv2.fillPoly(high_frame_mask, [right_inner_points], 0)

    # Lens tint mask only inside openings.
    cv2.fillPoly(high_lens_mask, [left_inner_points], 255)
    cv2.fillPoly(high_lens_mask, [right_inner_points], 255)

    high_frame_mask = cv2.GaussianBlur(high_frame_mask, (5, 5), 0)
    high_lens_mask = cv2.GaussianBlur(high_lens_mask, (5, 5), 0)

    frame_mask = cv2.resize(
        high_frame_mask,
        (image_width, image_height),
        interpolation=cv2.INTER_AREA,
    )
    lens_mask = cv2.resize(
        high_lens_mask,
        (image_width, image_height),
        interpolation=cv2.INTER_AREA,
    )

    actual_lens_gap = (
        (right_lens_center_x - lens_width / 2.0)
        - (left_lens_center_x + lens_width / 2.0)
    )

    debug = {
        "design": "stage3_realistic_rounded_rect_front_only",
        "vertical_offset": round(vertical_offset, 2),
        "horizontal_offset": round(horizontal_offset, 2),
        "horizontal_offset_ratio": FRAME_HORIZONTAL_OFFSET_RATIO,
        "vertical_offset_ratio": FRAME_VERTICAL_OFFSET_RATIO,
        "rim_thickness": round(rim_thickness, 2),
        "frame_origin": [round(origin[0], 2), round(origin[1], 2)],
        "lens_center_offset": round(lens_center_offset, 2),
        "actual_lens_gap": round(actual_lens_gap, 2),
        "left_outer_points_count": len(left_outer_local),
        "right_outer_points_count": len(right_outer_local),
        "left_inner_points_count": len(left_inner_local),
        "right_inner_points_count": len(right_inner_local),
        "bridge_points_count": len(bridge_local),        "no_temples": True,
        "no_cad": True,
        "no_stl": True,
    }

    return frame_mask, lens_mask, debug


def _apply_frame_to_image(
    image_bgr: np.ndarray,
    frame_mask: np.ndarray,
    lens_mask: np.ndarray,
) -> np.ndarray:
    """Blend frame, subtle lens tint, shadow, and edge highlight into the image."""
    output = image_bgr.astype(np.float32)

    # Subtle lens tint first, behind the frame.
    lens_color = np.array([32, 34, 36], dtype=np.float32)
    lens_alpha = (lens_mask.astype(np.float32) / 255.0) * LENS_TINT_ALPHA
    output = (output * (1.0 - lens_alpha[:, :, None])) + (lens_color * lens_alpha[:, :, None])

    # Soft shadow under the front frame.
    shadow_matrix = np.float32([[1, 0, 2], [0, 1, 3]])
    shadow_mask = cv2.warpAffine(frame_mask, shadow_matrix, (frame_mask.shape[1], frame_mask.shape[0]))
    shadow_mask = cv2.GaussianBlur(shadow_mask, (7, 7), 0)
    shadow_alpha = (shadow_mask.astype(np.float32) / 255.0) * 0.20
    output *= 1.0 - (shadow_alpha[:, :, None] * 0.45)

    # Main black acetate/plastic frame.
    frame_color = np.array([12, 11, 10], dtype=np.float32)
    frame_alpha = (frame_mask.astype(np.float32) / 255.0) * FRAME_ALPHA
    output = (output * (1.0 - frame_alpha[:, :, None])) + (frame_color * frame_alpha[:, :, None])

    # Tiny edge highlight so the frame does not look flat.
    edge_kernel = np.ones((3, 3), dtype=np.uint8)
    edge = cv2.morphologyEx(frame_mask, cv2.MORPH_GRADIENT, edge_kernel)
    edge = cv2.GaussianBlur(edge, (3, 3), 0)
    highlight_alpha = (edge.astype(np.float32) / 255.0) * 0.13
    output += np.array([18, 18, 18], dtype=np.float32) * highlight_alpha[:, :, None]

    return np.clip(output, 0, 255).astype(np.uint8)


def draw_tryon(image_path: str, output_path: str, measurements: Dict[str, float]) -> Dict[str, object]:
    """
    Draw a 2D front eyeglass frame over the uploaded face image.

    Returns frame dimensions and debug information. Units are pixels.
    """
    image_bgr = cv2.imread(image_path)

    if image_bgr is None:
        raise TryOnError("Could not read image file for try-on generation.")

    dimensions = _calculate_frame_dimensions(measurements)
    frame_mask, lens_mask, mask_debug = _create_masks(
        image_shape=image_bgr.shape,
        measurements=measurements,
        dimensions=dimensions,
    )

    output = _apply_frame_to_image(
        image_bgr=image_bgr,
        frame_mask=frame_mask,
        lens_mask=lens_mask,
    )

    success = cv2.imwrite(output_path, output)
    if not success:
        raise TryOnError("Could not save try-on output image.")

    return {
        **dimensions,
        "debug": {
            "frame_alpha": FRAME_ALPHA,
            "lens_tint_alpha": LENS_TINT_ALPHA,
            "antialias_scale": ANTIALIAS_SCALE,
            **mask_debug,
        },
    }
