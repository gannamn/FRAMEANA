import math
from typing import Dict, List, Tuple

import cv2
import mediapipe as mp
import numpy as np


# =========================================================
# FRAMEANA - STAGE 1
# Stable Face Analysis only
# No 2D overlay, no CAD, no STL
# =========================================================


# MediaPipe FaceMesh landmark indices
LEFT_FACE_SIDE = 234
RIGHT_FACE_SIDE = 454

LEFT_EYE_OUTER = 33
LEFT_EYE_INNER = 133
RIGHT_EYE_INNER = 362
RIGHT_EYE_OUTER = 263

NOSE_LEFT = 129
NOSE_RIGHT = 358

# Iris landmarks exist when refine_landmarks=True
LEFT_IRIS = [468, 469, 470, 471, 472]
RIGHT_IRIS = [473, 474, 475, 476, 477]


class FaceAnalysisError(Exception):
    """Raised when face analysis cannot be completed."""


mp_face_mesh = mp.solutions.face_mesh


def _landmark_to_point(landmark, image_width: int, image_height: int) -> Tuple[float, float]:
    """Convert a normalized MediaPipe landmark to pixel coordinates."""
    return float(landmark.x * image_width), float(landmark.y * image_height)


def _distance(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
    """Euclidean distance in pixels."""
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def _average_points(points: List[Tuple[float, float]]) -> Tuple[float, float]:
    """Return the average x/y position of a list of points."""
    if not points:
        raise FaceAnalysisError("Cannot average an empty list of points.")

    x = sum(p[0] for p in points) / len(points)
    y = sum(p[1] for p in points) / len(points)
    return x, y


def _has_iris_landmarks(landmarks) -> bool:
    """Check whether MediaPipe returned iris landmarks."""
    return len(landmarks) > max(RIGHT_IRIS)


def _get_eye_centers(landmarks, image_width: int, image_height: int) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """
    Get stable left/right eye centers.

    Priority:
    1. Use iris landmarks when available.
    2. Fall back to eye corner midpoint.
    """
    if _has_iris_landmarks(landmarks):
        left_eye_points = [
            _landmark_to_point(landmarks[index], image_width, image_height)
            for index in LEFT_IRIS
        ]
        right_eye_points = [
            _landmark_to_point(landmarks[index], image_width, image_height)
            for index in RIGHT_IRIS
        ]

        return _average_points(left_eye_points), _average_points(right_eye_points)

    left_outer = _landmark_to_point(landmarks[LEFT_EYE_OUTER], image_width, image_height)
    left_inner = _landmark_to_point(landmarks[LEFT_EYE_INNER], image_width, image_height)
    right_inner = _landmark_to_point(landmarks[RIGHT_EYE_INNER], image_width, image_height)
    right_outer = _landmark_to_point(landmarks[RIGHT_EYE_OUTER], image_width, image_height)

    left_center = _average_points([left_outer, left_inner])
    right_center = _average_points([right_inner, right_outer])

    return left_center, right_center


def analyze_face(image_path: str) -> Dict[str, float]:
    """
    Analyze one face image and return basic facial measurements.

    Returned values:
    - face_width: distance between left/right face side landmarks in pixels
    - eye_distance: distance between eye centers in pixels
    - nose_width: distance between left/right nose landmarks in pixels
    - head_angle: roll angle between both eyes in degrees
    - center_x: midpoint x between both eyes in pixels
    - center_y: midpoint y between both eyes in pixels
    """
    image_bgr = cv2.imread(image_path)

    if image_bgr is None:
        raise FaceAnalysisError("Could not read image file. Please upload a valid JPG or PNG image.")

    image_height, image_width = image_bgr.shape[:2]

    if image_width <= 0 or image_height <= 0:
        raise FaceAnalysisError("Invalid image size.")

    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    with mp_face_mesh.FaceMesh(
        static_image_mode=True,
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    ) as face_mesh:
        results = face_mesh.process(image_rgb)

    if not results.multi_face_landmarks:
        raise FaceAnalysisError("No face detected. Please upload a clear front-facing face image.")

    landmarks = results.multi_face_landmarks[0].landmark

    left_face = _landmark_to_point(landmarks[LEFT_FACE_SIDE], image_width, image_height)
    right_face = _landmark_to_point(landmarks[RIGHT_FACE_SIDE], image_width, image_height)

    nose_left = _landmark_to_point(landmarks[NOSE_LEFT], image_width, image_height)
    nose_right = _landmark_to_point(landmarks[NOSE_RIGHT], image_width, image_height)

    left_eye, right_eye = _get_eye_centers(landmarks, image_width, image_height)

    face_width = _distance(left_face, right_face)
    eye_distance = _distance(left_eye, right_eye)
    nose_width = _distance(nose_left, nose_right)

    center_x = (left_eye[0] + right_eye[0]) / 2.0
    center_y = (left_eye[1] + right_eye[1]) / 2.0

    head_angle = math.degrees(
        math.atan2(right_eye[1] - left_eye[1], right_eye[0] - left_eye[0])
    )

    return {
        "face_width": round(face_width, 2),
        "eye_distance": round(eye_distance, 2),
        "nose_width": round(nose_width, 2),
        "head_angle": round(head_angle, 2),
        "center_x": round(center_x, 2),
        "center_y": round(center_y, 2),
    }
