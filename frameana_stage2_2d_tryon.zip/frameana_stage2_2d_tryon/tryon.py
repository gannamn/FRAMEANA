import math
from typing import Dict, List, Sequence, Tuple

import cv2
import numpy as np


# =========================================================
# FRAMEANA - STAGE 2
# 2D Try-On front frame only
# No CAD, no STL, no temples
# =========================================================


Point = Tuple[float, float]

# Stage 2 starts with a front frame only.
# Keep this value explicit so the front stays stable while we tune design.
RIM_THICKNESS = 18.0
FRAME_ALPHA = 0.86
ANTIALIAS_SCALE = 3


class TryOnError(Exception):
    """Raised when 2D try-on image generation cannot be completed."""


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))


def _rotate_point(point: Point, angle_degrees: float) -> Point:
    """Rotate a local point using image coordinate direction."""
    angle = math.radians(angle_degrees)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    x, y = point
    return (
        x * cos_a - y * sin_a,
        x * sin_a + y * cos_a,
    )


def _local_to_image_points(
    local_points: Sequence[Point],
    origin: Point,
    angle_degrees: float,
) -> np.ndarray:
    """Convert local frame points to rotated image coordinates."""
    output_points: List[List[int]] = []

    for point in local_points:
        rotated_x, rotated_y = _rotate_point(point, angle_degrees)
        image_x = origin[0] + rotated_x
        image_y = origin[1] + rotated_y
        output_points.append([int(round(image_x)), int(round(image_y))])

    return np.array(output_points, dtype=np.int32)


def _catmull_rom_closed(points: Sequence[Point], samples_per_segment: int = 14) -> List[Point]:
    """
    Create a smooth closed contour through control points.

    This avoids visible straight segments while keeping one continuous contour.
    """
    if len(points) < 4:
        raise TryOnError("A smooth closed contour requires at least 4 points.")

    smooth_points: List[Point] = []
    count = len(points)

    for index in range(count):
        p0 = points[(index - 1) % count]
        p1 = points[index]
        p2 = points[(index + 1) % count]
        p3 = points[(index + 2) % count]

        for step in range(samples_per_segment):
            t = step / samples_per_segment
            t2 = t * t
            t3 = t2 * t

            x = 0.5 * (
                (2.0 * p1[0])
                + (-p0[0] + p2[0]) * t
                + (2.0 * p0[0] - 5.0 * p1[0] + 4.0 * p2[0] - p3[0]) * t2
                + (-p0[0] + 3.0 * p1[0] - 3.0 * p2[0] + p3[0]) * t3
            )
            y = 0.5 * (
                (2.0 * p1[1])
                + (-p0[1] + p2[1]) * t
                + (2.0 * p0[1] - 5.0 * p1[1] + 4.0 * p2[1] - p3[1]) * t2
                + (-p0[1] + 3.0 * p1[1] - 3.0 * p2[1] + p3[1]) * t3
            )
            smooth_points.append((x, y))

    return smooth_points


def _calculate_frame_dimensions(measurements: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate Stage 2 front-frame dimensions in pixels.

    Important rule:
    bridge_width is the clear distance between the two inner lens cutouts.
    Lens centers are driven by the eye distance from Stage 1.
    """
    face_width = float(measurements["face_width"])
    eye_distance = float(measurements["eye_distance"])
    nose_width = float(measurements["nose_width"])

    if face_width <= 0 or eye_distance <= 0 or nose_width <= 0:
        raise TryOnError("Invalid face measurements for try-on generation.")

    bridge_width = _clamp(
        value=nose_width * 0.95,
        minimum=eye_distance * 0.22,
        maximum=eye_distance * 0.34,
    )

    # If the detected nose is unusually small/large, this keeps the bridge usable.
    lens_width = max(eye_distance - bridge_width, eye_distance * 0.58)
    lens_height = lens_width * 0.62

    frame_width = (2.0 * lens_width) + bridge_width + (2.0 * RIM_THICKNESS)

    # Avoid a frame that is visually wider than the face. This only scales the
    # drawn front while preserving bridge_width as the gap between lens cutouts.
    max_frame_width = face_width * 0.92
    if frame_width > max_frame_width:
        scale = max((max_frame_width - (2.0 * RIM_THICKNESS)) / (frame_width - (2.0 * RIM_THICKNESS)), 0.70)
        lens_width *= scale
        bridge_width *= scale
        lens_height *= scale
        frame_width = (2.0 * lens_width) + bridge_width + (2.0 * RIM_THICKNESS)

    return {
        "rim_thickness": round(RIM_THICKNESS, 2),
        "frame_width": round(frame_width, 2),
        "lens_width": round(lens_width, 2),
        "lens_height": round(lens_height, 2),
        "bridge_width": round(bridge_width, 2),
    }


def create_soft_inner_lens(
    center_x: float,
    center_y: float,
    width: float,
    height: float,
) -> List[Point]:
    """
    Create a soft realistic inner lens cutout.

    The cutout is intentionally not a simple circle. It has a soft brow,
    a slightly narrower nasal side, and a gentle lower cheek curve.
    """
    x = center_x - (width / 2.0)
    y = center_y - (height / 2.0)
    w = width
    h = height

    control_points = [
        (x + w * 0.08, y + h * 0.47),
        (x + w * 0.13, y + h * 0.24),
        (x + w * 0.30, y + h * 0.08),
        (x + w * 0.52, y + h * 0.03),
        (x + w * 0.76, y + h * 0.08),
        (x + w * 0.91, y + h * 0.27),
        (x + w * 0.95, y + h * 0.50),
        (x + w * 0.89, y + h * 0.73),
        (x + w * 0.70, y + h * 0.91),
        (x + w * 0.46, y + h * 0.97),
        (x + w * 0.22, y + h * 0.88),
        (x + w * 0.10, y + h * 0.67),
    ]

    return _catmull_rom_closed(control_points, samples_per_segment=16)


def create_full_frame_contour(
    eye_distance: float,
    lens_width: float,
    lens_height: float,
    bridge_width: float,
    rim_thickness: float,
) -> List[Point]:
    """
    Create one continuous outer acetate front contour.

    This replaces separated lens/bridge primitives. The output is one closed
    spline-like contour that contains both lenses and the bridge as one front.
    """
    half_bridge = bridge_width / 2.0
    left_lens_center_x = -eye_distance / 2.0
    right_lens_center_x = eye_distance / 2.0

    left_outer_x = left_lens_center_x - (lens_width / 2.0) - rim_thickness
    left_inner_x = -half_bridge - rim_thickness * 0.55
    right_inner_x = half_bridge + rim_thickness * 0.55
    right_outer_x = right_lens_center_x + (lens_width / 2.0) + rim_thickness

    top_y = -(lens_height / 2.0) - rim_thickness
    bottom_y = (lens_height / 2.0) + rim_thickness

    brow_y = top_y - (rim_thickness * 0.45)
    cheek_y = bottom_y + (rim_thickness * 0.15)

    bridge_top_y = -(lens_height * 0.23)
    bridge_bottom_y = lens_height * 0.33

    control_points = [
        (left_outer_x + rim_thickness * 0.30, -lens_height * 0.25),
        (left_outer_x + lens_width * 0.08, top_y + rim_thickness * 0.20),
        (left_lens_center_x - lens_width * 0.25, brow_y),
        (left_inner_x, top_y + rim_thickness * 0.40),
        (-half_bridge * 0.78, bridge_top_y),
        (0.0, bridge_top_y + rim_thickness * 0.18),
        (half_bridge * 0.78, bridge_top_y),
        (right_inner_x, top_y + rim_thickness * 0.40),
        (right_lens_center_x + lens_width * 0.25, brow_y),
        (right_outer_x - lens_width * 0.08, top_y + rim_thickness * 0.20),
        (right_outer_x - rim_thickness * 0.30, -lens_height * 0.25),
        (right_outer_x, lens_height * 0.10),
        (right_outer_x - lens_width * 0.10, bottom_y - rim_thickness * 0.15),
        (right_lens_center_x + lens_width * 0.20, cheek_y),
        (right_inner_x, bottom_y - rim_thickness * 0.10),
        (half_bridge * 0.72, bridge_bottom_y),
        (0.0, bridge_bottom_y - rim_thickness * 0.05),
        (-half_bridge * 0.72, bridge_bottom_y),
        (left_inner_x, bottom_y - rim_thickness * 0.10),
        (left_lens_center_x - lens_width * 0.20, cheek_y),
        (left_outer_x + lens_width * 0.10, bottom_y - rim_thickness * 0.15),
        (left_outer_x, lens_height * 0.10),
    ]

    return _catmull_rom_closed(control_points, samples_per_segment=14)


def _create_frame_mask(
    image_shape: Tuple[int, int, int],
    measurements: Dict[str, float],
    dimensions: Dict[str, float],
) -> Tuple[np.ndarray, Dict[str, object]]:
    """Create anti-aliased acetate mask with two lens holes."""
    image_height, image_width = image_shape[:2]
    scale = ANTIALIAS_SCALE

    high_mask = np.zeros((image_height * scale, image_width * scale), dtype=np.uint8)

    center_x = float(measurements["center_x"])
    center_y = float(measurements["center_y"])
    head_angle = float(measurements["head_angle"])
    eye_distance = float(measurements["eye_distance"])

    lens_width = float(dimensions["lens_width"])
    lens_height = float(dimensions["lens_height"])
    bridge_width = float(dimensions["bridge_width"])
    rim_thickness = float(dimensions["rim_thickness"])

    # Frames naturally sit a little lower than the exact iris center.
    vertical_offset = lens_height * 0.08
    origin = (center_x, center_y + vertical_offset)

    left_lens_center_x = -eye_distance / 2.0
    right_lens_center_x = eye_distance / 2.0

    outer_local = create_full_frame_contour(
        eye_distance=eye_distance,
        lens_width=lens_width,
        lens_height=lens_height,
        bridge_width=bridge_width,
        rim_thickness=rim_thickness,
    )

    left_inner_local = create_soft_inner_lens(
        center_x=left_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
    )

    right_inner_local = create_soft_inner_lens(
        center_x=right_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
    )

    outer_points = _local_to_image_points(outer_local, origin, head_angle) * scale
    left_inner_points = _local_to_image_points(left_inner_local, origin, head_angle) * scale
    right_inner_points = _local_to_image_points(right_inner_local, origin, head_angle) * scale

    cv2.fillPoly(high_mask, [outer_points], 255)
    cv2.fillPoly(high_mask, [left_inner_points], 0)
    cv2.fillPoly(high_mask, [right_inner_points], 0)

    high_mask = cv2.GaussianBlur(high_mask, (5, 5), 0)
    mask = cv2.resize(high_mask, (image_width, image_height), interpolation=cv2.INTER_AREA)

    debug = {
        "vertical_offset": round(vertical_offset, 2),
        "rim_thickness": round(rim_thickness, 2),
        "frame_origin": [round(origin[0], 2), round(origin[1], 2)],
        "outer_points_count": len(outer_local),
        "left_inner_points_count": len(left_inner_local),
        "right_inner_points_count": len(right_inner_local),
    }

    return mask, debug


def draw_tryon(image_path: str, output_path: str, measurements: Dict[str, float]) -> Dict[str, object]:
    """
    Draw a 2D front eyeglass frame over the uploaded face image.

    Returns frame dimensions and debug information. Units are pixels.
    """
    image_bgr = cv2.imread(image_path)

    if image_bgr is None:
        raise TryOnError("Could not read image file for try-on generation.")

    dimensions = _calculate_frame_dimensions(measurements)
    mask, mask_debug = _create_frame_mask(image_bgr.shape, measurements, dimensions)

    frame_color_bgr = np.array([22, 18, 15], dtype=np.float32)
    overlay = np.full_like(image_bgr, frame_color_bgr, dtype=np.uint8)

    alpha = (mask.astype(np.float32) / 255.0) * FRAME_ALPHA
    alpha_3d = alpha[:, :, None]

    output = (image_bgr.astype(np.float32) * (1.0 - alpha_3d)) + (overlay.astype(np.float32) * alpha_3d)
    output = np.clip(output, 0, 255).astype(np.uint8)

    success = cv2.imwrite(output_path, output)
    if not success:
        raise TryOnError("Could not save try-on output image.")

    return {
        **dimensions,
        "debug": {
            "frame_alpha": FRAME_ALPHA,
            "antialias_scale": ANTIALIAS_SCALE,
            **mask_debug,
        },
    }
