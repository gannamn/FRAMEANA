import os
import shutil
import uuid
from typing import Dict

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from face import FaceAnalysisError, analyze_face
from tryon import TryOnError, draw_tryon


# =========================================================
# FRAMEANA - STAGE 2 BACKEND
# 2D Try-On only
# Uses Stage 1 stable face analysis
# No CAD, no STL, no React dependency
# =========================================================


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

app = FastAPI(
    title="FRAMEANA Stage 2 2D Try-On API",
    description="Upload a face image, analyze it using Stage 1, and draw a 2D front eyeglass frame.",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/output", StaticFiles(directory=OUTPUT_DIR), name="output")


def _validate_image_file(file: UploadFile) -> str:
    filename = file.filename or ""
    _, extension = os.path.splitext(filename.lower())

    if extension not in ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_EXTENSIONS))
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type. Allowed image types: {allowed}",
        )

    return extension


def _save_upload(file: UploadFile, extension: str) -> str:
    image_id = str(uuid.uuid4())
    image_path = os.path.join(UPLOAD_DIR, f"{image_id}{extension}")

    with open(image_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return image_path


@app.get("/")
def health_check() -> Dict[str, str]:
    return {
        "status": "running",
        "message": "FRAMEANA Stage 2 2D Try-On API is running.",
    }


@app.post("/analyze-face")
async def analyze_face_endpoint(file: UploadFile = File(...)) -> Dict[str, object]:
    """
    Keep Stage 1 endpoint available.

    Upload a face image and return stable facial measurements only.
    Measurements are in pixels.
    """
    extension = _validate_image_file(file)
    image_path = ""

    try:
        image_path = _save_upload(file, extension)
        result = analyze_face(image_path)
        measurements = result["measurements"]

        return {
            "status": "success",
            "unit": "pixels",
            "face_width": measurements["face_width"],
            "eye_distance": measurements["eye_distance"],
            "nose_width": measurements["nose_width"],
            "head_angle": measurements["head_angle"],
            "center_x": measurements["center_x"],
            "center_y": measurements["center_y"],
            "debug": result["debug"],
        }

    except FaceAnalysisError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected server error: {str(error)}",
        ) from error

    finally:
        await file.close()
        if image_path and os.path.exists(image_path):
            os.remove(image_path)


@app.post("/generate-tryon")
async def generate_tryon_endpoint(file: UploadFile = File(...)) -> Dict[str, object]:
    """
    Stage 2 endpoint.

    Steps:
    1. Upload face image.
    2. Analyze face using Stage 1 MediaPipe logic.
    3. Draw a 2D front frame only.
    4. Return output image path and JSON debug.

    Measurements are in pixels.
    """
    extension = _validate_image_file(file)
    image_path = ""
    output_filename = f"{uuid.uuid4()}.jpg"
    output_path = os.path.join(OUTPUT_DIR, output_filename)
    output_url = f"/output/{output_filename}"

    try:
        image_path = _save_upload(file, extension)

        analysis_result = analyze_face(image_path)
        measurements = analysis_result["measurements"]

        tryon_result = draw_tryon(
            image_path=image_path,
            output_path=output_path,
            measurements=measurements,
        )

        return {
            "status": "success",
            "unit": "pixels",
            "output": output_url,
            "face_width": measurements["face_width"],
            "eye_distance": measurements["eye_distance"],
            "nose_width": measurements["nose_width"],
            "head_angle": measurements["head_angle"],
            "center_x": measurements["center_x"],
            "center_y": measurements["center_y"],
            "frame_width": tryon_result["frame_width"],
            "lens_width": tryon_result["lens_width"],
            "lens_height": tryon_result["lens_height"],
            "bridge_width": tryon_result["bridge_width"],
            "debug": {
                "face_analysis": analysis_result["debug"],
                "tryon": tryon_result["debug"],
            },
        }

    except FaceAnalysisError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except TryOnError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected server error: {str(error)}",
        ) from error

    finally:
        await file.close()
        if image_path and os.path.exists(image_path):
            os.remove(image_path)
