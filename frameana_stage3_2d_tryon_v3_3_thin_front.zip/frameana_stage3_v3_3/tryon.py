import math
from typing import Dict, List, Sequence, Tuple

import cv2
import numpy as np


# =========================================================
# FRAMEANA - STAGE 3
# 2D Try-On front frame only
# No CAD, no STL, no temples
# =========================================================


Point = Tuple[float, float]

# This version is intentionally stroke-based, not filled-acetate.
# The previous filled mask created a thick black block around the eyes.
# The target for Stage 3 is closer to the CHATGPT reference: thin realistic
# rounded-rectangle front frame, clear lenses, and a simple narrow bridge.
ANTIALIAS_SCALE = 3
FRAME_ALPHA = 0.96
LENS_TINT_ALPHA = 0.035
SHADOW_ALPHA = 0.16

MIN_RIM_THICKNESS = 7.0
MAX_RIM_THICKNESS = 24.0
RIM_TO_EYE_RATIO = 0.031
TOP_BROW_MULTIPLIER = 1.18
BRIDGE_THICKNESS_MULTIPLIER = 0.58

# Stage 3 must stay front-frame only.
DRAW_SMALL_FRONT_END_PIECES = True
FRAME_HORIZONTAL_OFFSET_RATIO = 0.0
FRAME_VERTICAL_OFFSET_RATIO = 0.015


class TryOnError(Exception):
    """Raised when 2D try-on image generation cannot be completed."""


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))


def _rotate_point(point: Point, angle_degrees: float) -> Point:
    """Rotate a local point using image coordinate direction."""
    angle = math.radians(angle_degrees)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    x, y = point

    return (
        x * cos_a - y * sin_a,
        x * sin_a + y * cos_a,
    )


def _local_to_image_points(
    local_points: Sequence[Point],
    origin: Point,
    angle_degrees: float,
    scale: int = 1,
) -> np.ndarray:
    """Convert local frame points to rotated image coordinates."""
    output_points: List[List[int]] = []

    for point in local_points:
        rotated_x, rotated_y = _rotate_point(point, angle_degrees)
        image_x = (origin[0] + rotated_x) * scale
        image_y = (origin[1] + rotated_y) * scale
        output_points.append([int(round(image_x)), int(round(image_y))])

    return np.array(output_points, dtype=np.int32)


def _catmull_rom_closed(points: Sequence[Point], samples_per_segment: int = 16) -> List[Point]:
    """Create a smooth closed contour through control points."""
    if len(points) < 4:
        raise TryOnError("A smooth closed contour requires at least 4 points.")

    smooth_points: List[Point] = []
    count = len(points)

    for index in range(count):
        p0 = points[(index - 1) % count]
        p1 = points[index]
        p2 = points[(index + 1) % count]
        p3 = points[(index + 2) % count]

        for step in range(samples_per_segment):
            t = step / samples_per_segment
            t2 = t * t
            t3 = t2 * t

            x = 0.5 * (
                (2.0 * p1[0])
                + (-p0[0] + p2[0]) * t
                + (2.0 * p0[0] - 5.0 * p1[0] + 4.0 * p2[0] - p3[0]) * t2
                + (-p0[0] + 3.0 * p1[0] - 3.0 * p2[0] + p3[0]) * t3
            )
            y = 0.5 * (
                (2.0 * p1[1])
                + (-p0[1] + p2[1]) * t
                + (2.0 * p0[1] - 5.0 * p1[1] + 4.0 * p2[1] - p3[1]) * t2
                + (-p0[1] + 3.0 * p1[1] - 3.0 * p2[1] + p3[1]) * t3
            )

            smooth_points.append((x, y))

    return smooth_points


def _catmull_rom_open(points: Sequence[Point], samples_per_segment: int = 16) -> List[Point]:
    """Create a smooth open curve through control points."""
    if len(points) < 2:
        raise TryOnError("A smooth open curve requires at least 2 points.")

    padded_points = [points[0], *points, points[-1]]
    smooth_points: List[Point] = []

    for index in range(1, len(padded_points) - 2):
        p0 = padded_points[index - 1]
        p1 = padded_points[index]
        p2 = padded_points[index + 1]
        p3 = padded_points[index + 2]

        for step in range(samples_per_segment):
            t = step / samples_per_segment
            t2 = t * t
            t3 = t2 * t

            x = 0.5 * (
                (2.0 * p1[0])
                + (-p0[0] + p2[0]) * t
                + (2.0 * p0[0] - 5.0 * p1[0] + 4.0 * p2[0] - p3[0]) * t2
                + (-p0[0] + 3.0 * p1[0] - 3.0 * p2[0] + p3[0]) * t3
            )
            y = 0.5 * (
                (2.0 * p1[1])
                + (-p0[1] + p2[1]) * t
                + (2.0 * p0[1] - 5.0 * p1[1] + 4.0 * p2[1] - p3[1]) * t2
                + (-p0[1] + 3.0 * p1[1] - 3.0 * p2[1] + p3[1]) * t3
            )

            smooth_points.append((x, y))

    smooth_points.append(points[-1])
    return smooth_points


def _calculate_frame_dimensions(measurements: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate Stage 3 front-frame dimensions in pixels.

    Important rules:
    - bridge_width is the clear distance between the two lens openings.
    - lens centers are aligned with the eye centers by using:
        lens_width + bridge_width = eye_distance
    - no CAD/STL/temples are generated in this stage.
    """
    face_width = float(measurements["face_width"])
    eye_distance = float(measurements["eye_distance"])
    nose_width = float(measurements["nose_width"])

    if face_width <= 0 or eye_distance <= 0 or nose_width <= 0:
        raise TryOnError("Invalid face measurements for try-on generation.")

    rim_thickness = _clamp(
        value=eye_distance * RIM_TO_EYE_RATIO,
        minimum=MIN_RIM_THICKNESS,
        maximum=MAX_RIM_THICKNESS,
    )

    # Use Stage 1 nose_width as the practical clear bridge gap, with safety
    # limits only to prevent extreme MediaPipe cases.
    bridge_width = _clamp(
        value=nose_width,
        minimum=eye_distance * 0.22,
        maximum=eye_distance * 0.34,
    )

    lens_width = eye_distance - bridge_width
    lens_width = _clamp(
        value=lens_width,
        minimum=eye_distance * 0.58,
        maximum=eye_distance * 0.76,
    )

    # The reference frame is rectangular and not tall/oval.
    lens_height = lens_width * 0.43

    frame_width = (2.0 * lens_width) + bridge_width + (2.0 * rim_thickness)

    max_frame_width = face_width * 0.84
    if frame_width > max_frame_width:
        available_lens_width = (max_frame_width - bridge_width - (2.0 * rim_thickness)) / 2.0
        lens_width = _clamp(
            value=available_lens_width,
            minimum=eye_distance * 0.52,
            maximum=lens_width,
        )
        lens_height = lens_width * 0.43
        frame_width = (2.0 * lens_width) + bridge_width + (2.0 * rim_thickness)

    return {
        "rim_thickness": round(rim_thickness, 2),
        "frame_width": round(frame_width, 2),
        "lens_width": round(lens_width, 2),
        "lens_height": round(lens_height, 2),
        "bridge_width": round(bridge_width, 2),
    }


def create_reference_lens_contour(
    center_x: float,
    center_y: float,
    width: float,
    height: float,
    mirror_x: bool = False,
) -> List[Point]:
    """
    Create a CHATGPT-reference style lens contour.

    This is a rounded-rectangle optical shape:
    - flatter top brow
    - rounded corners
    - soft lower curve
    - no filled black block
    """
    x = center_x - (width / 2.0)
    y = center_y - (height / 2.0)
    w = width
    h = height

    ratios = [
        (0.035, 0.50),
        (0.045, 0.35),
        (0.080, 0.22),
        (0.160, 0.125),
        (0.300, 0.080),
        (0.520, 0.070),
        (0.735, 0.075),
        (0.875, 0.135),
        (0.945, 0.255),
        (0.970, 0.470),
        (0.940, 0.670),
        (0.850, 0.805),
        (0.675, 0.875),
        (0.455, 0.895),
        (0.245, 0.870),
        (0.110, 0.770),
        (0.055, 0.640),
    ]

    if mirror_x:
        ratios = [(1.0 - ratio_x, ratio_y) for ratio_x, ratio_y in reversed(ratios)]

    control_points = [(x + w * ratio_x, y + h * ratio_y) for ratio_x, ratio_y in ratios]
    return _catmull_rom_closed(control_points, samples_per_segment=18)


def create_top_brow_curve(
    center_x: float,
    center_y: float,
    width: float,
    height: float,
) -> List[Point]:
    """Create a subtle thicker upper brow stroke for one lens."""
    x = center_x - (width / 2.0)
    y = center_y - (height / 2.0)
    w = width
    h = height

    control_points = [
        (x + w * 0.115, y + h * 0.195),
        (x + w * 0.250, y + h * 0.090),
        (x + w * 0.500, y + h * 0.055),
        (x + w * 0.750, y + h * 0.090),
        (x + w * 0.890, y + h * 0.200),
    ]

    return _catmull_rom_open(control_points, samples_per_segment=18)


def create_bridge_curve(
    bridge_width: float,
    lens_height: float,
) -> List[Point]:
    """
    Create a narrow bridge curve.

    The curve spans exactly from the left inner lens edge to the right inner
    lens edge. Therefore bridge_width remains the real visual gap between
    lenses, not decorative padding.
    """
    half_bridge = bridge_width / 2.0
    y = -lens_height * 0.225

    control_points = [
        (-half_bridge, y + lens_height * 0.020),
        (-half_bridge * 0.55, y - lens_height * 0.010),
        (0.0, y - lens_height * 0.018),
        (half_bridge * 0.55, y - lens_height * 0.010),
        (half_bridge, y + lens_height * 0.020),
    ]

    return _catmull_rom_open(control_points, samples_per_segment=20)


def create_front_end_piece_curve(
    side: int,
    lens_center_x: float,
    lens_width: float,
    lens_height: float,
    rim_thickness: float,
) -> List[Point]:
    """Create a very short front end-piece only, not a temple/arm."""
    outer_x = lens_center_x + side * (lens_width * 0.485)
    y = -lens_height * 0.235
    length = rim_thickness * 2.4

    if side < 0:
        control_points = [
            (outer_x, y),
            (outer_x - length * 0.55, y - rim_thickness * 0.04),
            (outer_x - length, y + rim_thickness * 0.05),
        ]
    else:
        control_points = [
            (outer_x, y),
            (outer_x + length * 0.55, y - rim_thickness * 0.04),
            (outer_x + length, y + rim_thickness * 0.05),
        ]

    return _catmull_rom_open(control_points, samples_per_segment=12)


def _draw_curve(
    mask: np.ndarray,
    local_points: Sequence[Point],
    origin: Point,
    angle_degrees: float,
    thickness: float,
    closed: bool,
    scale: int,
) -> None:
    points = _local_to_image_points(
        local_points=local_points,
        origin=origin,
        angle_degrees=angle_degrees,
        scale=scale,
    )

    cv2.polylines(
        mask,
        [points],
        isClosed=closed,
        color=255,
        thickness=max(1, int(round(thickness * scale))),
        lineType=cv2.LINE_AA,
    )


def _fill_lens_tint(
    mask: np.ndarray,
    local_points: Sequence[Point],
    origin: Point,
    angle_degrees: float,
    scale: int,
) -> None:
    points = _local_to_image_points(
        local_points=local_points,
        origin=origin,
        angle_degrees=angle_degrees,
        scale=scale,
    )

    cv2.fillPoly(mask, [points], 255, lineType=cv2.LINE_AA)


def _create_masks(
    image_shape: Tuple[int, int, int],
    measurements: Dict[str, float],
    dimensions: Dict[str, float],
) -> Tuple[np.ndarray, np.ndarray, Dict[str, object]]:
    """Create anti-aliased masks for a thin front frame and subtle lens tint."""
    image_height, image_width = image_shape[:2]
    scale = ANTIALIAS_SCALE

    high_h = image_height * scale
    high_w = image_width * scale

    high_frame_mask = np.zeros((high_h, high_w), dtype=np.uint8)
    high_lens_mask = np.zeros((high_h, high_w), dtype=np.uint8)

    center_x = float(measurements["center_x"])
    center_y = float(measurements["center_y"])
    head_angle = float(measurements["head_angle"])
    eye_distance = float(measurements["eye_distance"])

    lens_width = float(dimensions["lens_width"])
    lens_height = float(dimensions["lens_height"])
    bridge_width = float(dimensions["bridge_width"])
    rim_thickness = float(dimensions["rim_thickness"])

    horizontal_offset = eye_distance * FRAME_HORIZONTAL_OFFSET_RATIO
    vertical_offset = lens_height * FRAME_VERTICAL_OFFSET_RATIO
    origin = (center_x + horizontal_offset, center_y + vertical_offset)

    # This makes the clear distance between the two lens openings exactly bridge_width.
    lens_center_offset = (lens_width + bridge_width) / 2.0
    left_lens_center_x = -lens_center_offset
    right_lens_center_x = lens_center_offset

    left_lens = create_reference_lens_contour(
        center_x=left_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
        mirror_x=True,
    )
    right_lens = create_reference_lens_contour(
        center_x=right_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
        mirror_x=False,
    )

    left_brow = create_top_brow_curve(
        center_x=left_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
    )
    right_brow = create_top_brow_curve(
        center_x=right_lens_center_x,
        center_y=0.0,
        width=lens_width,
        height=lens_height,
    )

    bridge = create_bridge_curve(
        bridge_width=bridge_width,
        lens_height=lens_height,
    )

    _fill_lens_tint(high_lens_mask, left_lens, origin, head_angle, scale)
    _fill_lens_tint(high_lens_mask, right_lens, origin, head_angle, scale)

    # Main lens outlines: a stroke, not a filled outer polygon.
    _draw_curve(high_frame_mask, left_lens, origin, head_angle, rim_thickness, True, scale)
    _draw_curve(high_frame_mask, right_lens, origin, head_angle, rim_thickness, True, scale)

    # Slightly thicker top brow like real plastic/acetate frames.
    _draw_curve(
        high_frame_mask,
        left_brow,
        origin,
        head_angle,
        rim_thickness * TOP_BROW_MULTIPLIER,
        False,
        scale,
    )
    _draw_curve(
        high_frame_mask,
        right_brow,
        origin,
        head_angle,
        rim_thickness * TOP_BROW_MULTIPLIER,
        False,
        scale,
    )

    # Thin bridge, not a black block.
    _draw_curve(
        high_frame_mask,
        bridge,
        origin,
        head_angle,
        rim_thickness * BRIDGE_THICKNESS_MULTIPLIER,
        False,
        scale,
    )

    if DRAW_SMALL_FRONT_END_PIECES:
        left_end_piece = create_front_end_piece_curve(
            side=-1,
            lens_center_x=left_lens_center_x,
            lens_width=lens_width,
            lens_height=lens_height,
            rim_thickness=rim_thickness,
        )
        right_end_piece = create_front_end_piece_curve(
            side=1,
            lens_center_x=right_lens_center_x,
            lens_width=lens_width,
            lens_height=lens_height,
            rim_thickness=rim_thickness,
        )
        _draw_curve(
            high_frame_mask,
            left_end_piece,
            origin,
            head_angle,
            rim_thickness * 0.78,
            False,
            scale,
        )
        _draw_curve(
            high_frame_mask,
            right_end_piece,
            origin,
            head_angle,
            rim_thickness * 0.78,
            False,
            scale,
        )
        end_piece_points_count = len(left_end_piece) + len(right_end_piece)
    else:
        end_piece_points_count = 0

    # Keep edges smooth but do not blur heavily, otherwise the frame becomes fat.
    high_frame_mask = cv2.GaussianBlur(high_frame_mask, (3, 3), 0)
    high_lens_mask = cv2.GaussianBlur(high_lens_mask, (3, 3), 0)

    frame_mask = cv2.resize(
        high_frame_mask,
        (image_width, image_height),
        interpolation=cv2.INTER_AREA,
    )
    lens_mask = cv2.resize(
        high_lens_mask,
        (image_width, image_height),
        interpolation=cv2.INTER_AREA,
    )

    actual_lens_gap = (
        (right_lens_center_x - lens_width / 2.0)
        - (left_lens_center_x + lens_width / 2.0)
    )

    debug = {
        "design": "stage3_thin_stroked_front_frame_like_chatgpt_reference",
        "vertical_offset": round(vertical_offset, 2),
        "horizontal_offset": round(horizontal_offset, 2),
        "horizontal_offset_ratio": FRAME_HORIZONTAL_OFFSET_RATIO,
        "vertical_offset_ratio": FRAME_VERTICAL_OFFSET_RATIO,
        "rim_thickness": round(rim_thickness, 2),
        "top_brow_thickness": round(rim_thickness * TOP_BROW_MULTIPLIER, 2),
        "bridge_thickness": round(rim_thickness * BRIDGE_THICKNESS_MULTIPLIER, 2),
        "frame_origin": [round(origin[0], 2), round(origin[1], 2)],
        "lens_center_offset": round(lens_center_offset, 2),
        "actual_lens_gap": round(actual_lens_gap, 2),
        "left_lens_points_count": len(left_lens),
        "right_lens_points_count": len(right_lens),
        "bridge_points_count": len(bridge),
        "end_piece_points_count": end_piece_points_count,
        "stroke_based_frame": True,
        "filled_black_block_removed": True,
        "no_temples": True,
        "no_cad": True,
        "no_stl": True,
    }

    return frame_mask, lens_mask, debug


def _apply_frame_to_image(
    image_bgr: np.ndarray,
    frame_mask: np.ndarray,
    lens_mask: np.ndarray,
) -> np.ndarray:
    """Blend thin black front frame, subtle lens tint, shadow, and highlight."""
    output = image_bgr.astype(np.float32)

    # Very subtle lens tint, only inside the lens area.
    lens_color = np.array([32, 35, 38], dtype=np.float32)
    lens_alpha = (lens_mask.astype(np.float32) / 255.0) * LENS_TINT_ALPHA
    output = (output * (1.0 - lens_alpha[:, :, None])) + (lens_color * lens_alpha[:, :, None])

    # Small natural shadow. Keep it light to avoid fake thick edges.
    shadow_matrix = np.float32([[1, 0, 1.5], [0, 1, 2.0]])
    shadow_mask = cv2.warpAffine(
        frame_mask,
        shadow_matrix,
        (frame_mask.shape[1], frame_mask.shape[0]),
    )
    shadow_mask = cv2.GaussianBlur(shadow_mask, (5, 5), 0)
    shadow_alpha = (shadow_mask.astype(np.float32) / 255.0) * SHADOW_ALPHA
    output *= 1.0 - (shadow_alpha[:, :, None] * 0.42)

    # Main black frame.
    frame_color = np.array([9, 9, 8], dtype=np.float32)
    frame_alpha = (frame_mask.astype(np.float32) / 255.0) * FRAME_ALPHA
    output = (output * (1.0 - frame_alpha[:, :, None])) + (frame_color * frame_alpha[:, :, None])

    # Small upper-left edge highlight to make the front less flat.
    edge_kernel = np.ones((3, 3), dtype=np.uint8)
    edge = cv2.morphologyEx(frame_mask, cv2.MORPH_GRADIENT, edge_kernel)
    edge = cv2.GaussianBlur(edge, (3, 3), 0)
    highlight_alpha = (edge.astype(np.float32) / 255.0) * 0.10
    output += np.array([16, 16, 16], dtype=np.float32) * highlight_alpha[:, :, None]

    return np.clip(output, 0, 255).astype(np.uint8)


def draw_tryon(image_path: str, output_path: str, measurements: Dict[str, float]) -> Dict[str, object]:
    """
    Draw a 2D front eyeglass frame over the uploaded face image.

    Returns frame dimensions and debug information. Units are pixels.
    """
    image_bgr = cv2.imread(image_path)

    if image_bgr is None:
        raise TryOnError("Could not read image file for try-on generation.")

    dimensions = _calculate_frame_dimensions(measurements)
    frame_mask, lens_mask, mask_debug = _create_masks(
        image_shape=image_bgr.shape,
        measurements=measurements,
        dimensions=dimensions,
    )

    output = _apply_frame_to_image(
        image_bgr=image_bgr,
        frame_mask=frame_mask,
        lens_mask=lens_mask,
    )

    success = cv2.imwrite(output_path, output)
    if not success:
        raise TryOnError("Could not save try-on output image.")

    return {
        **dimensions,
        "debug": {
            "frame_alpha": FRAME_ALPHA,
            "lens_tint_alpha": LENS_TINT_ALPHA,
            "shadow_alpha": SHADOW_ALPHA,
            "antialias_scale": ANTIALIAS_SCALE,
            **mask_debug,
        },
    }
